import {
  ChromaKeySettings,
  ColorGradingSettings,
  CropSettings,
  EffectOverlayType,
  FilterPreset,
  MediaItem,
  ProjectData,
  TextStyleSettings,
  TimelineClip,
  TimelineTrack,
  TransitionType,
} from '../types/editor';

export const DEFAULT_COLOR_GRADING: ColorGradingSettings = {
  brightness: 0,
  contrast: 0,
  saturation: 0,
  exposure: 0,
  hue: 0,
  temperature: 0,
  vignette: 0,
  blur: 0,
  filterPreset: 'none',
};

export const DEFAULT_CHROMA_KEY: ChromaKeySettings = {
  enabled: false,
  keyColor: '#00FF00',
  similarity: 42,
  smoothness: 14,
  spillSuppression: 18,
};

export const DEFAULT_CROP: CropSettings = {
  top: 0,
  right: 0,
  bottom: 0,
  left: 0,
};

export const DEFAULT_TRACKS: TimelineTrack[] = [
  { id: 'track-v2', name: 'V2 • Overlay / PIP', type: 'video', muted: false, locked: false, hidden: false },
  { id: 'track-v1', name: 'V1 • Main Video', type: 'video', muted: false, locked: false, hidden: false },
  { id: 'track-t1', name: 'T1 • Titles & Captions', type: 'text', muted: false, locked: false, hidden: false },
  { id: 'track-fx1', name: 'FX1 • Effects & Stickers', type: 'effect', muted: false, locked: false, hidden: false },
  { id: 'track-a1', name: 'A1 • Music Score', type: 'audio', muted: false, locked: false, hidden: false },
  { id: 'track-a2', name: 'A2 • Voiceover & SFX', type: 'audio', muted: false, locked: false, hidden: false },
];

function makeWaveform(seed: number, length = 64): number[] {
  const arr: number[] = [];
  for (let i = 0; i < length; i++) {
    const v =
      0.25 +
      0.45 * Math.abs(Math.sin(i * 0.43 + seed)) +
      0.28 * Math.abs(Math.cos(i * 1.17 - seed * 2));
    arr.push(Math.min(1, Math.max(0.12, Number(v.toFixed(2)))));
  }
  return arr;
}

export const DEFAULT_MEDIA_LIBRARY: MediaItem[] = [
  {
    id: 'media-neon-city',
    name: 'Cyberpunk Neon Metropolis',
    type: 'video',
    url: 'https://videos.pexels.com/video-files/8058411/8058411-hd_1920_1080_25fps.mp4',
    thumbnail:
      'https://images.pexels.com/videos/8058411/pexels-photo-8058411.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=240&w=420',
    duration: 8,
    width: 1920,
    height: 1080,
    proceduralPreset: 'neon-city',
  },
  {
    id: 'media-futuristic-walk',
    name: 'Futuristic Neon Corridor',
    type: 'video',
    url: 'https://videos.pexels.com/video-files/8059305/8059305-hd_1920_1080_25fps.mp4',
    thumbnail:
      'https://images.pexels.com/videos/8059305/pexels-photo-8059305.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=240&w=420',
    duration: 7,
    width: 1920,
    height: 1080,
    proceduralPreset: 'synth-corridor',
  },
  {
    id: 'media-greenscreen-actor',
    name: 'Green Screen Holo Presenter (Chroma)',
    type: 'video',
    url: 'procedural://greenscreen-presenter',
    thumbnail:
      'https://images.pexels.com/photos/8726478/pexels-photo-8726478.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=200&w=280',
    duration: 8,
    width: 1920,
    height: 1080,
    proceduralPreset: 'greenscreen-presenter',
    isGreenScreen: true,
  },
  {
    id: 'media-hyper-tunnel',
    name: 'Hyperdrive Quantum Tunnel 60fps',
    type: 'video',
    url: 'procedural://hyper-tunnel',
    thumbnail:
      'https://images.pexels.com/photos/18545010/pexels-photo-18545010.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=200&w=280',
    duration: 6,
    width: 1920,
    height: 1080,
    proceduralPreset: 'hyper-tunnel',
  },
  {
    id: 'media-aurora-waves',
    name: 'Aurora Synth Horizon Loop',
    type: 'video',
    url: 'procedural://aurora-waves',
    thumbnail:
      'https://images.pexels.com/photos/35161171/pexels-photo-35161171.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=200&w=280',
    duration: 7,
    width: 1920,
    height: 1080,
    proceduralPreset: 'aurora-waves',
  },
  {
    id: 'media-img-portrait',
    name: 'Violet Studio Fashion Portrait',
    type: 'image',
    url: 'https://images.pexels.com/photos/12789661/pexels-photo-12789661.png?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    thumbnail:
      'https://images.pexels.com/photos/12789661/pexels-photo-12789661.png?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=200&w=280',
    duration: 5,
    width: 1080,
    height: 1350,
    proceduralPreset: 'neon-portrait',
  },
  {
    id: 'media-img-skyline',
    name: 'Crimson Neon Cityscape Still',
    type: 'image',
    url: 'https://images.pexels.com/photos/18545016/pexels-photo-18545016.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    thumbnail:
      'https://images.pexels.com/photos/18545016/pexels-photo-18545016.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=200&w=280',
    duration: 5,
    width: 1920,
    height: 1080,
    proceduralPreset: 'crimson-skyline',
  },
  // Built-in Audio Library
  {
    id: 'audio-synthwave',
    name: 'Midnight Hyperdrive (128 BPM)',
    type: 'audio',
    url: 'synth://synthwave-128',
    thumbnail: '',
    duration: 16,
    width: 0,
    height: 0,
    proceduralPreset: 'synthwave-128',
    audioCategory: 'music',
    bpm: 128,
    waveform: makeWaveform(1.4, 80),
  },
  {
    id: 'audio-lofi',
    name: 'Velvet Lo-Fi Beats (92 BPM)',
    type: 'audio',
    url: 'synth://lofi-92',
    thumbnail: '',
    duration: 15,
    width: 0,
    height: 0,
    proceduralPreset: 'lofi-92',
    audioCategory: 'music',
    bpm: 92,
    waveform: makeWaveform(3.1, 80),
  },
  {
    id: 'audio-cinematic',
    name: 'Blade Runner Bass Pulse (110 BPM)',
    type: 'audio',
    url: 'synth://cinematic-110',
    thumbnail: '',
    duration: 14,
    width: 0,
    height: 0,
    proceduralPreset: 'cinematic-110',
    audioCategory: 'music',
    bpm: 110,
    waveform: makeWaveform(5.2, 80),
  },
  {
    id: 'audio-sfx-whoosh',
    name: 'Cyber Whoosh Transition',
    type: 'audio',
    url: 'synth://sfx-whoosh',
    thumbnail: '',
    duration: 1.5,
    width: 0,
    height: 0,
    proceduralPreset: 'sfx-whoosh',
    audioCategory: 'sfx',
    waveform: makeWaveform(7.7, 24),
  },
  {
    id: 'audio-sfx-boom',
    name: 'Cinematic Sub Impact Boom',
    type: 'audio',
    url: 'synth://sfx-boom',
    thumbnail: '',
    duration: 2.2,
    width: 0,
    height: 0,
    proceduralPreset: 'sfx-boom',
    audioCategory: 'sfx',
    waveform: makeWaveform(9.1, 28),
  },
  {
    id: 'audio-sfx-glitch',
    name: 'Digital Glitch Data Burst',
    type: 'audio',
    url: 'synth://sfx-glitch',
    thumbnail: '',
    duration: 1.4,
    width: 0,
    height: 0,
    proceduralPreset: 'sfx-glitch',
    audioCategory: 'sfx',
    waveform: makeWaveform(11.3, 24),
  },
];

export interface TextPresetTemplate {
  id: string;
  label: string;
  previewBadge: string;
  style: TextStyleSettings;
}

export const TEXT_TEMPLATES: TextPresetTemplate[] = [
  {
    id: 'txt-neon-hero',
    label: 'Electric Neon Title',
    previewBadge: 'NEON GLOW',
    style: {
      text: 'KINETIX STUDIO',
      fontFamily: 'Plus Jakarta Sans',
      fontSize: 54,
      fontWeight: '800',
      color: '#FFFFFF',
      useGradient: true,
      gradientColor2: '#A855F7',
      outlineColor: '#6D28D9',
      outlineWidth: 3,
      shadowColor: '#8B5CF6',
      shadowBlur: 24,
      bgColor: '#09090E',
      bgOpacity: 0,
      animation: 'bounce',
      align: 'center',
      isSubtitle: false,
    },
  },
  {
    id: 'txt-tiktok-caption',
    label: 'Viral Pop Caption',
    previewBadge: 'TIKTOK POP',
    style: {
      text: 'Wait for the drop 🔥⚡',
      fontFamily: 'Plus Jakarta Sans',
      fontSize: 42,
      fontWeight: '800',
      color: '#FACC15',
      useGradient: false,
      gradientColor2: '#F59E0B',
      outlineColor: '#000000',
      outlineWidth: 5,
      shadowColor: '#000000',
      shadowBlur: 12,
      bgColor: '#000000',
      bgOpacity: 0,
      animation: 'bounce',
      align: 'center',
      isSubtitle: true,
    },
  },
  {
    id: 'txt-pill-badge',
    label: 'Glass Pill Callout',
    previewBadge: 'PILL BADGE',
    style: {
      text: 'NEW AI WORKFLOW 2.0',
      fontFamily: 'Inter',
      fontSize: 32,
      fontWeight: '700',
      color: '#F4F4F8',
      useGradient: false,
      gradientColor2: '#EC4899',
      outlineColor: '#8B5CF6',
      outlineWidth: 0,
      shadowColor: '#8B5CF6',
      shadowBlur: 10,
      bgColor: '#7C3AED',
      bgOpacity: 85,
      animation: 'slide-in',
      align: 'center',
      isSubtitle: false,
    },
  },
  {
    id: 'txt-cyber-glitch',
    label: 'Cyber Glitch Header',
    previewBadge: 'GLITCH FX',
    style: {
      text: 'FUTURE // NOW',
      fontFamily: 'JetBrains Mono',
      fontSize: 48,
      fontWeight: '800',
      color: '#22D3EE',
      useGradient: true,
      gradientColor2: '#EC4899',
      outlineColor: '#09090E',
      outlineWidth: 4,
      shadowColor: '#EC4899',
      shadowBlur: 18,
      bgColor: '#09090E',
      bgOpacity: 40,
      animation: 'glitch',
      align: 'center',
      isSubtitle: false,
    },
  },
  {
    id: 'txt-cinema-sub',
    label: 'Cinema Documentary Sub',
    previewBadge: 'SUBTITLE',
    style: {
      text: 'Every frame crafted with precision.',
      fontFamily: 'Inter',
      fontSize: 30,
      fontWeight: '600',
      color: '#FFFFFF',
      useGradient: false,
      gradientColor2: '#FFFFFF',
      outlineColor: '#000000',
      outlineWidth: 2,
      shadowColor: '#000000',
      shadowBlur: 8,
      bgColor: '#09090E',
      bgOpacity: 72,
      animation: 'fade-up',
      align: 'center',
      isSubtitle: true,
    },
  },
];

export const FILTER_PRESETS_INFO: {
  id: FilterPreset;
  name: string;
  desc: string;
  previewGradient: string;
  settings: Partial<ColorGradingSettings>;
}[] = [
  {
    id: 'none',
    name: 'Original Natural',
    desc: 'Unmodified camera color profile',
    previewGradient: 'from-zinc-700 to-zinc-900',
    settings: { brightness: 0, contrast: 0, saturation: 0, hue: 0, temperature: 0, vignette: 0 },
  },
  {
    id: 'cyberpunk',
    name: 'Cyberpunk 2099',
    desc: 'High contrast neon magenta & cyan shift',
    previewGradient: 'from-fuchsia-600 via-purple-700 to-cyan-500',
    settings: { brightness: 6, contrast: 28, saturation: 38, hue: -14, temperature: -18, vignette: 25 },
  },
  {
    id: 'teal-orange',
    name: 'Hollywood Teal & Orange',
    desc: 'Blockbuster warm skin tones & cool shadows',
    previewGradient: 'from-teal-600 via-slate-800 to-amber-500',
    settings: { brightness: 4, contrast: 22, saturation: 20, hue: 8, temperature: 16, vignette: 18 },
  },
  {
    id: 'vintage',
    name: 'Kodachrome 70s',
    desc: 'Warm golden nostalgia with soft blacks',
    previewGradient: 'from-amber-600 via-orange-700 to-stone-800',
    settings: { brightness: 8, contrast: -10, saturation: -18, hue: 12, temperature: 32, vignette: 35 },
  },
  {
    id: 'noir',
    name: 'Obsidian Noir B&W',
    desc: 'Dramatic high-contrast monochrome silver',
    previewGradient: 'from-zinc-200 via-zinc-600 to-black',
    settings: { brightness: -4, contrast: 42, saturation: -100, hue: 0, temperature: 0, vignette: 40 },
  },
  {
    id: 'dreamy',
    name: 'Ethereal Pastel Glow',
    desc: 'Soft highlights with airy violet tint',
    previewGradient: 'from-pink-400 via-purple-400 to-indigo-500',
    settings: { brightness: 14, contrast: -14, saturation: 15, hue: -8, temperature: 10, vignette: 10 },
  },
  {
    id: 'matrix',
    name: 'Bio-Digital Emerald',
    desc: 'Sci-fi green tint with crisp crushed shadows',
    previewGradient: 'from-emerald-500 via-green-800 to-black',
    settings: { brightness: -2, contrast: 30, saturation: 18, hue: 55, temperature: -20, vignette: 30 },
  },
  {
    id: 'bleach',
    name: 'Gritty Bleach Bypass',
    desc: 'Desaturated metallic cinema look',
    previewGradient: 'from-slate-400 via-zinc-700 to-neutral-950',
    settings: { brightness: -6, contrast: 36, saturation: -55, hue: 0, temperature: -12, vignette: 28 },
  },
];

export const TRANSITION_PRESETS: {
  id: TransitionType;
  name: string;
  desc: string;
  badge: string;
}[] = [
  { id: 'none', name: 'Hard Cut', desc: 'Instant frame switch', badge: 'CUT' },
  { id: 'fade', name: 'Cross Dissolve', desc: 'Smooth opacity blend', badge: 'FADE' },
  { id: 'zoom', name: 'Hyper Zoom In', desc: 'Dynamic scale punch transition', badge: 'ZOOM' },
  { id: 'slide-left', name: 'Whip Slide Left', desc: 'Fast horizontal motion whip', badge: 'SLIDE' },
  { id: 'slide-up', name: 'Vertical Rise', desc: 'Smooth upward reveal', badge: 'RISE' },
  { id: 'blur', name: 'Gaussian Flash Blur', desc: 'Defocus dissolve with glow', badge: 'BLUR' },
  { id: 'glitch', name: 'RGB Cyber Glitch', desc: 'Chromatic aberration slice', badge: 'GLITCH' },
  { id: 'spin', name: '360° Vortex Spin', desc: 'Rotational whip transition', badge: 'SPIN' },
];

export const EFFECT_OVERLAY_PRESETS: {
  id: EffectOverlayType;
  name: string;
  desc: string;
  color: string;
}[] = [
  { id: 'vhs', name: 'VHS 1994 Scanlines', desc: 'Retro tracking lines & timecode jitter', color: '#EC4899' },
  { id: 'rgb-split', name: 'Chromatic RGB Split', desc: '3D anaglyph lens edge separation', color: '#22D3EE' },
  { id: 'film-grain', name: '35mm Kodak Grain', desc: 'Organic cinema noise & dust specks', color: '#F59E0B' },
  { id: 'cinema-bars', name: '2.35:1 Anamorphic Scope', desc: 'Widescreen letterbox matte bars', color: '#8B5CF6' },
  { id: 'neon-frame', name: 'Cyber HUD Viewfinder', desc: 'Animated telemetry brackets & REC dot', color: '#10B981' },
  { id: 'light-leak', name: 'Warm Prism Light Leak', desc: 'Anaerobic lens flare sweep', color: '#F97316' },
  { id: 'bokeh-pulse', name: 'Dream Bokeh Particles', desc: 'Floating luminous orb particles', color: '#A855F7' },
];

export const STICKER_PRESETS: { id: string; emoji: string; label: string }[] = [
  { id: 'stk-fire', emoji: '🔥', label: 'Hype Fire' },
  { id: 'stk-zap', emoji: '⚡', label: 'High Voltage' },
  { id: 'stk-heart', emoji: '💜', label: 'Violet Heart' },
  { id: 'stk-rocket', emoji: '🚀', label: 'Launch Boost' },
  { id: 'stk-sparkles', emoji: '✨', label: 'AI Magic' },
  { id: 'stk-target', emoji: '🎯', label: 'Precision Lock' },
  { id: 'stk-crown', emoji: '👑', label: 'Creator Crown' },
  { id: 'stk-eyes', emoji: '👀', label: 'Watch This' },
  { id: 'stk-100', emoji: '💯', label: '100 Score' },
  { id: 'stk-film', emoji: '🎬', label: 'Action Slate' },
  { id: 'stk-headphones', emoji: '🎧', label: 'Bass Drop' },
  { id: 'stk-star', emoji: '🌟', label: 'Superstar' },
];

export function createBaseClip(partial: Partial<TimelineClip> & { id: string; trackId: string; name: string; type: TimelineClip['type'] }): TimelineClip {
  return {
    startTime: 0,
    duration: 4,
    trimStart: 0,
    sourceDuration: 10,
    x: 0,
    y: 0,
    scale: 100,
    rotation: 0,
    opacity: 100,
    flipH: false,
    flipV: false,
    crop: { ...DEFAULT_CROP },
    blendMode: 'source-over',
    backgroundBlurFill: true,
    speed: 1,
    speedRamp: 'constant',
    reverse: false,
    keyframes: [],
    transitionIn: { type: 'none', duration: 0.6 },
    transitionOut: { type: 'none', duration: 0.5 },
    color: { ...DEFAULT_COLOR_GRADING },
    chromaKey: { ...DEFAULT_CHROMA_KEY },
    ...partial,
  };
}

export function createInitialDefaultProject(): ProjectData {
  const clips: TimelineClip[] = [
    createBaseClip({
      id: 'clip-v1-1',
      trackId: 'track-v1',
      mediaId: 'media-neon-city',
      name: 'Cyberpunk Neon Metropolis',
      type: 'video',
      startTime: 0,
      duration: 4.5,
      sourceDuration: 8,
      url: 'https://videos.pexels.com/video-files/8058411/8058411-hd_1920_1080_25fps.mp4',
      thumbnail:
        'https://images.pexels.com/videos/8058411/pexels-photo-8058411.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=240&w=420',
      proceduralPreset: 'neon-city',
      transitionIn: { type: 'fade', duration: 0.6 },
      transitionOut: { type: 'zoom', duration: 0.6 },
      color: { ...DEFAULT_COLOR_GRADING, contrast: 14, saturation: 18 },
    }),
    createBaseClip({
      id: 'clip-v1-2',
      trackId: 'track-v1',
      mediaId: 'media-futuristic-walk',
      name: 'Futuristic Neon Corridor',
      type: 'video',
      startTime: 4.5,
      duration: 4.5,
      sourceDuration: 7,
      url: 'https://videos.pexels.com/video-files/8059305/8059305-hd_1920_1080_25fps.mp4',
      thumbnail:
        'https://images.pexels.com/videos/8059305/pexels-photo-8059305.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=240&w=420',
      proceduralPreset: 'synth-corridor',
      transitionIn: { type: 'glitch', duration: 0.6 },
      transitionOut: { type: 'fade', duration: 0.5 },
      color: { ...DEFAULT_COLOR_GRADING, filterPreset: 'cyberpunk', contrast: 20, saturation: 25 },
    }),
    createBaseClip({
      id: 'clip-v1-3',
      trackId: 'track-v1',
      mediaId: 'media-hyper-tunnel',
      name: 'Hyperdrive Quantum Tunnel',
      type: 'video',
      startTime: 9.0,
      duration: 3.5,
      sourceDuration: 6,
      url: 'procedural://hyper-tunnel',
      thumbnail:
        'https://images.pexels.com/photos/18545010/pexels-photo-18545010.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=200&w=280',
      proceduralPreset: 'hyper-tunnel',
      transitionIn: { type: 'spin', duration: 0.6 },
      transitionOut: { type: 'fade', duration: 0.7 },
    }),
    // Green Screen Chroma Key Overlay on V2
    createBaseClip({
      id: 'clip-v2-chroma',
      trackId: 'track-v2',
      mediaId: 'media-greenscreen-actor',
      name: 'Holo Presenter [Chroma Key Active]',
      type: 'video',
      startTime: 2.0,
      duration: 4.2,
      sourceDuration: 8,
      url: 'procedural://greenscreen-presenter',
      thumbnail:
        'https://images.pexels.com/photos/8726478/pexels-photo-8726478.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=200&w=280',
      proceduralPreset: 'greenscreen-presenter',
      x: 24,
      y: 12,
      scale: 58,
      chromaKey: {
        enabled: true,
        keyColor: '#00FF00',
        similarity: 46,
        smoothness: 16,
        spillSuppression: 20,
      },
      transitionIn: { type: 'slide-up', duration: 0.4 },
      transitionOut: { type: 'fade', duration: 0.4 },
    }),
    // Title & Captions on T1
    createBaseClip({
      id: 'clip-t1-hero',
      trackId: 'track-t1',
      name: 'KINETIX STUDIO // PRO',
      type: 'text',
      startTime: 0.3,
      duration: 3.8,
      sourceDuration: 10,
      y: -28,
      textStyle: {
        ...TEXT_TEMPLATES[0].style,
        text: 'KINETIX // PRO CUT',
      },
      keyframes: [
        { id: 'kf-1', timeOffset: 0, scale: 85, x: 0, y: -28, rotation: 0, opacity: 90 },
        { id: 'kf-2', timeOffset: 1.8, scale: 106, x: 0, y: -25, rotation: 0, opacity: 100 },
      ],
    }),
    createBaseClip({
      id: 'clip-t1-sub1',
      trackId: 'track-t1',
      name: 'Caption: Real-time Chroma & FX',
      type: 'text',
      startTime: 4.5,
      duration: 4.2,
      sourceDuration: 10,
      y: 34,
      textStyle: {
        ...TEXT_TEMPLATES[1].style,
        text: 'Multi-Track Chroma Key & AI Sync ⚡',
      },
    }),
    createBaseClip({
      id: 'clip-t1-outro',
      trackId: 'track-t1',
      name: 'Caption: Export in 4K 60FPS',
      type: 'text',
      startTime: 9.0,
      duration: 3.3,
      sourceDuration: 10,
      y: 0,
      textStyle: {
        ...TEXT_TEMPLATES[3].style,
        text: 'RENDER READY • 60FPS',
      },
    }),
    // Effect Overlay on FX1
    createBaseClip({
      id: 'clip-fx1-1',
      trackId: 'track-fx1',
      name: 'Cyber HUD Viewfinder',
      type: 'effect',
      startTime: 0,
      duration: 6.5,
      sourceDuration: 12,
      effectOverlayType: 'neon-frame',
    }),
    createBaseClip({
      id: 'clip-fx1-2',
      trackId: 'track-fx1',
      name: 'Chromatic RGB Split',
      type: 'effect',
      startTime: 6.5,
      duration: 6.0,
      sourceDuration: 12,
      effectOverlayType: 'rgb-split',
    }),
    // Background Music on A1
    createBaseClip({
      id: 'clip-a1-music',
      trackId: 'track-a1',
      mediaId: 'audio-synthwave',
      name: 'Midnight Hyperdrive (128 BPM)',
      type: 'audio',
      startTime: 0,
      duration: 12.5,
      sourceDuration: 16,
      url: 'synth://synthwave-128',
      proceduralPreset: 'synthwave-128',
      waveform: DEFAULT_MEDIA_LIBRARY.find((m) => m.id === 'audio-synthwave')?.waveform,
      audioSettings: {
        volume: 85,
        fadeIn: 0.6,
        fadeOut: 1.4,
        noiseReduction: false,
        voiceEnhance: false,
      },
    }),
    // SFX on A2
    createBaseClip({
      id: 'clip-a2-sfx1',
      trackId: 'track-a2',
      mediaId: 'audio-sfx-whoosh',
      name: 'Cyber Whoosh Transition',
      type: 'audio',
      startTime: 4.1,
      duration: 1.4,
      sourceDuration: 1.5,
      url: 'synth://sfx-whoosh',
      proceduralPreset: 'sfx-whoosh',
      waveform: DEFAULT_MEDIA_LIBRARY.find((m) => m.id === 'audio-sfx-whoosh')?.waveform,
      audioSettings: {
        volume: 110,
        fadeIn: 0.1,
        fadeOut: 0.2,
        noiseReduction: false,
        voiceEnhance: false,
      },
    }),
  ];

  // Generate 128 BPM beat markers (every 0.46875s * 2 = 0.9375s bar accent)
  const beatMarkers: number[] = [];
  for (let t = 0.9375; t < 12.5; t += 0.9375) {
    beatMarkers.push(Number(t.toFixed(2)));
  }

  return {
    id: 'proj-default-cyber',
    name: 'Cyberpunk Launch Reel 2026',
    updatedAt: Date.now(),
    thumbnail:
      'https://images.pexels.com/videos/8058411/pexels-photo-8058411.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=240&w=420',
    aspectRatio: '16:9',
    fps: 60,
    resolution: '1080p',
    tracks: DEFAULT_TRACKS.map((t) => ({ ...t })),
    clips,
    beatMarkers,
  };
}

export interface StarterTemplateCard {
  id: string;
  title: string;
  category: string;
  aspectRatio: ProjectData['aspectRatio'];
  durationLabel: string;
  thumbnail: string;
  badge: string;
  buildProject: () => ProjectData;
}

export const STARTER_TEMPLATES: StarterTemplateCard[] = [
  {
    id: 'tpl-tiktok-reel',
    title: 'Viral TikTok / Reels Beat-Cut',
    category: 'Vertical Short • 9:16',
    aspectRatio: '9:16',
    durationLabel: '00:10',
    thumbnail:
      'https://images.pexels.com/photos/12789661/pexels-photo-12789661.png?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=320&w=220',
    badge: '9:16 REEL',
    buildProject: () => {
      const base = createInitialDefaultProject();
      return {
        ...base,
        id: 'proj-tpl-' + Date.now(),
        name: 'TikTok High-Energy Beat Edit',
        aspectRatio: '9:16',
        updatedAt: Date.now(),
      };
    },
  },
  {
    id: 'tpl-youtube-cinema',
    title: 'Cyberpunk Widescreen Showcase',
    category: 'YouTube 4K • 16:9',
    aspectRatio: '16:9',
    durationLabel: '00:12',
    thumbnail:
      'https://images.pexels.com/videos/8058411/pexels-photo-8058411.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=240&w=420',
    badge: '16:9 PRO',
    buildProject: () => {
      const base = createInitialDefaultProject();
      return {
        ...base,
        id: 'proj-tpl-' + Date.now(),
        name: 'Cyberpunk Widescreen Showcase',
        aspectRatio: '16:9',
        updatedAt: Date.now(),
      };
    },
  },
  {
    id: 'tpl-chroma-studio',
    title: 'Green-Screen Chroma Key VFX Lab',
    category: 'Compositing • 16:9',
    aspectRatio: '16:9',
    durationLabel: '00:08',
    thumbnail:
      'https://images.pexels.com/photos/8726478/pexels-photo-8726478.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=240&w=420',
    badge: 'CHROMA KEY',
    buildProject: () => {
      const base = createInitialDefaultProject();
      base.clips = base.clips.map((c) =>
        c.id === 'clip-v2-chroma'
          ? { ...c, startTime: 0.4, duration: 7.5, scale: 78, x: 0, y: 6 }
          : c
      );
      return {
        ...base,
        id: 'proj-tpl-' + Date.now(),
        name: 'Chroma Key VFX Composite',
        updatedAt: Date.now(),
      };
    },
  },
];
