import { useState, useEffect, useRef, useCallback } from 'react';
import {
  AIProposal,
  AspectRatioOption,
  EffectOverlayType,
  FilterPreset,
  FPSOption,
  LeftRailTab,
  MediaItem,
  ProjectData,
  TextStyleSettings,
  TimelineClip,
  TimelineTrack,
  TrackType,
  TransitionType,
} from './types/editor';
import {
  createBaseClip,
  createInitialDefaultProject,
  DEFAULT_MEDIA_LIBRARY,
  DEFAULT_TRACKS,
  TEXT_TEMPLATES,
} from './data/presets';
import {
  computeClipLocalTime,
  getCanvasDimensions,
  renderCompositeFrame,
} from './engine/canvasCompositor';
import { studioAudioEngine } from './engine/audioEngine';
import { TopBar } from './components/TopBar';
import { LeftAssetDrawer } from './components/LeftAssetDrawer';
import { CenterPreviewStage } from './components/CenterPreviewStage';
import { RightInspector } from './components/RightInspector';
import { MultiTrackTimeline } from './components/MultiTrackTimeline';
import { HomeDashboardModal } from './components/HomeDashboardModal';
import { ExportModal } from './components/ExportModal';
import { Layers, Sliders, Film, Sparkles } from 'lucide-react';

const STORAGE_KEY_PROJECTS = 'kinetix_studio_projects_v2';

export function App() {
  // Saved Projects in localStorage
  const [savedProjects, setSavedProjects] = useState<ProjectData[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_PROJECTS);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // Ignore storage error
    }
    return [createInitialDefaultProject()];
  });

  // Active Project State
  const [project, setProject] = useState<ProjectData>(() => savedProjects[0]);
  const [mediaLibrary, setMediaLibrary] = useState<MediaItem[]>(DEFAULT_MEDIA_LIBRARY);

  // Undo / Redo History Stack
  const [undoStack, setUndoStack] = useState<ProjectData[]>([]);
  const [redoStack, setRedoStack] = useState<ProjectData[]>([]);

  // UI & Playback State
  const [activeTab, setActiveTab] = useState<LeftRailTab>('media');
  const [selectedClipId, setSelectedClipId] = useState<string | null>('clip-v2-chroma');
  const [currentTime, setCurrentTime] = useState<number>(2.4);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isLooping, setIsLooping] = useState<boolean>(true);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [showSafeGuides, setShowSafeGuides] = useState<boolean>(false);
  const [zoomPxPerSec, setZoomPxPerSec] = useState<number>(68);
  const [snapEnabled, setSnapEnabled] = useState<boolean>(true);
  const [vuLevels, setVuLevels] = useState<{ leftLevel: number; rightLevel: number }>({
    leftLevel: 0,
    rightLevel: 0,
  });

  // Modals & Responsive Mobile View Switcher
  const [isDashboardOpen, setIsDashboardOpen] = useState<boolean>(false);
  const [isExportOpen, setIsExportOpen] = useState<boolean>(false);
  const [activeAIProposal, setActiveAIProposal] = useState<AIProposal | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [lastSavedText, setLastSavedText] = useState<string>('Autosaved');
  const [mobileDrawerMode, setMobileDrawerMode] = useState<'stage' | 'assets' | 'inspector'>('stage');

  // Canvas & Media Element Refs
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const videoElementsRef = useRef<Map<string, HTMLVideoElement>>(new Map());
  const imageElementsRef = useRef<Map<string, HTMLImageElement>>(new Map());
  const lastFrameTsRef = useRef<number | null>(null);

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    window.setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3200);
  }, []);

  // Compute total timeline duration from clips
  const totalDuration = Math.max(
    4,
    project.clips.reduce((max, c) => Math.max(max, c.startTime + c.duration), 0)
  );

  const selectedClip = project.clips.find((c) => c.id === selectedClipId) || null;

  // Record Undo History Snapshot before mutating project
  const updateProjectWithHistory = useCallback(
    (updater: (prev: ProjectData) => ProjectData, recordUndo = true) => {
      setProject((prev) => {
        if (recordUndo) {
          setUndoStack((u) => [...u.slice(-29), prev]);
          setRedoStack([]);
        }
        const next = { ...updater(prev), updatedAt: Date.now() };
        return next;
      });
    },
    []
  );

  // Undo & Redo Handlers
  const handleUndo = useCallback(() => {
    if (undoStack.length === 0) return;
    const prevSnapshot = undoStack[undoStack.length - 1];
    setUndoStack((u) => u.slice(0, -1));
    setRedoStack((r) => [...r, project]);
    setProject(prevSnapshot);
    showToast('Undid last action');
  }, [undoStack, project, showToast]);

  const handleRedo = useCallback(() => {
    if (redoStack.length === 0) return;
    const nextSnapshot = redoStack[redoStack.length - 1];
    setRedoStack((r) => r.slice(0, -1));
    setUndoStack((u) => [...u, project]);
    setProject(nextSnapshot);
    showToast('Redid action');
  }, [redoStack, project, showToast]);

  // Autosave to localStorage
  useEffect(() => {
    setSavedProjects((prevList) => {
      const exists = prevList.some((p) => p.id === project.id);
      const nextList = exists
        ? prevList.map((p) => (p.id === project.id ? project : p))
        : [project, ...prevList];
      try {
        localStorage.setItem(STORAGE_KEY_PROJECTS, JSON.stringify(nextList));
      } catch {
        // Ignore quota errors
      }
      return nextList;
    });
    setLastSavedText('Autosaved');
  }, [project]);

  // Sync HTMLVideoElement & HTMLImageElement Pool for active clips
  useEffect(() => {
    const vidMap = videoElementsRef.current;
    const imgMap = imageElementsRef.current;

    for (const clip of project.clips) {
      if (
        clip.type === 'video' &&
        clip.url &&
        !clip.url.startsWith('procedural://') &&
        !vidMap.has(clip.id)
      ) {
        const vid = document.createElement('video');
        vid.src = clip.url;
        vid.crossOrigin = 'anonymous';
        vid.muted = true;
        vid.playsInline = true;
        vid.preload = 'auto';
        vid.load();
        vidMap.set(clip.id, vid);
      } else if (clip.type === 'image' && clip.url && !imgMap.has(clip.id)) {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.src = clip.url;
        imgMap.set(clip.id, img);
      }
    }
  }, [project.clips]);

  // Sync video element seek positions when scrubbing or playing
  useEffect(() => {
    const vidMap = videoElementsRef.current;
    for (const clip of project.clips) {
      if (clip.type !== 'video') continue;
      const vid = vidMap.get(clip.id);
      if (!vid || vid.readyState < 1) continue;

      const isInside =
        currentTime >= clip.startTime && currentTime <= clip.startTime + clip.duration;
      if (isInside) {
        const targetSourceTime =
          computeClipLocalTime(clip, currentTime) % Math.max(1, vid.duration || clip.sourceDuration || 8);
        if (Math.abs(vid.currentTime - targetSourceTime) > 0.28) {
          try {
            vid.currentTime = targetSourceTime;
          } catch {
            // Ignore seek error
          }
        }
        if (isPlaying && vid.paused && !clip.reverse) {
          vid.playbackRate = Math.max(0.25, Math.min(4, clip.speed));
          vid.play().catch(() => {});
        } else if (!isPlaying && !vid.paused) {
          vid.pause();
        }
      } else if (!vid.paused) {
        vid.pause();
      }
    }
  }, [currentTime, isPlaying, project.clips]);

  // Main 60fps Playback & Canvas Render Loop
  useEffect(() => {
    let animId = 0;

    const renderTick = (timestamp: number) => {
      if (isPlaying) {
        if (lastFrameTsRef.current !== null) {
          const dt = (timestamp - lastFrameTsRef.current) / 1000;
          setCurrentTime((prevTime) => {
            const nextTime = prevTime + dt;
            if (nextTime >= totalDuration) {
              if (isLooping) {
                studioAudioEngine.resetTriggers();
                return 0;
              } else {
                setIsPlaying(false);
                return totalDuration;
              }
            }
            return nextTime;
          });
        }
        lastFrameTsRef.current = timestamp;
      } else {
        lastFrameTsRef.current = null;
      }

      // Draw Composite Frame to Canvas
      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          const dims = getCanvasDimensions(project.aspectRatio, 720);
          if (canvas.width !== dims.width || canvas.height !== dims.height) {
            canvas.width = dims.width;
            canvas.height = dims.height;
          }

          renderCompositeFrame({
            ctx,
            width: canvas.width,
            height: canvas.height,
            timelineTime: currentTime,
            tracks: project.tracks,
            clips: project.clips,
            videoElements: videoElementsRef.current,
            imageElements: imageElementsRef.current,
            selectedClipId,
            showSafeGuides,
          });
        }
      }

      // Tick Audio Engine & VU Meter
      const levels = studioAudioEngine.tickPlayback({
        timelineTime: currentTime,
        isPlaying,
        tracks: project.tracks,
        clips: project.clips,
        isMuted,
      });
      setVuLevels(levels);

      animId = requestAnimationFrame(renderTick);
    };

    animId = requestAnimationFrame(renderTick);
    return () => cancelAnimationFrame(animId);
  }, [
    isPlaying,
    isLooping,
    isMuted,
    currentTime,
    totalDuration,
    project.aspectRatio,
    project.tracks,
    project.clips,
    selectedClipId,
    showSafeGuides,
  ]);

  // Core Clip Operations: Update, Split, Merge, Duplicate, Delete
  const handleUpdateClip = useCallback(
    (id: string, patch: Partial<TimelineClip>, recordHistory = true) => {
      updateProjectWithHistory(
        (prev) => ({
          ...prev,
          clips: prev.clips.map((c) => (c.id === id ? { ...c, ...patch } : c)),
        }),
        recordHistory
      );
    },
    [updateProjectWithHistory]
  );

  const handleSplitAtPlayhead = useCallback(() => {
    // Find selected clip if playhead is inside it, else find top clip under playhead
    const target =
      project.clips.find(
        (c) =>
          c.id === selectedClipId &&
          currentTime > c.startTime + 0.25 &&
          currentTime < c.startTime + c.duration - 0.25
      ) ||
      project.clips.find(
        (c) =>
          currentTime > c.startTime + 0.25 &&
          currentTime < c.startTime + c.duration - 0.25
      );

    if (!target) {
      showToast('Move playhead inside a clip to Split (S)');
      return;
    }

    const splitOffset = Number((currentTime - target.startTime).toFixed(2));
    const secondDuration = Number((target.duration - splitOffset).toFixed(2));

    const firstHalf: TimelineClip = {
      ...target,
      duration: splitOffset,
    };

    const secondHalf: TimelineClip = {
      ...target,
      id: 'clip-' + Date.now(),
      name: `${target.name} (Part 2)`,
      startTime: Number(currentTime.toFixed(2)),
      duration: secondDuration,
      trimStart: Number((target.trimStart + splitOffset).toFixed(2)),
      keyframes: [],
    };

    updateProjectWithHistory((prev) => ({
      ...prev,
      clips: prev.clips.flatMap((c) => (c.id === target.id ? [firstHalf, secondHalf] : [c])),
    }));
    setSelectedClipId(secondHalf.id);
    showToast(`Split "${target.name}" at ${currentTime.toFixed(2)}s`);
  }, [project.clips, selectedClipId, currentTime, updateProjectWithHistory, showToast]);

  const handleMergeAdjacentClips = useCallback(() => {
    if (!selectedClip) {
      showToast('Select a clip to merge with its neighbor on the same track');
      return;
    }
    const sameTrackClips = project.clips
      .filter((c) => c.trackId === selectedClip.trackId)
      .sort((a, b) => a.startTime - b.startTime);

    const idx = sameTrackClips.findIndex((c) => c.id === selectedClip.id);
    const neighbor = sameTrackClips[idx + 1] || sameTrackClips[idx - 1];
    if (!neighbor) {
      showToast('No adjacent clip found on this track to merge');
      return;
    }

    const first = selectedClip.startTime <= neighbor.startTime ? selectedClip : neighbor;
    const second = first.id === selectedClip.id ? neighbor : selectedClip;
    const mergedDuration = Number(
      (second.startTime + second.duration - first.startTime).toFixed(2)
    );

    updateProjectWithHistory((prev) => ({
      ...prev,
      clips: prev.clips
        .filter((c) => c.id !== second.id)
        .map((c) =>
          c.id === first.id
            ? { ...c, duration: mergedDuration, name: `${first.name} + Merged` }
            : c
        ),
    }));
    setSelectedClipId(first.id);
    showToast('Merged adjacent clips on track');
  }, [selectedClip, project.clips, updateProjectWithHistory, showToast]);

  const handleDuplicateClip = useCallback(
    (id?: string) => {
      const targetId = id || selectedClipId;
      const orig = project.clips.find((c) => c.id === targetId);
      if (!orig) return;

      const copy: TimelineClip = {
        ...orig,
        id: 'clip-' + Date.now(),
        name: `${orig.name} (Copy)`,
        startTime: Number((orig.startTime + orig.duration).toFixed(2)),
      };
      updateProjectWithHistory((prev) => ({
        ...prev,
        clips: [...prev.clips, copy],
      }));
      setSelectedClipId(copy.id);
      showToast(`Duplicated "${orig.name}"`);
    },
    [selectedClipId, project.clips, updateProjectWithHistory, showToast]
  );

  const handleDeleteClip = useCallback(
    (id?: string) => {
      const targetId = id || selectedClipId;
      if (!targetId) return;
      updateProjectWithHistory((prev) => ({
        ...prev,
        clips: prev.clips.filter((c) => c.id !== targetId),
      }));
      if (selectedClipId === targetId) setSelectedClipId(null);
      showToast('Deleted clip from timeline');
    },
    [selectedClipId, updateProjectWithHistory, showToast]
  );

  // Global Keyboard Shortcuts (Space, S, M, D, Delete, Arrows, Ctrl+Z, Ctrl+Y)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;

      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        if (e.shiftKey) handleRedo();
        else handleUndo();
        return;
      }
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'y') {
        e.preventDefault();
        handleRedo();
        return;
      }

      if (e.code === 'Space') {
        e.preventDefault();
        studioAudioEngine.ensureContext();
        setIsPlaying((p) => !p);
      } else if (e.key.toLowerCase() === 's') {
        e.preventDefault();
        handleSplitAtPlayhead();
      } else if (e.key.toLowerCase() === 'm') {
        e.preventDefault();
        handleMergeAdjacentClips();
      } else if (e.key.toLowerCase() === 'd') {
        e.preventDefault();
        handleDuplicateClip();
      } else if (e.key === 'Delete' || e.key === 'Backspace') {
        e.preventDefault();
        handleDeleteClip();
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        setIsPlaying(false);
        setCurrentTime((t) => Math.max(0, t - 1 / project.fps));
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        setIsPlaying(false);
        setCurrentTime((t) => Math.min(totalDuration, t + 1 / project.fps));
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [
    handleUndo,
    handleRedo,
    handleSplitAtPlayhead,
    handleMergeAdjacentClips,
    handleDuplicateClip,
    handleDeleteClip,
    project.fps,
    totalDuration,
  ]);

  // Import Local User Files (Video, Image, Audio)
  const handleImportFiles = (files: FileList) => {
    Array.from(files).forEach((file) => {
      const url = URL.createObjectURL(file);
      const isVideo = file.type.startsWith('video/');
      const isImage = file.type.startsWith('image/');
      const isAudio = file.type.startsWith('audio/');

      if (isVideo) {
        const tempVid = document.createElement('video');
        tempVid.src = url;
        tempVid.onloadedmetadata = () => {
          const dur = Math.max(1, Number((tempVid.duration || 6).toFixed(1)));
          const newItem: MediaItem = {
            id: 'media-user-' + Date.now() + Math.random().toString(36).slice(2, 6),
            name: file.name.replace(/\.[^/.]+$/, ''),
            type: 'video',
            url,
            thumbnail:
              'https://images.pexels.com/photos/18545010/pexels-photo-18545010.jpeg?auto=compress&cs=tinysrgb&dpr=1&fit=crop&h=200&w=280',
            duration: dur,
            width: tempVid.videoWidth || 1920,
            height: tempVid.videoHeight || 1080,
          };
          setMediaLibrary((prev) => [newItem, ...prev]);
          showToast(`Imported video "${newItem.name}" (${dur}s)`);
        };
      } else if (isImage) {
        const newItem: MediaItem = {
          id: 'media-user-' + Date.now() + Math.random().toString(36).slice(2, 6),
          name: file.name.replace(/\.[^/.]+$/, ''),
          type: 'image',
          url,
          thumbnail: url,
          duration: 5,
          width: 1920,
          height: 1080,
        };
        setMediaLibrary((prev) => [newItem, ...prev]);
        showToast(`Imported image "${newItem.name}"`);
      } else if (isAudio) {
        const newItem: MediaItem = {
          id: 'audio-user-' + Date.now() + Math.random().toString(36).slice(2, 6),
          name: file.name.replace(/\.[^/.]+$/, ''),
          type: 'audio',
          url,
          thumbnail: '',
          duration: 10,
          width: 0,
          height: 0,
          audioCategory: 'music',
          waveform: Array.from({ length: 60 }, (_, i) => 0.25 + 0.55 * Math.abs(Math.sin(i * 0.4))),
        };
        setMediaLibrary((prev) => [newItem, ...prev]);
        setActiveTab('audio');
        showToast(`Imported audio "${newItem.name}"`);
      }
    });
  };

  // Add Media Item to Timeline
  const handleAddMediaToTimeline = (
    media: MediaItem,
    targetTrackId?: string,
    customStartTime?: number
  ) => {
    const resolvedTrackId =
      targetTrackId ||
      (media.type === 'audio'
        ? media.audioCategory === 'sfx'
          ? 'track-a2'
          : 'track-a1'
        : media.isGreenScreen
        ? 'track-v2'
        : 'track-v1');

    const trackClips = project.clips.filter((c) => c.trackId === resolvedTrackId);
    const trackEnd = trackClips.reduce((m, c) => Math.max(m, c.startTime + c.duration), 0);
    const startTime =
      typeof customStartTime === 'number'
        ? customStartTime
        : resolvedTrackId === 'track-v2' || resolvedTrackId === 'track-a2'
        ? Number(currentTime.toFixed(2))
        : Number(trackEnd.toFixed(2));

    const newClip = createBaseClip({
      id: 'clip-' + Date.now() + Math.random().toString(36).slice(2, 5),
      trackId: resolvedTrackId,
      mediaId: media.id,
      name: media.name,
      type: media.type,
      startTime,
      duration: media.duration,
      sourceDuration: media.duration,
      url: media.url,
      thumbnail: media.thumbnail,
      proceduralPreset: media.proceduralPreset,
      waveform: media.waveform,
      scale: media.isGreenScreen ? 68 : 100,
      chromaKey: media.isGreenScreen
        ? {
            enabled: true,
            keyColor: '#00FF00',
            similarity: 46,
            smoothness: 16,
            spillSuppression: 20,
          }
        : {
            enabled: false,
            keyColor: '#00FF00',
            similarity: 42,
            smoothness: 14,
            spillSuppression: 18,
          },
      audioSettings:
        media.type === 'audio'
          ? {
              volume: 95,
              fadeIn: 0.2,
              fadeOut: 0.4,
              noiseReduction: false,
              voiceEnhance: false,
            }
          : undefined,
    });

    updateProjectWithHistory((prev) => ({
      ...prev,
      clips: [...prev.clips, newClip],
    }));
    setSelectedClipId(newClip.id);
    showToast(`Added "${media.name}" to timeline`);
  };

  // Add Text Clip
  const handleAddTextClip = (style: TextStyleSettings, label: string) => {
    const newClip = createBaseClip({
      id: 'clip-txt-' + Date.now(),
      trackId: 'track-t1',
      name: label,
      type: 'text',
      startTime: Number(currentTime.toFixed(2)),
      duration: 3.5,
      sourceDuration: 10,
      y: style.isSubtitle ? 34 : 0,
      textStyle: { ...style },
    });
    updateProjectWithHistory((prev) => ({
      ...prev,
      clips: [...prev.clips, newClip],
    }));
    setSelectedClipId(newClip.id);
    showToast(`Added "${label}" on Track T1`);
  };

  // Add Effect Overlay Clip
  const handleAddEffectOverlay = (overlayType: EffectOverlayType, name: string) => {
    const newClip = createBaseClip({
      id: 'clip-fx-' + Date.now(),
      trackId: 'track-fx1',
      name,
      type: 'effect',
      startTime: Number(currentTime.toFixed(2)),
      duration: 4.5,
      sourceDuration: 15,
      effectOverlayType: overlayType,
    });
    updateProjectWithHistory((prev) => ({
      ...prev,
      clips: [...prev.clips, newClip],
    }));
    setSelectedClipId(newClip.id);
    showToast(`Added VFX "${name}" on Track FX1`);
  };

  // Add Sticker Clip
  const handleAddStickerClip = (emoji: string, label: string) => {
    const newClip = createBaseClip({
      id: 'clip-stk-' + Date.now(),
      trackId: 'track-fx1',
      name: label,
      type: 'sticker',
      startTime: Number(currentTime.toFixed(2)),
      duration: 3.5,
      sourceDuration: 10,
      stickerEmoji: emoji,
      x: 25,
      y: -22,
    });
    updateProjectWithHistory((prev) => ({
      ...prev,
      clips: [...prev.clips, newClip],
    }));
    setSelectedClipId(newClip.id);
    showToast(`Added ${emoji} "${label}" sticker`);
  };

  // Apply Color Filter Preset
  const handleApplyFilter = (preset: FilterPreset, applyAll: boolean) => {
    updateProjectWithHistory((prev) => ({
      ...prev,
      clips: prev.clips.map((c) => {
        if (c.type !== 'video' && c.type !== 'image') return c;
        if (!applyAll && selectedClipId && c.id !== selectedClipId) return c;
        return {
          ...c,
          color: { ...c.color, filterPreset: preset },
        };
      }),
    }));
    showToast(`Applied ${preset.toUpperCase()} color grade`);
  };

  // Apply Transition
  const handleApplyTransition = (
    type: TransitionType,
    duration: number,
    applyAll: boolean
  ) => {
    updateProjectWithHistory((prev) => ({
      ...prev,
      clips: prev.clips.map((c) => {
        if (c.type !== 'video' && c.type !== 'image') return c;
        if (!applyAll && selectedClipId && c.id !== selectedClipId) return c;
        return {
          ...c,
          transitionIn: { type, duration },
          transitionOut: { type, duration },
        };
      }),
    }));
    showToast(
      applyAll
        ? `Applied ${type.toUpperCase()} transition to all video cuts`
        : `Applied ${type.toUpperCase()} transition to clip`
    );
  };

  // Generate Timed Auto-Captions across Timeline
  const handleGenerateAutoCaptions = () => {
    const phrases = [
      { start: 0.2, dur: 2.8, text: 'Welcome to Kinetix Studio ⚡' },
      { start: 3.1, dur: 3.0, text: 'Real-Time Chroma Key & LUTs 🎬' },
      { start: 6.2, dur: 3.0, text: 'Beat-Synced Multi-Track Editing 🔥' },
      { start: 9.3, dur: 3.0, text: 'Export in 4K 60FPS Ready 🚀' },
    ];

    const generated: TimelineClip[] = phrases.map((p, idx) =>
      createBaseClip({
        id: `clip-autocap-${Date.now()}-${idx}`,
        trackId: 'track-t1',
        name: p.text,
        type: 'text',
        startTime: p.start,
        duration: p.dur,
        sourceDuration: 10,
        y: 35,
        textStyle: {
          ...TEXT_TEMPLATES[1].style,
          text: p.text,
        },
      })
    );

    updateProjectWithHistory((prev) => ({
      ...prev,
      clips: [
        ...prev.clips.filter((c) => !c.id.startsWith('clip-autocap-')),
        ...generated,
      ],
    }));
    setSelectedClipId(generated[0].id);
    showToast('Generated 4 AI synchronized captions on Track T1');
  };

  // Add Recorded or TTS Voiceover Clip on Track A2
  const handleAddVoiceoverClip = (
    url: string,
    duration: number,
    label: string,
    ttsText?: string
  ) => {
    const newVo = createBaseClip({
      id: 'clip-vo-' + Date.now(),
      trackId: 'track-a2',
      name: label,
      type: 'audio',
      startTime: Number(currentTime.toFixed(2)),
      duration,
      sourceDuration: duration,
      url,
      proceduralPreset: 'lofi-92',
      waveform: Array.from({ length: 48 }, (_, i) =>
        Number((0.3 + 0.6 * Math.abs(Math.sin(i * 0.65))).toFixed(2))
      ),
      audioSettings: {
        volume: 120,
        fadeIn: 0.1,
        fadeOut: 0.2,
        noiseReduction: true,
        voiceEnhance: true,
        ttsText,
      },
    });
    updateProjectWithHistory((prev) => ({
      ...prev,
      clips: [...prev.clips, newVo],
    }));
    setSelectedClipId(newVo.id);
    showToast(`Added "${label}" to Track A2`);
  };

  // Generate Beat Markers & Snap Clips to Beats
  const handleSyncBeatMarkers = (bpm: number) => {
    const step = Number(((60 / bpm) * 2).toFixed(2));
    const markers: number[] = [];
    for (let t = step; t < totalDuration + 2; t += step) {
      markers.push(Number(t.toFixed(2)));
    }
    updateProjectWithHistory((prev) => ({
      ...prev,
      beatMarkers: markers,
    }));
    showToast(`Detected & placed ${markers.length} beat markers (${bpm} BPM)`);
  };

  const handleSnapClipsToBeats = () => {
    if (project.beatMarkers.length === 0) {
      handleSyncBeatMarkers(128);
    }
    updateProjectWithHistory((prev) => {
      const beats = [0, ...prev.beatMarkers];
      const nearestBeat = (val: number) => {
        let best = val;
        let minDiff = 999;
        for (const b of beats) {
          const d = Math.abs(val - b);
          if (d < minDiff) {
            minDiff = d;
            best = b;
          }
        }
        return best;
      };
      return {
        ...prev,
        clips: prev.clips.map((c) => {
          if (c.trackId !== 'track-v1') return c;
          const snappedStart = nearestBeat(c.startTime);
          return {
            ...c,
            startTime: snappedStart,
            transitionIn: { type: 'zoom', duration: 0.5 },
          };
        }),
      };
    });
    showToast('Snapped Track V1 cuts to nearest musical beat markers!');
  };

  // Approve & Execute AI Studio Proposal
  const handleApproveAIProposal = (proposal: AIProposal) => {
    if (proposal.actionType === 'beat-sync-edit') {
      handleSnapClipsToBeats();
    } else if (proposal.actionType === 'auto-captions') {
      handleGenerateAutoCaptions();
    } else if (proposal.actionType === 'smart-reframe' && proposal.targetAspectRatio) {
      updateProjectWithHistory((prev) => ({
        ...prev,
        aspectRatio: proposal.targetAspectRatio!,
        clips: prev.clips.map((c) => ({
          ...c,
          backgroundBlurFill: true,
        })),
      }));
      showToast(`Smart-reframed canvas to ${proposal.targetAspectRatio}`);
    } else if (proposal.actionType === 'background-remove') {
      updateProjectWithHistory((prev) => ({
        ...prev,
        clips: prev.clips.map((c) =>
          c.trackId === 'track-v2' || c.proceduralPreset === 'greenscreen-presenter'
            ? {
                ...c,
                chromaKey: {
                  enabled: true,
                  keyColor: '#00FF00',
                  similarity: 48,
                  smoothness: 16,
                  spillSuppression: 22,
                },
              }
            : c
        ),
      }));
      showToast('Activated AI Chroma Key compositing on Track V2');
    } else if (proposal.actionType === 'highlight-trim') {
      updateProjectWithHistory((prev) => ({
        ...prev,
        clips: prev.clips.map((c) =>
          c.trackId === 'track-v1'
            ? {
                ...c,
                speedRamp: 'montage',
                color: { ...c.color, contrast: 18, saturation: 24 },
              }
            : c
        ),
      }));
      showToast('Applied Montage Speed Ramp & Highlight Enhancement');
    } else if (proposal.actionType === 'cyberpunk-grade') {
      handleApplyFilter('cyberpunk', true);
      handleAddEffectOverlay('cinema-bars', '2.35:1 Anamorphic Scope');
    }

    setActiveAIProposal(null);
  };

  // Track Management
  const handleToggleTrackFlag = (
    trackId: string,
    flag: 'muted' | 'locked' | 'hidden'
  ) => {
    updateProjectWithHistory((prev) => ({
      ...prev,
      tracks: prev.tracks.map((t) =>
        t.id === trackId ? { ...t, [flag]: !t[flag] } : t
      ),
    }));
  };

  const handleAddTrack = (type: TrackType) => {
    const count = project.tracks.filter((t) => t.type === type).length + 1;
    const prefix =
      type === 'video' ? 'V' : type === 'audio' ? 'A' : type === 'text' ? 'T' : 'FX';
    const newTrack: TimelineTrack = {
      id: `track-${type}-${Date.now()}`,
      name: `${prefix}${count} • Custom ${type.toUpperCase()}`,
      type,
      muted: false,
      locked: false,
      hidden: false,
    };
    updateProjectWithHistory((prev) => ({
      ...prev,
      tracks: [newTrack, ...prev.tracks],
    }));
    showToast(`Added track "${newTrack.name}"`);
  };

  // Project Management (New, Duplicate, Delete, Export JSON)
  const handleCreateNewProject = (aspectRatio: AspectRatioOption, title?: string) => {
    const blank: ProjectData = {
      id: 'proj-' + Date.now(),
      name: title || `New ${aspectRatio} Project`,
      updatedAt: Date.now(),
      aspectRatio,
      fps: 60,
      resolution: '1080p',
      tracks: DEFAULT_TRACKS.map((t) => ({ ...t })),
      clips: [
        createBaseClip({
          id: 'clip-init-' + Date.now(),
          trackId: 'track-v1',
          mediaId: 'media-neon-city',
          name: 'Cyberpunk Neon Metropolis',
          type: 'video',
          startTime: 0,
          duration: 5,
          sourceDuration: 8,
          url: 'https://videos.pexels.com/video-files/8058411/8058411-hd_1920_1080_25fps.mp4',
          thumbnail:
            'https://images.pexels.com/videos/8058411/pexels-photo-8058411.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=240&w=420',
          proceduralPreset: 'neon-city',
        }),
      ],
      beatMarkers: [0.94, 1.88, 2.81, 3.75],
    };
    setProject(blank);
    setCurrentTime(0);
    setUndoStack([]);
    setRedoStack([]);
    showToast(`Created new ${aspectRatio} project`);
  };

  const handleExportCurrentProjectJson = () => {
    const blob = new Blob([JSON.stringify(project, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${project.name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.kinetix.json`;
    a.click();
    showToast('Exported .kinetix.json project file');
  };

  return (
    <div className="h-screen w-screen overflow-hidden flex flex-col bg-[#09090E] text-[#F4F4F8]">
      {/* Top Studio Bar */}
      <TopBar
        projectName={project.name}
        onChangeProjectName={(name) =>
          updateProjectWithHistory((prev) => ({ ...prev, name }), false)
        }
        aspectRatio={project.aspectRatio}
        onChangeAspectRatio={(ar) =>
          updateProjectWithHistory((prev) => ({ ...prev, aspectRatio: ar }))
        }
        fps={project.fps}
        onChangeFps={(fps: FPSOption) =>
          updateProjectWithHistory((prev) => ({ ...prev, fps }))
        }
        canUndo={undoStack.length > 0}
        canRedo={redoStack.length > 0}
        onUndo={handleUndo}
        onRedo={handleRedo}
        onOpenDashboard={() => setIsDashboardOpen(true)}
        onOpenExport={() => {
          setIsPlaying(false);
          setIsExportOpen(true);
        }}
        onOpenAICopilot={() => {
          setActiveTab('ai');
          setMobileDrawerMode('assets');
        }}
        onSaveProjectNow={() => {
          setLastSavedText('Saved just now');
          showToast('Project snapshot saved to browser storage');
        }}
        lastSavedText={lastSavedText}
        vuLevels={vuLevels}
      />

      {/* Main Middle Workspace: Left Asset Drawer + Center Preview Stage + Right Inspector */}
      <div className="flex-1 flex min-h-0 overflow-hidden relative">
        {/* Left Tool Rail & Asset Drawer (Visible on Desktop or when mobile tab = 'assets') */}
        <div
          className={`${
            mobileDrawerMode === 'assets' ? 'flex w-full z-30' : 'hidden md:flex'
          } h-full`}
        >
          <LeftAssetDrawer
            activeTab={activeTab}
            onSelectTab={setActiveTab}
            mediaLibrary={mediaLibrary}
            onImportFiles={handleImportFiles}
            onAddMediaToTimeline={(media, trackId) => {
              handleAddMediaToTimeline(media, trackId);
              if (mobileDrawerMode === 'assets') setMobileDrawerMode('stage');
            }}
            onAddTextClip={(style, label) => {
              handleAddTextClip(style, label);
              if (mobileDrawerMode === 'assets') setMobileDrawerMode('stage');
            }}
            onAddEffectOverlay={(type, name) => {
              handleAddEffectOverlay(type, name);
              if (mobileDrawerMode === 'assets') setMobileDrawerMode('stage');
            }}
            onAddStickerClip={(emoji, label) => {
              handleAddStickerClip(emoji, label);
              if (mobileDrawerMode === 'assets') setMobileDrawerMode('stage');
            }}
            onApplyFilterToSelectedOrAll={handleApplyFilter}
            onApplyTransitionToSelectedOrAll={handleApplyTransition}
            onGenerateAutoCaptions={handleGenerateAutoCaptions}
            onAddVoiceoverClip={handleAddVoiceoverClip}
            onSyncBeatMarkers={handleSyncBeatMarkers}
            onSnapClipsToBeats={handleSnapClipsToBeats}
            clips={project.clips}
            selectedClipId={selectedClipId}
            onSelectClip={setSelectedClipId}
            onUpdateClip={handleUpdateClip}
            onSeek={(t) => {
              setIsPlaying(false);
              setCurrentTime(t);
            }}
            activeAIProposal={activeAIProposal}
            onProposeAIEdit={setActiveAIProposal}
            onApproveAIProposal={handleApproveAIProposal}
            onDismissAIProposal={() => setActiveAIProposal(null)}
          />
        </div>

        {/* Center Video Preview Stage */}
        <div
          className={`${
            mobileDrawerMode === 'stage' ? 'flex' : 'hidden md:flex'
          } flex-1 min-w-0 h-full`}
        >
          <CenterPreviewStage
            canvasRef={canvasRef}
            aspectRatio={project.aspectRatio}
            fps={project.fps}
            currentTime={currentTime}
            totalDuration={totalDuration}
            isPlaying={isPlaying}
            isLooping={isLooping}
            isMuted={isMuted}
            showSafeGuides={showSafeGuides}
            selectedClip={selectedClip}
            onTogglePlay={() => {
              studioAudioEngine.ensureContext();
              setIsPlaying((p) => !p);
            }}
            onSeek={(t) => {
              setIsPlaying(false);
              setCurrentTime(Math.max(0, Math.min(totalDuration, t)));
            }}
            onStepFrame={(dir) => {
              setIsPlaying(false);
              setCurrentTime((t) =>
                Math.max(0, Math.min(totalDuration, t + (dir * 1) / project.fps))
              );
            }}
            onToggleLoop={() => setIsLooping((l) => !l)}
            onToggleMute={() => setIsMuted((m) => !m)}
            onToggleSafeGuides={() => setShowSafeGuides((g) => !g)}
            onUpdateClip={(id, patch) => handleUpdateClip(id, patch, false)}
          />
        </div>

        {/* Right Property Inspector (Visible on Desktop or when mobile tab = 'inspector') */}
        <div
          className={`${
            mobileDrawerMode === 'inspector' ? 'flex w-full z-30' : 'hidden md:flex'
          } h-full`}
        >
          <RightInspector
            selectedClip={selectedClip}
            currentTime={currentTime}
            onUpdateClip={handleUpdateClip}
            onDeleteClip={handleDeleteClip}
            onDuplicateClip={handleDuplicateClip}
            onSplitClipAtPlayhead={handleSplitAtPlayhead}
            onSeek={(t) => {
              setIsPlaying(false);
              setCurrentTime(t);
            }}
          />
        </div>
      </div>

      {/* Bottom Multi-Track Timeline */}
      <MultiTrackTimeline
        tracks={project.tracks}
        clips={project.clips}
        currentTime={currentTime}
        totalDuration={totalDuration}
        selectedClipId={selectedClipId}
        beatMarkers={project.beatMarkers}
        zoomPxPerSec={zoomPxPerSec}
        snapEnabled={snapEnabled}
        onChangeZoom={setZoomPxPerSec}
        onToggleSnap={() => setSnapEnabled((s) => !s)}
        onSeek={(t) => {
          setIsPlaying(false);
          setCurrentTime(t);
        }}
        onSelectClip={setSelectedClipId}
        onUpdateClip={handleUpdateClip}
        onSplitAtPlayhead={handleSplitAtPlayhead}
        onMergeAdjacentClips={handleMergeAdjacentClips}
        onDuplicateSelected={() => handleDuplicateClip()}
        onDeleteSelected={() => handleDeleteClip()}
        onToggleTrackMute={(id) => handleToggleTrackFlag(id, 'muted')}
        onToggleTrackLock={(id) => handleToggleTrackFlag(id, 'locked')}
        onToggleTrackHidden={(id) => handleToggleTrackFlag(id, 'hidden')}
        onAddTrack={handleAddTrack}
        onAddBeatMarkerAtPlayhead={() => {
          const t = Number(currentTime.toFixed(2));
          updateProjectWithHistory((prev) => ({
            ...prev,
            beatMarkers: Array.from(new Set([...prev.beatMarkers, t])).sort(
              (a, b) => a - b
            ),
          }));
          showToast(`Added beat marker ♦ at ${t}s`);
        }}
        onDropMediaOnTrack={(mediaId, trackId, dropTime) => {
          const item = mediaLibrary.find((m) => m.id === mediaId);
          if (item) {
            handleAddMediaToTimeline(item, trackId, dropTime);
          }
        }}
      />

      {/* Mobile Bottom View Switcher (< md screens) */}
      <div className="md:hidden h-11 bg-[#14141D] border-t border-[#262636] grid grid-cols-3 gap-1 px-2 items-center shrink-0 z-40">
        <button
          onClick={() => setMobileDrawerMode('stage')}
          className={`py-1.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 ${
            mobileDrawerMode === 'stage'
              ? 'bg-[#8B5CF6] text-white'
              : 'text-[#9494A8]'
          }`}
        >
          <Film className="w-3.5 h-3.5" />
          <span>Monitor</span>
        </button>
        <button
          onClick={() => setMobileDrawerMode('assets')}
          className={`py-1.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 ${
            mobileDrawerMode === 'assets'
              ? 'bg-[#8B5CF6] text-white'
              : 'text-[#9494A8]'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Assets & AI</span>
        </button>
        <button
          onClick={() => setMobileDrawerMode('inspector')}
          className={`py-1.5 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 ${
            mobileDrawerMode === 'inspector'
              ? 'bg-[#8B5CF6] text-white'
              : 'text-[#9494A8]'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>Inspector</span>
        </button>
      </div>

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-16 right-5 z-50 px-4 py-2.5 rounded-xl bg-[#181822]/95 border border-[#8B5CF6] text-xs font-semibold text-white shadow-[0_0_24px_rgba(139,92,246,0.5)] flex items-center gap-2 animate-in fade-in slide-in-from-bottom-3 duration-150">
          <Sparkles className="w-4 h-4 text-[#A855F7]" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Home Dashboard Modal */}
      <HomeDashboardModal
        isOpen={isDashboardOpen}
        onClose={() => setIsDashboardOpen(false)}
        savedProjects={savedProjects}
        currentProjectId={project.id}
        onCreateNewProject={handleCreateNewProject}
        onSelectProject={(proj) => {
          setProject(proj);
          setCurrentTime(0);
          setSelectedClipId(proj.clips[0]?.id || null);
          showToast(`Opened "${proj.name}"`);
        }}
        onDeleteProject={(id) => {
          setSavedProjects((prev) => {
            const filtered = prev.filter((p) => p.id !== id);
            localStorage.setItem(STORAGE_KEY_PROJECTS, JSON.stringify(filtered));
            if (project.id === id && filtered[0]) {
              setProject(filtered[0]);
            }
            return filtered;
          });
          showToast('Deleted project draft');
        }}
        onDuplicateProject={(proj) => {
          const dup: ProjectData = {
            ...proj,
            id: 'proj-' + Date.now(),
            name: `${proj.name} (Copy)`,
            updatedAt: Date.now(),
          };
          setSavedProjects((prev) => [dup, ...prev]);
          showToast(`Duplicated "${proj.name}"`);
        }}
        onImportProjectJson={(imported) => {
          setProject(imported);
          setCurrentTime(0);
          showToast(`Imported project "${imported.name}"`);
        }}
        onExportCurrentProjectJson={handleExportCurrentProjectJson}
      />

      {/* Export Video Modal */}
      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        projectName={project.name}
        aspectRatio={project.aspectRatio}
        fps={project.fps}
        resolution={project.resolution}
        tracks={project.tracks}
        clips={project.clips}
        totalDuration={totalDuration}
        videoElements={videoElementsRef.current}
        imageElements={imageElementsRef.current}
        onChangeAspectRatio={(ar) =>
          updateProjectWithHistory((prev) => ({ ...prev, aspectRatio: ar }))
        }
        onChangeFps={(fps) =>
          updateProjectWithHistory((prev) => ({ ...prev, fps }))
        }
      />
    </div>
  );
}

export default App;
