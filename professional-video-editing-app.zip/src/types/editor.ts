export type AspectRatioOption = '16:9' | '9:16' | '1:1' | '4:5';
export type FPSOption = 24 | 30 | 60;
export type ResolutionOption = '720p' | '1080p' | '4K';

export type TrackType = 'video' | 'text' | 'effect' | 'audio';
export type ClipType = 'video' | 'image' | 'audio' | 'text' | 'effect' | 'sticker';

export type TransitionType =
  | 'none'
  | 'fade'
  | 'zoom'
  | 'slide-left'
  | 'slide-up'
  | 'blur'
  | 'glitch'
  | 'spin';

export type FilterPreset =
  | 'none'
  | 'cyberpunk'
  | 'teal-orange'
  | 'vintage'
  | 'noir'
  | 'dreamy'
  | 'matrix'
  | 'bleach';

export type SpeedRampPreset =
  | 'constant'
  | 'montage'
  | 'hero-slowmo'
  | 'jump-boost'
  | 'bullet-time';

export type TextAnimationType =
  | 'none'
  | 'typewriter'
  | 'bounce'
  | 'fade-up'
  | 'slide-in'
  | 'wave'
  | 'glitch';

export type EffectOverlayType =
  | 'vhs'
  | 'rgb-split'
  | 'film-grain'
  | 'cinema-bars'
  | 'neon-frame'
  | 'light-leak'
  | 'bokeh-pulse';

export interface Keyframe {
  id: string;
  timeOffset: number; // seconds from clip start
  scale: number;
  x: number;
  y: number;
  rotation: number;
  opacity: number;
}

export interface ChromaKeySettings {
  enabled: boolean;
  keyColor: string; // e.g., '#00FF00'
  similarity: number; // 1 - 100
  smoothness: number; // 0 - 50
  spillSuppression: number; // 0 - 50
}

export interface ColorGradingSettings {
  brightness: number; // -100 to 100
  contrast: number; // -100 to 100
  saturation: number; // -100 to 100
  exposure: number; // -100 to 100
  hue: number; // -180 to 180
  temperature: number; // -100 to 100
  vignette: number; // 0 to 100
  blur: number; // 0 to 40
  filterPreset: FilterPreset;
}

export interface TransitionSettings {
  type: TransitionType;
  duration: number; // 0.2 to 2.5s
}

export interface TextStyleSettings {
  text: string;
  fontFamily: 'Plus Jakarta Sans' | 'Inter' | 'JetBrains Mono' | 'Impact' | 'Georgia';
  fontSize: number;
  fontWeight: '400' | '600' | '700' | '800';
  color: string;
  useGradient: boolean;
  gradientColor2: string;
  outlineColor: string;
  outlineWidth: number;
  shadowColor: string;
  shadowBlur: number;
  bgColor: string;
  bgOpacity: number;
  animation: TextAnimationType;
  align: 'left' | 'center' | 'right';
  isSubtitle: boolean;
}

export interface AudioClipSettings {
  volume: number; // 0 to 200%
  fadeIn: number; // 0 to 5s
  fadeOut: number; // 0 to 5s
  noiseReduction: boolean;
  voiceEnhance: boolean;
  ttsText?: string;
  ttsVoice?: string;
}

export interface CropSettings {
  top: number;
  right: number;
  bottom: number;
  left: number;
}

export interface MediaItem {
  id: string;
  name: string;
  type: 'video' | 'image' | 'audio';
  url: string;
  thumbnail: string;
  duration: number;
  width: number;
  height: number;
  proceduralPreset?: string;
  audioCategory?: 'music' | 'sfx' | 'voiceover';
  bpm?: number;
  waveform?: number[];
  isGreenScreen?: boolean;
}

export interface TimelineClip {
  id: string;
  trackId: string;
  mediaId?: string;
  name: string;
  type: ClipType;
  startTime: number; // seconds on timeline
  duration: number; // seconds on timeline
  trimStart: number; // seconds offset into source
  sourceDuration: number;
  url?: string;
  thumbnail?: string;
  proceduralPreset?: string;
  waveform?: number[];

  // Spatial transform
  x: number; // -100 to 100%
  y: number; // -100 to 100%
  scale: number; // 10 to 300%
  rotation: number; // 0 to 360 deg
  opacity: number; // 0 to 100%
  flipH: boolean;
  flipV: boolean;
  crop: CropSettings;
  blendMode: GlobalCompositeOperation;
  backgroundBlurFill: boolean;

  // Motion & Speed
  speed: number; // 0.25 to 4.0
  speedRamp: SpeedRampPreset;
  reverse: boolean;
  keyframes: Keyframe[];

  // Transitions & Color & Chroma
  transitionIn: TransitionSettings;
  transitionOut: TransitionSettings;
  color: ColorGradingSettings;
  chromaKey: ChromaKeySettings;

  // Type-specific payloads
  textStyle?: TextStyleSettings;
  audioSettings?: AudioClipSettings;
  effectOverlayType?: EffectOverlayType;
  stickerEmoji?: string;
}

export interface TimelineTrack {
  id: string;
  name: string;
  type: TrackType;
  muted: boolean;
  locked: boolean;
  hidden: boolean;
}

export interface AIProposal {
  id: string;
  title: string;
  description: string;
  changesSummary: string[];
  actionType:
    | 'beat-sync-edit'
    | 'auto-captions'
    | 'smart-reframe'
    | 'cyberpunk-grade'
    | 'highlight-trim'
    | 'background-remove';
  targetAspectRatio?: AspectRatioOption;
}

export interface ProjectData {
  id: string;
  name: string;
  updatedAt: number;
  thumbnail?: string;
  aspectRatio: AspectRatioOption;
  fps: FPSOption;
  resolution: ResolutionOption;
  tracks: TimelineTrack[];
  clips: TimelineClip[];
  beatMarkers: number[];
}

export interface ExportConfig {
  resolution: ResolutionOption;
  fps: FPSOption;
  aspectRatio: AspectRatioOption;
  format: 'mp4' | 'webm';
  bitrateMbps: 8 | 16 | 32;
  filename: string;
}

export type LeftRailTab =
  | 'media'
  | 'text'
  | 'audio'
  | 'effects'
  | 'transitions'
  | 'stickers'
  | 'ai';
