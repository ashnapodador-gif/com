import React, { useRef, useState } from 'react';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  ChevronLeft,
  ChevronRight,
  Volume2,
  VolumeX,
  Grid,
  Maximize2,
  Repeat,
  Sparkles,
} from 'lucide-react';
import {
  AspectRatioOption,
  FPSOption,
  TimelineClip,
} from '../types/editor';
import { formatTimecode, getCanvasDimensions } from '../engine/canvasCompositor';

interface CenterPreviewStageProps {
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  aspectRatio: AspectRatioOption;
  fps: FPSOption;
  currentTime: number;
  totalDuration: number;
  isPlaying: boolean;
  isLooping: boolean;
  isMuted: boolean;
  showSafeGuides: boolean;
  selectedClip: TimelineClip | null;
  onTogglePlay: () => void;
  onSeek: (time: number) => void;
  onStepFrame: (direction: -1 | 1) => void;
  onToggleLoop: () => void;
  onToggleMute: () => void;
  onToggleSafeGuides: () => void;
  onUpdateClip: (id: string, patch: Partial<TimelineClip>) => void;
}

export const CenterPreviewStage: React.FC<CenterPreviewStageProps> = ({
  canvasRef,
  aspectRatio,
  fps,
  currentTime,
  totalDuration,
  isPlaying,
  isLooping,
  isMuted,
  showSafeGuides,
  selectedClip,
  onTogglePlay,
  onSeek,
  onStepFrame,
  onToggleLoop,
  onToggleMute,
  onToggleSafeGuides,
  onUpdateClip,
}) => {
  const stageContainerRef = useRef<HTMLDivElement>(null);
  const [isDraggingCanvasLayer, setIsDraggingCanvasLayer] = useState(false);
  const dragStartRef = useRef<{
    clientX: number;
    clientY: number;
    origX: number;
    origY: number;
  } | null>(null);

  const dims = getCanvasDimensions(aspectRatio, 720);

  const handlePointerDownCanvas = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!selectedClip || selectedClip.type === 'audio' || selectedClip.type === 'effect') return;
    e.currentTarget.setPointerCapture(e.pointerId);
    setIsDraggingCanvasLayer(true);
    dragStartRef.current = {
      clientX: e.clientX,
      clientY: e.clientY,
      origX: selectedClip.x,
      origY: selectedClip.y,
    };
  };

  const handlePointerMoveCanvas = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDraggingCanvasLayer || !dragStartRef.current || !selectedClip || !canvasRef.current) {
      return;
    }
    const rect = canvasRef.current.getBoundingClientRect();
    const dxPercent = ((e.clientX - dragStartRef.current.clientX) / Math.max(1, rect.width * 0.5)) * 100;
    const dyPercent = ((e.clientY - dragStartRef.current.clientY) / Math.max(1, rect.height * 0.5)) * 100;

    onUpdateClip(selectedClip.id, {
      x: Math.round(Math.max(-100, Math.min(100, dragStartRef.current.origX + dxPercent))),
      y: Math.round(Math.max(-100, Math.min(100, dragStartRef.current.origY + dyPercent))),
    });
  };

  const handlePointerUpCanvas = () => {
    setIsDraggingCanvasLayer(false);
    dragStartRef.current = null;
  };

  const handleFullScreen = () => {
    if (stageContainerRef.current && stageContainerRef.current.requestFullscreen) {
      stageContainerRef.current.requestFullscreen().catch(() => {});
    }
  };

  // Css aspect ratio style
  const aspectStyle =
    aspectRatio === '16:9'
      ? { aspectRatio: '16 / 9', maxHeight: '100%', maxWidth: '100%' }
      : aspectRatio === '9:16'
      ? { aspectRatio: '9 / 16', maxHeight: '100%', maxWidth: '100%' }
      : aspectRatio === '1:1'
      ? { aspectRatio: '1 / 1', maxHeight: '100%', maxWidth: '100%' }
      : { aspectRatio: '4 / 5', maxHeight: '100%', maxWidth: '100%' };

  return (
    <div
      ref={stageContainerRef}
      className="flex-1 flex flex-col bg-[#09090E] min-w-0 min-h-0 overflow-hidden select-none"
    >
      {/* Top Stage Telemetry Bar */}
      <div className="h-9 px-3 bg-[#0D0D14] border-b border-[#262636] flex items-center justify-between text-xs shrink-0">
        <div className="flex items-center gap-2">
          <span className="px-2 py-0.5 rounded bg-[#181822] border border-[#262636] text-[10px] font-mono-code text-[#9494A8]">
            {dims.width}×{dims.height} ({aspectRatio})
          </span>
          {selectedClip && (
            <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded bg-[#8B5CF6]/15 border border-[#8B5CF6]/40 text-[10px] text-[#A855F7] truncate max-w-[200px]">
              <Sparkles className="w-3 h-3 shrink-0" />
              Selected: {selectedClip.name}
            </span>
          )}
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={onToggleSafeGuides}
            title="Toggle Rule-of-Thirds & Title Safe Guides"
            className={`px-2 py-1 rounded text-[10px] font-semibold flex items-center gap-1 border transition-colors cursor-pointer ${
              showSafeGuides
                ? 'bg-[#8B5CF6]/20 text-[#A855F7] border-[#8B5CF6]/50'
                : 'bg-[#181822] text-[#9494A8] border-[#262636] hover:text-white'
            }`}
          >
            <Grid className="w-3 h-3" />
            <span className="hidden md:inline">Safe Guides</span>
          </button>

          <button
            onClick={handleFullScreen}
            title="Fullscreen Monitor"
            className="p-1 rounded bg-[#181822] hover:bg-[#262636] text-[#9494A8] hover:text-white border border-[#262636] transition-colors cursor-pointer"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Viewport Canvas Container */}
      <div className="flex-1 relative flex items-center justify-center p-3 sm:p-5 overflow-hidden bg-checkerboard">
        <div
          style={aspectStyle}
          className="relative flex items-center justify-center shadow-[0_0_40px_rgba(0,0,0,0.85)] rounded-lg overflow-hidden border border-[#262636] bg-black"
        >
          <canvas
            ref={canvasRef}
            width={dims.width}
            height={dims.height}
            onPointerDown={handlePointerDownCanvas}
            onPointerMove={handlePointerMoveCanvas}
            onPointerUp={handlePointerUpCanvas}
            className={`w-full h-full object-contain block ${
              selectedClip && selectedClip.type !== 'audio' && selectedClip.type !== 'effect'
                ? 'cursor-move'
                : 'cursor-default'
            }`}
          />
        </div>
      </div>

      {/* Bottom Transport Controls & Scrubber Bar */}
      <div className="h-12 px-3 sm:px-4 bg-[#111118] border-t border-[#262636] flex items-center justify-between gap-3 shrink-0">
        {/* Left: Frame-Accurate Timecode Readout */}
        <div className="flex items-center gap-1.5 font-mono-code text-xs">
          <span className="text-[#A855F7] font-bold">
            {formatTimecode(currentTime, fps)}
          </span>
          <span className="text-[#5A5A70]">/</span>
          <span className="text-[#9494A8]">
            {formatTimecode(totalDuration, fps)}
          </span>
        </div>

        {/* Center: Transport Deck (Jump Start, -1 Frame, Play/Pause, +1 Frame, Jump End) */}
        <div className="flex items-center gap-1 sm:gap-1.5">
          <button
            onClick={() => onSeek(0)}
            title="Jump to Start (Home)"
            className="p-1.5 rounded-lg text-[#9494A8] hover:text-white hover:bg-[#181822] transition-colors cursor-pointer"
          >
            <SkipBack className="w-4 h-4" />
          </button>

          <button
            onClick={() => onStepFrame(-1)}
            title="Previous Frame (Left Arrow)"
            className="p-1.5 rounded-lg text-[#9494A8] hover:text-white hover:bg-[#181822] transition-colors cursor-pointer flex items-center"
          >
            <ChevronLeft className="w-4 h-4" />
            <span className="text-[10px] font-mono-code hidden sm:inline">-1F</span>
          </button>

          <button
            onClick={onTogglePlay}
            title="Play / Pause (Space)"
            className="w-9 h-9 rounded-full bg-gradient-to-r from-[#8B5CF6] to-[#A855F7] hover:from-[#A855F7] hover:to-[#C084FC] text-white flex items-center justify-center shadow-[0_0_15px_rgba(139,92,246,0.5)] transition-transform active:scale-95 cursor-pointer mx-1"
          >
            {isPlaying ? (
              <Pause className="w-4 h-4 fill-current" />
            ) : (
              <Play className="w-4 h-4 fill-current ml-0.5" />
            )}
          </button>

          <button
            onClick={() => onStepFrame(1)}
            title="Next Frame (Right Arrow)"
            className="p-1.5 rounded-lg text-[#9494A8] hover:text-white hover:bg-[#181822] transition-colors cursor-pointer flex items-center"
          >
            <span className="text-[10px] font-mono-code hidden sm:inline">+1F</span>
            <ChevronRight className="w-4 h-4" />
          </button>

          <button
            onClick={() => onSeek(totalDuration)}
            title="Jump to End"
            className="p-1.5 rounded-lg text-[#9494A8] hover:text-white hover:bg-[#181822] transition-colors cursor-pointer"
          >
            <SkipForward className="w-4 h-4" />
          </button>
        </div>

        {/* Right: Loop & Master Mute */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={onToggleLoop}
            title="Loop Playback"
            className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
              isLooping
                ? 'bg-[#8B5CF6]/20 text-[#A855F7] border-[#8B5CF6]/50'
                : 'bg-[#181822] text-[#9494A8] border-[#262636] hover:text-white'
            }`}
          >
            <Repeat className="w-3.5 h-3.5" />
          </button>

          <button
            onClick={onToggleMute}
            title={isMuted ? 'Unmute Master Audio' : 'Mute Master Audio'}
            className={`p-1.5 rounded-lg border transition-colors cursor-pointer ${
              isMuted
                ? 'bg-[#EF4444]/20 text-[#EF4444] border-[#EF4444]/40'
                : 'bg-[#181822] text-[#9494A8] border-[#262636] hover:text-white'
            }`}
          >
            {isMuted ? (
              <VolumeX className="w-3.5 h-3.5" />
            ) : (
              <Volume2 className="w-3.5 h-3.5" />
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
