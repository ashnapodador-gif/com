import React from 'react';
import {
  Undo2,
  Redo2,
  Download,
  FolderKanban,
  Sparkles,
  CheckCircle2,
  Save,
  Monitor,
  Smartphone,
  Square,
  RectangleVertical,
} from 'lucide-react';
import { AspectRatioOption, FPSOption } from '../types/editor';

interface TopBarProps {
  projectName: string;
  onChangeProjectName: (name: string) => void;
  aspectRatio: AspectRatioOption;
  onChangeAspectRatio: (ar: AspectRatioOption) => void;
  fps: FPSOption;
  onChangeFps: (fps: FPSOption) => void;
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
  onOpenDashboard: () => void;
  onOpenExport: () => void;
  onOpenAICopilot: () => void;
  onSaveProjectNow: () => void;
  lastSavedText: string;
  vuLevels: { leftLevel: number; rightLevel: number };
}

export const TopBar: React.FC<TopBarProps> = ({
  projectName,
  onChangeProjectName,
  aspectRatio,
  onChangeAspectRatio,
  fps,
  onChangeFps,
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  onOpenDashboard,
  onOpenExport,
  onOpenAICopilot,
  onSaveProjectNow,
  lastSavedText,
  vuLevels,
}) => {
  const aspectIcons: Record<AspectRatioOption, React.ReactNode> = {
    '16:9': <Monitor className="w-3.5 h-3.5" />,
    '9:16': <Smartphone className="w-3.5 h-3.5" />,
    '1:1': <Square className="w-3.5 h-3.5" />,
    '4:5': <RectangleVertical className="w-3.5 h-3.5" />,
  };

  return (
    <header className="h-12 bg-[#111118] border-b border-[#262636] px-3 flex items-center justify-between gap-2 shrink-0 z-30">
      {/* Left: Brand Emblem + Dashboard Trigger + Project Title */}
      <div className="flex items-center gap-2.5 min-w-0">
        <button
          onClick={onOpenDashboard}
          title="Open Home Dashboard, Templates & Recent Projects"
          className="group flex items-center gap-2 px-2 py-1 rounded-lg bg-[#181822] hover:bg-[#1F1F2E] border border-[#262636] hover:border-[#8B5CF6]/50 transition-all cursor-pointer"
        >
          <div className="w-6 h-6 rounded-md bg-gradient-to-br from-[#8B5CF6] via-[#A855F7] to-[#EC4899] flex items-center justify-center shadow-[0_0_12px_rgba(139,92,246,0.5)]">
            <span className="font-display font-extrabold text-xs text-white tracking-tighter">
              K
            </span>
          </div>
          <span className="font-display font-bold text-xs tracking-tight text-[#F4F4F8] hidden sm:inline">
            KINETIX
          </span>
          <FolderKanban className="w-3.5 h-3.5 text-[#9494A8] group-hover:text-[#A855F7] transition-colors" />
        </button>

        <div className="h-4 w-[1px] bg-[#262636] hidden md:block" />

        <div className="flex items-center gap-1.5 min-w-0">
          <input
            type="text"
            value={projectName}
            onChange={(e) => onChangeProjectName(e.target.value)}
            aria-label="Project Name"
            className="bg-transparent hover:bg-[#181822] focus:bg-[#181822] text-xs font-semibold text-[#F4F4F8] px-2 py-1 rounded border border-transparent focus:border-[#8B5CF6] outline-none truncate max-w-[140px] sm:max-w-[200px] transition-colors"
          />
          <button
            onClick={onSaveProjectNow}
            title="Save Project Snapshot Now"
            className="hidden lg:flex items-center gap-1 text-[11px] text-[#9494A8] hover:text-[#F4F4F8] px-1.5 py-0.5 rounded bg-[#181822]/70 border border-[#262636]/70 cursor-pointer"
          >
            <CheckCircle2 className="w-3 h-3 text-[#10B981]" />
            <span>{lastSavedText}</span>
          </button>
        </div>
      </div>

      {/* Center: Undo/Redo + Aspect Ratio + FPS + Live Audio VU Meter */}
      <div className="flex items-center gap-2">
        {/* Undo / Redo */}
        <div className="flex items-center bg-[#181822] rounded-lg border border-[#262636] p-0.5">
          <button
            onClick={onUndo}
            disabled={!canUndo}
            title="Undo (Ctrl+Z)"
            className="p-1.5 rounded-md text-[#F4F4F8] disabled:text-[#5A5A70] hover:bg-[#1F1F2E] disabled:hover:bg-transparent transition-colors cursor-pointer disabled:cursor-not-allowed"
          >
            <Undo2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onRedo}
            disabled={!canRedo}
            title="Redo (Ctrl+Shift+Z)"
            className="p-1.5 rounded-md text-[#F4F4F8] disabled:text-[#5A5A70] hover:bg-[#1F1F2E] disabled:hover:bg-transparent transition-colors cursor-pointer disabled:cursor-not-allowed"
          >
            <Redo2 className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Aspect Ratio Pill Switcher */}
        <div className="hidden md:flex items-center bg-[#181822] rounded-lg border border-[#262636] p-0.5">
          {(['16:9', '9:16', '1:1', '4:5'] as AspectRatioOption[]).map((ar) => (
            <button
              key={ar}
              onClick={() => onChangeAspectRatio(ar)}
              title={`Set Canvas Aspect Ratio to ${ar}`}
              className={`flex items-center gap-1 px-2 py-1 rounded-md text-[11px] font-mono-code font-medium transition-all cursor-pointer ${
                aspectRatio === ar
                  ? 'bg-[#8B5CF6] text-white shadow-[0_0_10px_rgba(139,92,246,0.45)]'
                  : 'text-[#9494A8] hover:text-[#F4F4F8]'
              }`}
            >
              {aspectIcons[ar]}
              <span>{ar}</span>
            </button>
          ))}
        </div>

        {/* FPS Selector */}
        <div className="hidden xl:flex items-center bg-[#181822] rounded-lg border border-[#262636] p-0.5">
          {([24, 30, 60] as FPSOption[]).map((f) => (
            <button
              key={f}
              onClick={() => onChangeFps(f)}
              className={`px-2 py-1 rounded-md text-[11px] font-mono-code transition-colors cursor-pointer ${
                fps === f
                  ? 'bg-[#262636] text-[#A855F7] font-semibold'
                  : 'text-[#9494A8] hover:text-[#F4F4F8]'
              }`}
            >
              {f}fps
            </button>
          ))}
        </div>

        {/* Live Stereo VU Meter */}
        <div
          className="hidden lg:flex flex-col gap-0.5 bg-[#09090E] px-2 py-1 rounded-md border border-[#262636] w-24"
          title="Master Stereo Output Level (dB)"
        >
          <div className="flex items-center gap-1">
            <span className="text-[9px] font-mono-code text-[#5A5A70]">L</span>
            <div className="flex-1 h-1.5 bg-[#181822] rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-[#10B981] via-[#F59E0B] to-[#EF4444] transition-all duration-75"
                style={{ width: `${vuLevels.leftLevel}%` }}
              />
            </div>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-[9px] font-mono-code text-[#5A5A70]">R</span>
            <div className="flex-1 h-1.5 bg-[#181822] rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-[#10B981] via-[#F59E0B] to-[#EF4444] transition-all duration-75"
                style={{ width: `${vuLevels.rightLevel}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Right: AI Co-Pilot Trigger + Save + Export CTA */}
      <div className="flex items-center gap-2">
        <button
          onClick={onOpenAICopilot}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-white bg-gradient-to-r from-[#8B5CF6]/25 to-[#EC4899]/25 hover:from-[#8B5CF6]/40 hover:to-[#EC4899]/40 border border-[#A855F7]/50 transition-all cursor-pointer"
          title="Open AI Studio Co-Pilot"
        >
          <Sparkles className="w-3.5 h-3.5 text-[#EC4899]" />
          <span className="hidden sm:inline">AI Co-Pilot</span>
        </button>

        <button
          onClick={onSaveProjectNow}
          className="p-1.5 rounded-lg bg-[#181822] hover:bg-[#1F1F2E] border border-[#262636] text-[#9494A8] hover:text-[#F4F4F8] transition-colors cursor-pointer sm:hidden"
          title="Save Draft"
        >
          <Save className="w-4 h-4" />
        </button>

        <button
          onClick={onOpenExport}
          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold text-white bg-gradient-to-r from-[#8B5CF6] to-[#7C3AED] hover:from-[#A855F7] hover:to-[#8B5CF6] shadow-[0_0_16px_rgba(139,92,246,0.45)] transition-all cursor-pointer"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export</span>
        </button>
      </div>
    </header>
  );
};
