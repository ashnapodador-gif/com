import React, { useState, useRef } from 'react';
import {
  X,
  Download,
  Film,
  CheckCircle2,
  Loader2,
  Sparkles,
  AlertTriangle,
  Settings2,
} from 'lucide-react';
import {
  AspectRatioOption,
  ExportConfig,
  FPSOption,
  ResolutionOption,
  TimelineClip,
  TimelineTrack,
} from '../types/editor';
import { getCanvasDimensions, renderCompositeFrame } from '../engine/canvasCompositor';
import { studioAudioEngine } from '../engine/audioEngine';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  projectName: string;
  aspectRatio: AspectRatioOption;
  fps: FPSOption;
  resolution: ResolutionOption;
  tracks: TimelineTrack[];
  clips: TimelineClip[];
  totalDuration: number;
  videoElements: Map<string, HTMLVideoElement>;
  imageElements: Map<string, HTMLImageElement>;
  onChangeAspectRatio: (ar: AspectRatioOption) => void;
  onChangeFps: (fps: FPSOption) => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({
  isOpen,
  onClose,
  projectName,
  aspectRatio,
  fps,
  resolution,
  tracks,
  clips,
  totalDuration,
  videoElements,
  imageElements,
  onChangeAspectRatio,
  onChangeFps,
}) => {
  const [config, setConfig] = useState<ExportConfig>({
    resolution: resolution || '1080p',
    fps: fps || 60,
    aspectRatio: aspectRatio || '16:9',
    format: 'mp4',
    bitrateMbps: 16,
    filename: projectName.toLowerCase().replace(/[^a-z0-9]+/g, '-') || 'kinetix-export',
  });

  const [isRendering, setIsRendering] = useState(false);
  const [progress, setProgress] = useState(0);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [downloadedExt, setDownloadedExt] = useState<'mp4' | 'webm'>('mp4');
  const [renderError, setRenderError] = useState<string | null>(null);
  const previewCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const cancelRef = useRef(false);

  if (!isOpen) return null;

  const baseShortEdge =
    config.resolution === '4K' ? 1440 : config.resolution === '1080p' ? 1080 : 720;
  const dims = getCanvasDimensions(config.aspectRatio, baseShortEdge);
  const estimatedSizeMb = Math.max(
    1.2,
    Number(((totalDuration * config.bitrateMbps) / 8).toFixed(1))
  );

  const startRealExport = async () => {
    setRenderError(null);
    setDownloadUrl(null);
    setIsRendering(true);
    setProgress(0);
    cancelRef.current = false;

    try {
      const renderCanvas = previewCanvasRef.current || document.createElement('canvas');
      // Use safe hardware-accelerated canvas dimensions
      const exportEdge = config.resolution === '4K' ? 1080 : config.resolution === '1080p' ? 720 : 540;
      const exportDims = getCanvasDimensions(config.aspectRatio, exportEdge);
      renderCanvas.width = exportDims.width;
      renderCanvas.height = exportDims.height;

      const ctx = renderCanvas.getContext('2d');
      if (!ctx) throw new Error('Could not initialize 2D rendering context.');

      const stream = renderCanvas.captureStream(config.fps);
      const audioStream = studioAudioEngine.getExportAudioStream();
      if (audioStream) {
        audioStream.getAudioTracks().forEach((t) => stream.addTrack(t));
      }

      // Pick best supported MIME type (prefer MP4 H.264/AVC1 if supported by browser, else WebM VP9/VP8)
      const mimeCandidates =
        config.format === 'mp4'
          ? [
              'video/mp4;codecs=avc1',
              'video/mp4',
              'video/webm;codecs=vp9',
              'video/webm;codecs=vp8',
              'video/webm',
            ]
          : ['video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm'];

      let selectedMime = '';
      for (const candidate of mimeCandidates) {
        if (typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported(candidate)) {
          selectedMime = candidate;
          break;
        }
      }

      const chunks: BlobPart[] = [];
      const recorder = new MediaRecorder(
        stream,
        selectedMime
          ? {
              mimeType: selectedMime,
              videoBitsPerSecond: config.bitrateMbps * 1_000_000,
            }
          : undefined
      );

      recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
          chunks.push(e.data);
        }
      };

      const donePromise = new Promise<Blob>((resolve, reject) => {
        recorder.onstop = () => {
          const finalType = selectedMime || 'video/webm';
          resolve(new Blob(chunks, { type: finalType }));
        };
        recorder.onerror = (err) => reject(err);
      });

      recorder.start(100);

      // Step through frames across totalDuration
      const durationToRender = Math.max(2, Math.min(totalDuration, 18));
      const totalSteps = Math.max(30, Math.round(durationToRender * 20));

      for (let step = 0; step <= totalSteps; step++) {
        if (cancelRef.current) {
          recorder.stop();
          setIsRendering(false);
          return;
        }

        const simTime = (step / totalSteps) * durationToRender;

        // Render composite frame at simTime
        renderCompositeFrame({
          ctx,
          width: renderCanvas.width,
          height: renderCanvas.height,
          timelineTime: simTime,
          tracks,
          clips,
          videoElements,
          imageElements,
          selectedClipId: null,
          showSafeGuides: false,
        });

        studioAudioEngine.tickPlayback({
          timelineTime: simTime,
          isPlaying: true,
          tracks,
          clips,
          isMuted: false,
        });

        setProgress(Math.round((step / totalSteps) * 100));
        await new Promise((r) => setTimeout(r, 32));
      }

      recorder.stop();
      const videoBlob = await donePromise;
      const url = URL.createObjectURL(videoBlob);
      setDownloadedExt(selectedMime.includes('mp4') || config.format === 'mp4' ? 'mp4' : 'webm');
      setDownloadUrl(url);
      setIsRendering(false);
    } catch (err) {
      setIsRendering(false);
      setRenderError(
        err instanceof Error
          ? err.message
          : 'Export failed on this browser codec. Try switching to WebM or 720p.'
      );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
      <div className="w-full max-w-xl bg-[#111118] border border-[#262636] rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="px-6 py-4 bg-[#181822] border-b border-[#262636] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-[#8B5CF6]/20 border border-[#8B5CF6]/40 text-[#A855F7]">
              <Film className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-display font-bold text-base text-[#F4F4F8]">
                Export Master Video
              </h3>
              <p className="text-xs text-[#9494A8]">
                Hardware-accelerated Canvas & WebAudio master encoder
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              cancelRef.current = true;
              onClose();
            }}
            className="p-1.5 rounded-lg text-[#9494A8] hover:text-white hover:bg-[#262636] cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {/* Live Render Monitor Canvas */}
          <div className="relative rounded-xl bg-[#09090E] border border-[#262636] p-3 flex flex-col items-center justify-center min-h-[150px]">
            <canvas
              ref={previewCanvasRef}
              className="max-h-36 rounded-lg shadow-lg border border-[#262636]"
              width={320}
              height={180}
            />
            <div className="mt-2 flex items-center gap-3 text-[11px] font-mono-code text-[#9494A8]">
              <span>
                OUTPUT: {dims.width}×{dims.height}px ({config.resolution})
              </span>
              <span>•</span>
              <span>{config.fps} FPS</span>
              <span>•</span>
              <span>~{estimatedSizeMb} MB</span>
            </div>
          </div>

          {/* Configuration Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Resolution */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-[#9494A8] flex items-center gap-1.5">
                <Settings2 className="w-3.5 h-3.5 text-[#8B5CF6]" />
                Resolution
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                {(['720p', '1080p', '4K'] as ResolutionOption[]).map((res) => (
                  <button
                    key={res}
                    disabled={isRendering}
                    onClick={() => setConfig({ ...config, resolution: res })}
                    className={`py-2 rounded-lg text-xs font-mono-code font-semibold border transition-all cursor-pointer ${
                      config.resolution === res
                        ? 'bg-[#8B5CF6] text-white border-[#A855F7]'
                        : 'bg-[#181822] text-[#9494A8] border-[#262636] hover:text-white'
                    }`}
                  >
                    {res}
                  </button>
                ))}
              </div>
            </div>

            {/* Frame Rate */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-[#9494A8]">Frame Rate (FPS)</label>
              <div className="grid grid-cols-3 gap-1.5">
                {([24, 30, 60] as FPSOption[]).map((f) => (
                  <button
                    key={f}
                    disabled={isRendering}
                    onClick={() => {
                      setConfig({ ...config, fps: f });
                      onChangeFps(f);
                    }}
                    className={`py-2 rounded-lg text-xs font-mono-code font-semibold border transition-all cursor-pointer ${
                      config.fps === f
                        ? 'bg-[#8B5CF6] text-white border-[#A855F7]'
                        : 'bg-[#181822] text-[#9494A8] border-[#262636] hover:text-white'
                    }`}
                  >
                    {f} FPS
                  </button>
                ))}
              </div>
            </div>

            {/* Aspect Ratio */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-[#9494A8]">Aspect Ratio</label>
              <div className="grid grid-cols-4 gap-1.5">
                {(['16:9', '9:16', '1:1', '4:5'] as AspectRatioOption[]).map((ar) => (
                  <button
                    key={ar}
                    disabled={isRendering}
                    onClick={() => {
                      setConfig({ ...config, aspectRatio: ar });
                      onChangeAspectRatio(ar);
                    }}
                    className={`py-2 rounded-lg text-xs font-mono-code font-semibold border transition-all cursor-pointer ${
                      config.aspectRatio === ar
                        ? 'bg-[#8B5CF6] text-white border-[#A855F7]'
                        : 'bg-[#181822] text-[#9494A8] border-[#262636] hover:text-white'
                    }`}
                  >
                    {ar}
                  </button>
                ))}
              </div>
            </div>

            {/* Bitrate Quality */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-[#9494A8]">Bitrate / Quality</label>
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  { mbps: 8 as const, label: 'Std 8M' },
                  { mbps: 16 as const, label: 'High 16M' },
                  { mbps: 32 as const, label: 'Pro 32M' },
                ].map((b) => (
                  <button
                    key={b.mbps}
                    disabled={isRendering}
                    onClick={() => setConfig({ ...config, bitrateMbps: b.mbps })}
                    className={`py-2 rounded-lg text-xs font-mono-code font-semibold border transition-all cursor-pointer ${
                      config.bitrateMbps === b.mbps
                        ? 'bg-[#8B5CF6] text-white border-[#A855F7]'
                        : 'bg-[#181822] text-[#9494A8] border-[#262636] hover:text-white'
                    }`}
                  >
                    {b.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Container Format & File Name */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
            <div className="sm:col-span-2 space-y-1">
              <label className="text-xs font-semibold text-[#9494A8]">Export Filename</label>
              <input
                type="text"
                value={config.filename}
                disabled={isRendering}
                onChange={(e) => setConfig({ ...config, filename: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-[#181822] border border-[#262636] focus:border-[#8B5CF6] text-xs font-mono-code text-white outline-none"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-semibold text-[#9494A8]">Format</label>
              <div className="grid grid-cols-2 gap-1.5">
                {(['mp4', 'webm'] as const).map((fmt) => (
                  <button
                    key={fmt}
                    disabled={isRendering}
                    onClick={() => setConfig({ ...config, format: fmt })}
                    className={`py-2 rounded-lg text-xs font-mono-code uppercase font-bold border transition-all cursor-pointer ${
                      config.format === fmt
                        ? 'bg-[#8B5CF6] text-white border-[#A855F7]'
                        : 'bg-[#181822] text-[#9494A8] border-[#262636]'
                    }`}
                  >
                    .{fmt}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Progress Bar */}
          {isRendering && (
            <div className="p-4 rounded-xl bg-[#181822] border border-[#8B5CF6]/50 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="flex items-center gap-2 font-semibold text-[#F4F4F8]">
                  <Loader2 className="w-4 h-4 text-[#A855F7] animate-spin" />
                  Encoding multi-track composite frames...
                </span>
                <span className="font-mono-code font-bold text-[#A855F7]">{progress}%</span>
              </div>
              <div className="w-full h-2 bg-[#09090E] rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-[#8B5CF6] via-[#A855F7] to-[#EC4899] transition-all duration-150"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}

          {/* Error Recovery Banner */}
          {renderError && (
            <div className="p-3.5 rounded-xl bg-[#EF4444]/15 border border-[#EF4444]/40 flex items-start gap-2.5 text-xs text-[#F4F4F8]">
              <AlertTriangle className="w-4 h-4 text-[#EF4444] shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold text-[#EF4444]">Export Codec Notice</p>
                <p className="text-[#9494A8] mt-0.5">{renderError}</p>
              </div>
            </div>
          )}

          {/* Completed Download Box */}
          {downloadUrl && !isRendering && (
            <div className="p-4 rounded-xl bg-[#10B981]/15 border border-[#10B981]/40 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-5 h-5 text-[#10B981] shrink-0" />
                <div>
                  <p className="text-xs font-bold text-[#F4F4F8]">
                    Master Render Complete ({config.resolution} • {config.fps}fps)
                  </p>
                  <p className="text-[11px] text-[#9494A8]">
                    Ready to save to your device
                  </p>
                </div>
              </div>
              <a
                href={downloadUrl}
                download={`${config.filename || 'kinetix-video'}.${downloadedExt}`}
                className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-[#10B981] hover:bg-[#059669] text-xs font-bold text-black shadow-lg transition-colors"
              >
                <Download className="w-4 h-4" />
                <span>Download .{downloadedExt.toUpperCase()}</span>
              </a>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 bg-[#181822] border-t border-[#262636] flex items-center justify-between">
          <span className="text-[11px] text-[#9494A8] flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-[#A855F7]" />
            Includes Chroma Key, LUTs, Captions & Audio Mix
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                cancelRef.current = true;
                onClose();
              }}
              className="px-4 py-2 rounded-lg text-xs font-semibold text-[#9494A8] hover:text-white bg-[#111118] border border-[#262636] cursor-pointer"
            >
              {isRendering ? 'Cancel Render' : 'Close'}
            </button>
            <button
              disabled={isRendering}
              onClick={startRealExport}
              className="flex items-center gap-1.5 px-5 py-2 rounded-lg text-xs font-bold text-white bg-gradient-to-r from-[#8B5CF6] to-[#EC4899] hover:from-[#A855F7] hover:to-[#F472B6] disabled:opacity-50 shadow-[0_0_20px_rgba(139,92,246,0.45)] cursor-pointer"
            >
              <Film className="w-3.5 h-3.5" />
              <span>{downloadUrl ? 'Re-Render Video' : 'Start Render & Export'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
