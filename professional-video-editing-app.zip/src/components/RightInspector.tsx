import React, { useState } from 'react';
import {
  Sliders,
  Palette,
  Gauge,
  Type,
  Volume2,
  Diamond,
  RotateCcw,
  FlipHorizontal,
  FlipVertical,
  Trash2,
  Copy,
  Scissors,
  Sparkles,
  Layers,
  Plus,
} from 'lucide-react';
import {
  FilterPreset,
  Keyframe,
  SpeedRampPreset,
  TextAnimationType,
  TimelineClip,
  TransitionType,
} from '../types/editor';
import {
  DEFAULT_COLOR_GRADING,
  DEFAULT_CROP,
  FILTER_PRESETS_INFO,
  TRANSITION_PRESETS,
} from '../data/presets';

interface RightInspectorProps {
  selectedClip: TimelineClip | null;
  currentTime: number;
  onUpdateClip: (id: string, patch: Partial<TimelineClip>) => void;
  onDeleteClip: (id: string) => void;
  onDuplicateClip: (id: string) => void;
  onSplitClipAtPlayhead: () => void;
  onSeek: (time: number) => void;
}

export const RightInspector: React.FC<RightInspectorProps> = ({
  selectedClip,
  currentTime,
  onUpdateClip,
  onDeleteClip,
  onDuplicateClip,
  onSplitClipAtPlayhead,
  onSeek,
}) => {
  const [subTab, setSubTab] = useState<'transform' | 'color' | 'speed' | 'special'>('transform');

  if (!selectedClip) {
    return (
      <aside className="w-72 lg:w-80 bg-[#111118] border-l border-[#262636] flex flex-col h-full shrink-0 select-none">
        <div className="px-4 py-3 border-b border-[#262636] bg-[#14141D]">
          <h2 className="font-display font-bold text-xs uppercase tracking-wider text-[#9494A8]">
            Inspector Properties
          </h2>
        </div>
        <div className="flex-1 p-6 flex flex-col items-center justify-center text-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-[#181822] border border-[#262636] flex items-center justify-center text-[#8B5CF6]">
            <Sliders className="w-5 h-5" />
          </div>
          <div className="space-y-1">
            <p className="text-xs font-bold text-[#F4F4F8]">No Timeline Clip Selected</p>
            <p className="text-[11px] text-[#9494A8] max-w-[210px]">
              Click any video, text, effect, or audio clip on the multi-track timeline below to inspect & keyframe its parameters.
            </p>
          </div>
        </div>
      </aside>
    );
  }

  const localOffset = Math.max(
    0,
    Math.min(selectedClip.duration, Number((currentTime - selectedClip.startTime).toFixed(2)))
  );

  // Add or update keyframe at current local time
  const handleAddKeyframe = () => {
    const newKf: Keyframe = {
      id: 'kf-' + Date.now(),
      timeOffset: localOffset,
      scale: selectedClip.scale,
      x: selectedClip.x,
      y: selectedClip.y,
      rotation: selectedClip.rotation,
      opacity: selectedClip.opacity,
    };
    const filtered = selectedClip.keyframes.filter(
      (k) => Math.abs(k.timeOffset - localOffset) > 0.08
    );
    onUpdateClip(selectedClip.id, {
      keyframes: [...filtered, newKf].sort((a, b) => a.timeOffset - b.timeOffset),
    });
  };

  const handleRemoveKeyframe = (kfId: string) => {
    onUpdateClip(selectedClip.id, {
      keyframes: selectedClip.keyframes.filter((k) => k.id !== kfId),
    });
  };

  return (
    <aside className="w-72 lg:w-80 bg-[#111118] border-l border-[#262636] flex flex-col h-full shrink-0 select-none">
      {/* Header with Clip Name + Quick Actions */}
      <div className="px-3.5 py-2.5 border-b border-[#262636] bg-[#14141D] flex items-center justify-between gap-2">
        <div className="min-w-0">
          <span className="text-[9px] font-mono-code uppercase px-1.5 py-0.5 rounded bg-[#8B5CF6]/20 text-[#A855F7] font-bold">
            {selectedClip.type}
          </span>
          <h3 className="text-xs font-bold text-[#F4F4F8] truncate mt-0.5">
            {selectedClip.name}
          </h3>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={onSplitClipAtPlayhead}
            title="Split Clip at Playhead (S)"
            className="p-1.5 rounded-lg bg-[#181822] hover:bg-[#262636] text-[#9494A8] hover:text-white border border-[#262636] cursor-pointer"
          >
            <Scissors className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => onDuplicateClip(selectedClip.id)}
            title="Duplicate Clip (D)"
            className="p-1.5 rounded-lg bg-[#181822] hover:bg-[#262636] text-[#9494A8] hover:text-white border border-[#262636] cursor-pointer"
          >
            <Copy className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => onDeleteClip(selectedClip.id)}
            title="Delete Clip (Del)"
            className="p-1.5 rounded-lg bg-[#181822] hover:bg-[#EF4444]/20 text-[#9494A8] hover:text-[#EF4444] border border-[#262636] cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Inspector Sub-Navigation Tabs */}
      <div className="grid grid-cols-4 gap-1 p-1.5 bg-[#0D0D14] border-b border-[#262636]">
        <button
          onClick={() => setSubTab('transform')}
          className={`py-1.5 rounded-lg text-[10px] font-semibold flex flex-col items-center gap-0.5 transition-colors cursor-pointer ${
            subTab === 'transform'
              ? 'bg-[#8B5CF6] text-white'
              : 'text-[#9494A8] hover:text-white'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>Transform</span>
        </button>

        <button
          onClick={() => setSubTab('color')}
          className={`py-1.5 rounded-lg text-[10px] font-semibold flex flex-col items-center gap-0.5 transition-colors cursor-pointer ${
            subTab === 'color'
              ? 'bg-[#8B5CF6] text-white'
              : 'text-[#9494A8] hover:text-white'
          }`}
        >
          <Palette className="w-3.5 h-3.5" />
          <span>Color/Key</span>
        </button>

        <button
          onClick={() => setSubTab('speed')}
          className={`py-1.5 rounded-lg text-[10px] font-semibold flex flex-col items-center gap-0.5 transition-colors cursor-pointer ${
            subTab === 'speed'
              ? 'bg-[#8B5CF6] text-white'
              : 'text-[#9494A8] hover:text-white'
          }`}
        >
          <Gauge className="w-3.5 h-3.5" />
          <span>Speed/FX</span>
        </button>

        <button
          onClick={() => setSubTab('special')}
          className={`py-1.5 rounded-lg text-[10px] font-semibold flex flex-col items-center gap-0.5 transition-colors cursor-pointer ${
            subTab === 'special'
              ? 'bg-[#8B5CF6] text-white'
              : 'text-[#9494A8] hover:text-white'
          }`}
        >
          {selectedClip.type === 'text' ? (
            <>
              <Type className="w-3.5 h-3.5" />
              <span>Typography</span>
            </>
          ) : (
            <>
              <Volume2 className="w-3.5 h-3.5" />
              <span>Audio</span>
            </>
          )}
        </button>
      </div>

      {/* Scrollable Inspector Controls */}
      <div className="flex-1 overflow-y-auto p-3.5 space-y-5">
        {/* SUB-TAB 1: TRANSFORM, CROP & KEYFRAMES */}
        {subTab === 'transform' && (
          <>
            {/* Timing & Duration Readout */}
            <div className="p-2.5 rounded-xl bg-[#181822] border border-[#262636] grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-[#9494A8] block">Start Time (s)</label>
                <input
                  type="number"
                  step={0.1}
                  min={0}
                  value={Number(selectedClip.startTime.toFixed(2))}
                  onChange={(e) =>
                    onUpdateClip(selectedClip.id, {
                      startTime: Math.max(0, Number(e.target.value)),
                    })
                  }
                  className="w-full mt-0.5 px-2 py-1 rounded bg-[#09090E] border border-[#262636] text-xs font-mono-code text-white outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] text-[#9494A8] block">Duration (s)</label>
                <input
                  type="number"
                  step={0.1}
                  min={0.3}
                  max={60}
                  value={Number(selectedClip.duration.toFixed(2))}
                  onChange={(e) =>
                    onUpdateClip(selectedClip.id, {
                      duration: Math.max(0.3, Number(e.target.value)),
                    })
                  }
                  className="w-full mt-0.5 px-2 py-1 rounded bg-[#09090E] border border-[#262636] text-xs font-mono-code text-white outline-none"
                />
              </div>
            </div>

            {/* Spatial Transform Sliders */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-[11px] font-bold uppercase tracking-wider text-[#9494A8]">
                  Spatial Transform
                </h4>
                <button
                  onClick={() =>
                    onUpdateClip(selectedClip.id, {
                      x: 0,
                      y: 0,
                      scale: 100,
                      rotation: 0,
                      opacity: 100,
                      flipH: false,
                      flipV: false,
                      crop: { ...DEFAULT_CROP },
                    })
                  }
                  className="text-[10px] text-[#9494A8] hover:text-white flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3" />
                  Reset
                </button>
              </div>

              {/* Scale */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-[#9494A8]">Scale / Resize</span>
                  <span className="font-mono-code text-[#F4F4F8]">{selectedClip.scale}%</span>
                </div>
                <input
                  type="range"
                  min={10}
                  max={250}
                  value={selectedClip.scale}
                  onChange={(e) =>
                    onUpdateClip(selectedClip.id, { scale: Number(e.target.value) })
                  }
                  className="w-full studio-slider"
                />
              </div>

              {/* Position X & Y */}
              <div className="grid grid-cols-2 gap-2.5">
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-[#9494A8]">Pos X</span>
                    <span className="font-mono-code text-white">{selectedClip.x}%</span>
                  </div>
                  <input
                    type="range"
                    min={-100}
                    max={100}
                    value={selectedClip.x}
                    onChange={(e) =>
                      onUpdateClip(selectedClip.id, { x: Number(e.target.value) })
                    }
                    className="w-full studio-slider"
                  />
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-[#9494A8]">Pos Y</span>
                    <span className="font-mono-code text-white">{selectedClip.y}%</span>
                  </div>
                  <input
                    type="range"
                    min={-100}
                    max={100}
                    value={selectedClip.y}
                    onChange={(e) =>
                      onUpdateClip(selectedClip.id, { y: Number(e.target.value) })
                    }
                    className="w-full studio-slider"
                  />
                </div>
              </div>

              {/* Rotation & Opacity */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-[#9494A8]">Rotation</span>
                  <span className="font-mono-code text-white">{selectedClip.rotation}°</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={360}
                  value={selectedClip.rotation}
                  onChange={(e) =>
                    onUpdateClip(selectedClip.id, { rotation: Number(e.target.value) })
                  }
                  className="w-full studio-slider"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-[#9494A8]">Opacity</span>
                  <span className="font-mono-code text-white">{selectedClip.opacity}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={selectedClip.opacity}
                  onChange={(e) =>
                    onUpdateClip(selectedClip.id, { opacity: Number(e.target.value) })
                  }
                  className="w-full studio-slider"
                />
              </div>

              {/* Flip & Rotate 90° Quick Buttons */}
              <div className="grid grid-cols-3 gap-1.5 pt-1">
                <button
                  onClick={() =>
                    onUpdateClip(selectedClip.id, { flipH: !selectedClip.flipH })
                  }
                  className={`py-1.5 rounded-lg text-[11px] font-semibold flex items-center justify-center gap-1 border cursor-pointer ${
                    selectedClip.flipH
                      ? 'bg-[#8B5CF6]/25 text-[#A855F7] border-[#8B5CF6]'
                      : 'bg-[#181822] text-[#9494A8] border-[#262636]'
                  }`}
                >
                  <FlipHorizontal className="w-3.5 h-3.5" />
                  <span>Flip H</span>
                </button>
                <button
                  onClick={() =>
                    onUpdateClip(selectedClip.id, { flipV: !selectedClip.flipV })
                  }
                  className={`py-1.5 rounded-lg text-[11px] font-semibold flex items-center justify-center gap-1 border cursor-pointer ${
                    selectedClip.flipV
                      ? 'bg-[#8B5CF6]/25 text-[#A855F7] border-[#8B5CF6]'
                      : 'bg-[#181822] text-[#9494A8] border-[#262636]'
                  }`}
                >
                  <FlipVertical className="w-3.5 h-3.5" />
                  <span>Flip V</span>
                </button>
                <button
                  onClick={() =>
                    onUpdateClip(selectedClip.id, {
                      rotation: (selectedClip.rotation + 90) % 360,
                    })
                  }
                  className="py-1.5 rounded-lg text-[11px] font-semibold bg-[#181822] hover:bg-[#262636] text-[#F4F4F8] border border-[#262636] cursor-pointer"
                >
                  +90° Rot
                </button>
              </div>
            </div>

            {/* Edge Crop Controls */}
            {(selectedClip.type === 'video' || selectedClip.type === 'image') && (
              <div className="space-y-2.5 pt-3 border-t border-[#262636]">
                <h4 className="text-[11px] font-bold uppercase tracking-wider text-[#9494A8]">
                  Crop Edges (%)
                </h4>
                <div className="grid grid-cols-2 gap-2">
                  {(['top', 'bottom', 'left', 'right'] as const).map((edge) => (
                    <div key={edge} className="space-y-1">
                      <div className="flex justify-between text-[10px]">
                        <span className="capitalize text-[#9494A8]">{edge}</span>
                        <span className="font-mono-code text-white">
                          {selectedClip.crop[edge]}%
                        </span>
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={45}
                        value={selectedClip.crop[edge]}
                        onChange={(e) =>
                          onUpdateClip(selectedClip.id, {
                            crop: {
                              ...selectedClip.crop,
                              [edge]: Number(e.target.value),
                            },
                          })
                        }
                        className="w-full studio-slider"
                      />
                    </div>
                  ))}
                </div>

                {/* Ambient Blur Background Toggle */}
                <label className="flex items-center justify-between p-2 rounded-lg bg-[#181822] border border-[#262636] cursor-pointer mt-2">
                  <span className="text-xs text-[#F4F4F8]">Blur Canvas Background Fill</span>
                  <input
                    type="checkbox"
                    checked={selectedClip.backgroundBlurFill}
                    onChange={(e) =>
                      onUpdateClip(selectedClip.id, {
                        backgroundBlurFill: e.target.checked,
                      })
                    }
                    className="accent-[#8B5CF6] w-4 h-4"
                  />
                </label>
              </div>
            )}

            {/* Keyframe Animation Engine (◆) */}
            <div className="p-3 rounded-xl bg-[#181822] border border-[#262636] space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#F4F4F8] flex items-center gap-1.5">
                  <Diamond className="w-3.5 h-3.5 text-[#F59E0B] fill-current" />
                  Keyframes ({selectedClip.keyframes.length})
                </span>
                <button
                  onClick={handleAddKeyframe}
                  className="px-2 py-1 rounded-md bg-[#F59E0B]/20 hover:bg-[#F59E0B] text-[#F59E0B] hover:text-black text-[10px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <Plus className="w-3 h-3" />
                  <span>Add ◆ at +{localOffset.toFixed(1)}s</span>
                </button>
              </div>
              {selectedClip.keyframes.length === 0 ? (
                <p className="text-[10px] text-[#9494A8]">
                  Move playhead within clip, adjust Scale/Position/Rotation, and click &ldquo;Add ◆&rdquo; to animate smoothly between keyframes.
                </p>
              ) : (
                <div className="space-y-1">
                  {selectedClip.keyframes.map((kf, idx) => (
                    <div
                      key={kf.id}
                      className="flex items-center justify-between px-2 py-1 rounded bg-[#09090E] border border-[#262636] text-[10px] font-mono-code"
                    >
                      <button
                        onClick={() => onSeek(selectedClip.startTime + kf.timeOffset)}
                        className="text-[#F59E0B] hover:underline cursor-pointer"
                      >
                        ◆ KF#{idx + 1} @ +{kf.timeOffset.toFixed(2)}s (Scale {kf.scale}%)
                      </button>
                      <button
                        onClick={() => handleRemoveKeyframe(kf.id)}
                        className="text-[#9494A8] hover:text-[#EF4444] cursor-pointer"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </>
        )}

        {/* SUB-TAB 2: COLOR GRADING, FILTERS & CHROMA KEY */}
        {subTab === 'color' && (
          <>
            {/* Green-Screen Chroma Key Background Removal */}
            <div className="p-3 rounded-xl bg-gradient-to-br from-[#10B981]/15 to-[#181822] border border-[#10B981]/40 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#F4F4F8] flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-[#10B981]" />
                  Chroma Key (Green Screen)
                </span>
                <input
                  type="checkbox"
                  checked={selectedClip.chromaKey.enabled}
                  onChange={(e) =>
                    onUpdateClip(selectedClip.id, {
                      chromaKey: {
                        ...selectedClip.chromaKey,
                        enabled: e.target.checked,
                      },
                    })
                  }
                  className="accent-[#10B981] w-4 h-4 cursor-pointer"
                />
              </div>

              {selectedClip.chromaKey.enabled && (
                <div className="space-y-2.5 pt-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-[#9494A8]">Key Color</span>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() =>
                          onUpdateClip(selectedClip.id, {
                            chromaKey: { ...selectedClip.chromaKey, keyColor: '#00FF00' },
                          })
                        }
                        className="px-1.5 py-0.5 rounded text-[10px] font-mono-code bg-[#00FF00]/20 text-[#00FF00] border border-[#00FF00]/40 cursor-pointer"
                      >
                        Green
                      </button>
                      <button
                        onClick={() =>
                          onUpdateClip(selectedClip.id, {
                            chromaKey: { ...selectedClip.chromaKey, keyColor: '#0044FF' },
                          })
                        }
                        className="px-1.5 py-0.5 rounded text-[10px] font-mono-code bg-[#0044FF]/20 text-[#60A5FA] border border-[#0044FF]/40 cursor-pointer"
                      >
                        Blue
                      </button>
                      <input
                        type="color"
                        value={selectedClip.chromaKey.keyColor}
                        onChange={(e) =>
                          onUpdateClip(selectedClip.id, {
                            chromaKey: {
                              ...selectedClip.chromaKey,
                              keyColor: e.target.value,
                            },
                          })
                        }
                        className="w-6 h-6 rounded border border-[#262636] bg-transparent cursor-pointer"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-[11px]">
                      <span className="text-[#9494A8]">Similarity Threshold</span>
                      <span className="font-mono-code text-white">
                        {selectedClip.chromaKey.similarity}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={1}
                      max={95}
                      value={selectedClip.chromaKey.similarity}
                      onChange={(e) =>
                        onUpdateClip(selectedClip.id, {
                          chromaKey: {
                            ...selectedClip.chromaKey,
                            similarity: Number(e.target.value),
                          },
                        })
                      }
                      className="w-full studio-slider"
                    />
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-[11px]">
                      <span className="text-[#9494A8]">Edge Feather / Smoothness</span>
                      <span className="font-mono-code text-white">
                        {selectedClip.chromaKey.smoothness}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={50}
                      value={selectedClip.chromaKey.smoothness}
                      onChange={(e) =>
                        onUpdateClip(selectedClip.id, {
                          chromaKey: {
                            ...selectedClip.chromaKey,
                            smoothness: Number(e.target.value),
                          },
                        })
                      }
                      className="w-full studio-slider"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Color Grading Sliders */}
            <div className="space-y-2.5">
              <div className="flex items-center justify-between">
                <h4 className="text-[11px] font-bold uppercase tracking-wider text-[#9494A8]">
                  Color Correction & Grading
                </h4>
                <button
                  onClick={() =>
                    onUpdateClip(selectedClip.id, {
                      color: { ...DEFAULT_COLOR_GRADING },
                    })
                  }
                  className="text-[10px] text-[#9494A8] hover:text-white flex items-center gap-1 cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3" />
                  Reset
                </button>
              </div>

              {/* Filter Preset Dropdown */}
              <div className="space-y-1">
                <label className="text-[11px] text-[#9494A8]">LUT Filter Preset</label>
                <select
                  value={selectedClip.color.filterPreset}
                  onChange={(e) =>
                    onUpdateClip(selectedClip.id, {
                      color: {
                        ...selectedClip.color,
                        filterPreset: e.target.value as FilterPreset,
                      },
                    })
                  }
                  className="w-full bg-[#181822] border border-[#262636] rounded-lg px-2.5 py-1.5 text-xs text-white outline-none"
                >
                  {FILTER_PRESETS_INFO.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
                </select>
              </div>

              {(
                [
                  { key: 'brightness', label: 'Brightness', min: -80, max: 80 },
                  { key: 'contrast', label: 'Contrast', min: -80, max: 80 },
                  { key: 'saturation', label: 'Saturation', min: -100, max: 100 },
                  { key: 'exposure', label: 'Exposure', min: -80, max: 80 },
                  { key: 'temperature', label: 'Temp (Cool / Warm)', min: -100, max: 100 },
                  { key: 'hue', label: 'Hue Shift (°)', min: -180, max: 180 },
                  { key: 'vignette', label: 'Cinema Vignette', min: 0, max: 100 },
                  { key: 'blur', label: 'Gaussian Blur', min: 0, max: 40 },
                ] as const
              ).map((item) => (
                <div key={item.key} className="space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-[#9494A8]">{item.label}</span>
                    <span className="font-mono-code text-white">
                      {selectedClip.color[item.key]}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={item.min}
                    max={item.max}
                    value={selectedClip.color[item.key]}
                    onChange={(e) =>
                      onUpdateClip(selectedClip.id, {
                        color: {
                          ...selectedClip.color,
                          [item.key]: Number(e.target.value),
                        },
                      })
                    }
                    className="w-full studio-slider"
                  />
                </div>
              ))}
            </div>
          </>
        )}

        {/* SUB-TAB 3: SPEED, SPEED RAMPING, REVERSE & TRANSITIONS */}
        {subTab === 'speed' && (
          <>
            {/* Speed Multiplier */}
            <div className="space-y-2.5">
              <div className="flex justify-between text-xs">
                <span className="font-bold text-[#F4F4F8]">Playback Speed</span>
                <span className="font-mono-code font-bold text-[#A855F7]">
                  {selectedClip.speed.toFixed(2)}x
                </span>
              </div>
              <input
                type="range"
                min={0.25}
                max={4}
                step={0.05}
                value={selectedClip.speed}
                onChange={(e) =>
                  onUpdateClip(selectedClip.id, { speed: Number(e.target.value) })
                }
                className="w-full studio-slider"
              />
              <div className="grid grid-cols-5 gap-1">
                {[0.25, 0.5, 1, 2, 4].map((spd) => (
                  <button
                    key={spd}
                    onClick={() => onUpdateClip(selectedClip.id, { speed: spd })}
                    className={`py-1 rounded text-[10px] font-mono-code font-semibold border cursor-pointer ${
                      selectedClip.speed === spd
                        ? 'bg-[#8B5CF6] text-white border-[#A855F7]'
                        : 'bg-[#181822] text-[#9494A8] border-[#262636]'
                    }`}
                  >
                    {spd}x
                  </button>
                ))}
              </div>
            </div>

            {/* Speed Ramping Curves */}
            <div className="space-y-1.5 pt-2 border-t border-[#262636]">
              <label className="text-xs font-bold text-[#F4F4F8] block">
                Velocity / Speed Ramp Curve
              </label>
              <div className="grid grid-cols-1 gap-1.5">
                {(
                  [
                    { id: 'constant', label: 'Linear Constant Speed' },
                    { id: 'montage', label: 'Montage Ramp (Fast → Slow → Fast)' },
                    { id: 'hero-slowmo', label: 'Hero Drop (Normal → 0.35x Slow-Mo)' },
                    { id: 'jump-boost', label: 'Jump Cut Velocity Punch' },
                    { id: 'bullet-time', label: 'Matrix Bullet-Time Curve' },
                  ] as { id: SpeedRampPreset; label: string }[]
                ).map((curve) => (
                  <button
                    key={curve.id}
                    onClick={() =>
                      onUpdateClip(selectedClip.id, { speedRamp: curve.id })
                    }
                    className={`px-3 py-1.5 rounded-lg text-left text-xs font-medium border transition-colors cursor-pointer ${
                      selectedClip.speedRamp === curve.id
                        ? 'bg-[#8B5CF6]/20 text-[#A855F7] border-[#8B5CF6]'
                        : 'bg-[#181822] text-[#9494A8] border-[#262636] hover:text-white'
                    }`}
                  >
                    {curve.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Reverse Playback Toggle */}
            <label className="flex items-center justify-between p-2.5 rounded-xl bg-[#181822] border border-[#262636] cursor-pointer">
              <span className="text-xs font-semibold text-[#F4F4F8]">
                Reverse Clip Playback
              </span>
              <input
                type="checkbox"
                checked={selectedClip.reverse}
                onChange={(e) =>
                  onUpdateClip(selectedClip.id, { reverse: e.target.checked })
                }
                className="accent-[#8B5CF6] w-4 h-4"
              />
            </label>

            {/* Clip In / Out Transitions */}
            <div className="space-y-3 pt-2 border-t border-[#262636]">
              <h4 className="text-[11px] font-bold uppercase tracking-wider text-[#9494A8]">
                Entry & Exit Transitions
              </h4>

              <div className="space-y-1">
                <label className="text-[11px] text-[#9494A8]">Entry Transition (In)</label>
                <select
                  value={selectedClip.transitionIn.type}
                  onChange={(e) =>
                    onUpdateClip(selectedClip.id, {
                      transitionIn: {
                        ...selectedClip.transitionIn,
                        type: e.target.value as TransitionType,
                      },
                    })
                  }
                  className="w-full bg-[#181822] border border-[#262636] rounded-lg px-2.5 py-1.5 text-xs text-white outline-none"
                >
                  {TRANSITION_PRESETS.map((tr) => (
                    <option key={tr.id} value={tr.id}>
                      {tr.name} ({tr.badge})
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] text-[#9494A8]">Exit Transition (Out)</label>
                <select
                  value={selectedClip.transitionOut.type}
                  onChange={(e) =>
                    onUpdateClip(selectedClip.id, {
                      transitionOut: {
                        ...selectedClip.transitionOut,
                        type: e.target.value as TransitionType,
                      },
                    })
                  }
                  className="w-full bg-[#181822] border border-[#262636] rounded-lg px-2.5 py-1.5 text-xs text-white outline-none"
                >
                  {TRANSITION_PRESETS.map((tr) => (
                    <option key={tr.id} value={tr.id}>
                      {tr.name} ({tr.badge})
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </>
        )}

        {/* SUB-TAB 4: CONTEXTUAL TYPOGRAPHY OR AUDIO PROCESSING */}
        {subTab === 'special' && (
          <>
            {selectedClip.type === 'text' && selectedClip.textStyle ? (
              <div className="space-y-3">
                <div className="space-y-1">
                  <label className="text-[11px] font-semibold text-[#9494A8]">
                    Caption / Title Text
                  </label>
                  <textarea
                    rows={2}
                    value={selectedClip.textStyle.text}
                    onChange={(e) =>
                      onUpdateClip(selectedClip.id, {
                        name: e.target.value,
                        textStyle: {
                          ...selectedClip.textStyle!,
                          text: e.target.value,
                        },
                      })
                    }
                    className="w-full p-2 rounded-lg bg-[#09090E] border border-[#262636] focus:border-[#8B5CF6] text-xs text-white outline-none"
                  />
                </div>

                {/* Font Family & Size */}
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-[#9494A8] block">Font Family</label>
                    <select
                      value={selectedClip.textStyle.fontFamily}
                      onChange={(e) =>
                        onUpdateClip(selectedClip.id, {
                          textStyle: {
                            ...selectedClip.textStyle!,
                            fontFamily: e.target.value as typeof selectedClip.textStyle.fontFamily,
                          },
                        })
                      }
                      className="w-full mt-0.5 bg-[#181822] border border-[#262636] rounded px-2 py-1 text-xs text-white outline-none"
                    >
                      <option value="Plus Jakarta Sans">Plus Jakarta</option>
                      <option value="Inter">Inter Studio</option>
                      <option value="JetBrains Mono">JetBrains Mono</option>
                      <option value="Impact">Impact Bold</option>
                      <option value="Georgia">Georgia Serif</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] text-[#9494A8] block">
                      Size ({selectedClip.textStyle.fontSize}px)
                    </label>
                    <input
                      type="range"
                      min={18}
                      max={96}
                      value={selectedClip.textStyle.fontSize}
                      onChange={(e) =>
                        onUpdateClip(selectedClip.id, {
                          textStyle: {
                            ...selectedClip.textStyle!,
                            fontSize: Number(e.target.value),
                          },
                        })
                      }
                      className="w-full mt-2 studio-slider"
                    />
                  </div>
                </div>

                {/* Text Animation */}
                <div className="space-y-1">
                  <label className="text-[11px] text-[#9494A8]">Text Motion Animation</label>
                  <select
                    value={selectedClip.textStyle.animation}
                    onChange={(e) =>
                      onUpdateClip(selectedClip.id, {
                        textStyle: {
                          ...selectedClip.textStyle!,
                          animation: e.target.value as TextAnimationType,
                        },
                      })
                    }
                    className="w-full bg-[#181822] border border-[#262636] rounded-lg px-2.5 py-1.5 text-xs text-white outline-none"
                  >
                    <option value="none">None (Static)</option>
                    <option value="bounce">Viral Bounce Pop</option>
                    <option value="typewriter">Typewriter Reveal</option>
                    <option value="fade-up">Smooth Fade Up</option>
                    <option value="slide-in">Whip Slide In</option>
                    <option value="wave">Floating Sine Wave</option>
                    <option value="glitch">Cyber Glitch Jitter</option>
                  </select>
                </div>

                {/* Colors, Gradient, Outline & Shadow */}
                <div className="grid grid-cols-2 gap-2.5 pt-1">
                  <div className="flex items-center justify-between p-2 rounded-lg bg-[#181822] border border-[#262636]">
                    <span className="text-[11px] text-[#9494A8]">Fill</span>
                    <input
                      type="color"
                      value={selectedClip.textStyle.color}
                      onChange={(e) =>
                        onUpdateClip(selectedClip.id, {
                          textStyle: {
                            ...selectedClip.textStyle!,
                            color: e.target.value,
                          },
                        })
                      }
                      className="w-6 h-6 bg-transparent cursor-pointer"
                    />
                  </div>
                  <div className="flex items-center justify-between p-2 rounded-lg bg-[#181822] border border-[#262636]">
                    <span className="text-[11px] text-[#9494A8]">Outline</span>
                    <input
                      type="color"
                      value={selectedClip.textStyle.outlineColor}
                      onChange={(e) =>
                        onUpdateClip(selectedClip.id, {
                          textStyle: {
                            ...selectedClip.textStyle!,
                            outlineColor: e.target.value,
                          },
                        })
                      }
                      className="w-6 h-6 bg-transparent cursor-pointer"
                    />
                  </div>
                </div>

                <label className="flex items-center justify-between p-2 rounded-lg bg-[#181822] border border-[#262636] cursor-pointer">
                  <span className="text-xs text-[#F4F4F8]">Dual-Tone Gradient Text</span>
                  <input
                    type="checkbox"
                    checked={selectedClip.textStyle.useGradient}
                    onChange={(e) =>
                      onUpdateClip(selectedClip.id, {
                        textStyle: {
                          ...selectedClip.textStyle!,
                          useGradient: e.target.checked,
                        },
                      })
                    }
                    className="accent-[#8B5CF6] w-4 h-4"
                  />
                </label>

                <div className="space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-[#9494A8]">Outline Thickness</span>
                    <span className="font-mono-code text-white">
                      {selectedClip.textStyle.outlineWidth}px
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={10}
                    value={selectedClip.textStyle.outlineWidth}
                    onChange={(e) =>
                      onUpdateClip(selectedClip.id, {
                        textStyle: {
                          ...selectedClip.textStyle!,
                          outlineWidth: Number(e.target.value),
                        },
                      })
                    }
                    className="w-full studio-slider"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-[#9494A8]">Glow / Shadow Blur</span>
                    <span className="font-mono-code text-white">
                      {selectedClip.textStyle.shadowBlur}px
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={40}
                    value={selectedClip.textStyle.shadowBlur}
                    onChange={(e) =>
                      onUpdateClip(selectedClip.id, {
                        textStyle: {
                          ...selectedClip.textStyle!,
                          shadowBlur: Number(e.target.value),
                        },
                      })
                    }
                    className="w-full studio-slider"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="text-[#9494A8]">Pill Background Opacity</span>
                    <span className="font-mono-code text-white">
                      {selectedClip.textStyle.bgOpacity}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={selectedClip.textStyle.bgOpacity}
                    onChange={(e) =>
                      onUpdateClip(selectedClip.id, {
                        textStyle: {
                          ...selectedClip.textStyle!,
                          bgOpacity: Number(e.target.value),
                        },
                      })
                    }
                    className="w-full studio-slider"
                  />
                </div>
              </div>
            ) : (
              /* Audio Settings for Audio or Video Clip */
              <div className="space-y-3.5">
                {(() => {
                  const aud = selectedClip.audioSettings || {
                    volume: 100,
                    fadeIn: 0,
                    fadeOut: 0,
                    noiseReduction: false,
                    voiceEnhance: false,
                  };
                  return (
                    <>
                      <div className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="font-semibold text-[#F4F4F8]">Clip Volume Gain</span>
                          <span className="font-mono-code text-[#10B981] font-bold">
                            {aud.volume}%
                          </span>
                        </div>
                        <input
                          type="range"
                          min={0}
                          max={200}
                          value={aud.volume}
                          onChange={(e) =>
                            onUpdateClip(selectedClip.id, {
                              audioSettings: { ...aud, volume: Number(e.target.value) },
                            })
                          }
                          className="w-full studio-slider"
                        />
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="text-[#9494A8]">Fade In Duration</span>
                          <span className="font-mono-code text-white">
                            {aud.fadeIn.toFixed(1)}s
                          </span>
                        </div>
                        <input
                          type="range"
                          min={0}
                          max={4}
                          step={0.1}
                          value={aud.fadeIn}
                          onChange={(e) =>
                            onUpdateClip(selectedClip.id, {
                              audioSettings: { ...aud, fadeIn: Number(e.target.value) },
                            })
                          }
                          className="w-full studio-slider"
                        />
                      </div>

                      <div className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="text-[#9494A8]">Fade Out Duration</span>
                          <span className="font-mono-code text-white">
                            {aud.fadeOut.toFixed(1)}s
                          </span>
                        </div>
                        <input
                          type="range"
                          min={0}
                          max={4}
                          step={0.1}
                          value={aud.fadeOut}
                          onChange={(e) =>
                            onUpdateClip(selectedClip.id, {
                              audioSettings: { ...aud, fadeOut: Number(e.target.value) },
                            })
                          }
                          className="w-full studio-slider"
                        />
                      </div>

                      {/* AI Audio Cleanup & Voice Enhancement */}
                      <div className="p-3 rounded-xl bg-[#181822] border border-[#262636] space-y-2.5">
                        <h5 className="text-xs font-bold text-[#F4F4F8] flex items-center gap-1.5">
                          <Sparkles className="w-3.5 h-3.5 text-[#10B981]" />
                          DSP Voice & Noise Processing
                        </h5>

                        <label className="flex items-center justify-between text-xs text-[#9494A8] cursor-pointer">
                          <span>AI Background Noise Reduction</span>
                          <input
                            type="checkbox"
                            checked={aud.noiseReduction}
                            onChange={(e) =>
                              onUpdateClip(selectedClip.id, {
                                audioSettings: { ...aud, noiseReduction: e.target.checked },
                              })
                            }
                            className="accent-[#10B981] w-4 h-4"
                          />
                        </label>

                        <label className="flex items-center justify-between text-xs text-[#9494A8] cursor-pointer">
                          <span>Studio Vocal Presence EQ Boost</span>
                          <input
                            type="checkbox"
                            checked={aud.voiceEnhance}
                            onChange={(e) =>
                              onUpdateClip(selectedClip.id, {
                                audioSettings: { ...aud, voiceEnhance: e.target.checked },
                              })
                            }
                            className="accent-[#10B981] w-4 h-4"
                          />
                        </label>
                      </div>
                    </>
                  );
                })()}
              </div>
            )}
          </>
        )}
      </div>
    </aside>
  );
};
