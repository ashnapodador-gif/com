import React, { useRef } from 'react';
import {
  Plus,
  X,
  FolderOpen,
  Clock,
  Sparkles,
  Trash2,
  Copy,
  Upload,
  FileJson,
  Play,
  Smartphone,
  Monitor,
  Square,
  RectangleVertical,
} from 'lucide-react';
import { AspectRatioOption, ProjectData } from '../types/editor';
import { STARTER_TEMPLATES } from '../data/presets';

interface HomeDashboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  savedProjects: ProjectData[];
  currentProjectId: string;
  onCreateNewProject: (aspectRatio: AspectRatioOption, title?: string) => void;
  onSelectProject: (project: ProjectData) => void;
  onDeleteProject: (projectId: string) => void;
  onDuplicateProject: (project: ProjectData) => void;
  onImportProjectJson: (project: ProjectData) => void;
  onExportCurrentProjectJson: () => void;
}

export const HomeDashboardModal: React.FC<HomeDashboardModalProps> = ({
  isOpen,
  onClose,
  savedProjects,
  currentProjectId,
  onCreateNewProject,
  onSelectProject,
  onDeleteProject,
  onDuplicateProject,
  onImportProjectJson,
  onExportCurrentProjectJson,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleImportJsonChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result)) as ProjectData;
        if (parsed && Array.isArray(parsed.tracks) && Array.isArray(parsed.clips)) {
          onImportProjectJson(parsed);
          onClose();
        }
      } catch {
        alert('Invalid Kinetix project JSON file.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-6">
      <div className="w-full max-w-5xl max-h-[90vh] bg-[#111118] border border-[#262636] rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="px-6 py-4 bg-[#181822] border-b border-[#262636] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#8B5CF6] via-[#A855F7] to-[#EC4899] flex items-center justify-center shadow-[0_0_20px_rgba(139,92,246,0.5)]">
              <span className="font-display font-extrabold text-lg text-white">K</span>
            </div>
            <div>
              <h2 className="font-display font-bold text-base sm:text-lg text-[#F4F4F8] flex items-center gap-2">
                Kinetix Studio Hub
                <span className="text-[10px] font-mono-code uppercase tracking-wider px-2 py-0.5 rounded-full bg-[#8B5CF6]/20 text-[#A855F7] border border-[#8B5CF6]/40">
                  PRO v2.6
                </span>
              </h2>
              <p className="text-xs text-[#9494A8]">
                Create a new multi-track timeline, launch an AI-ready template, or resume a saved draft.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              onChange={handleImportJsonChange}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-[#111118] hover:bg-[#1F1F2E] text-[#F4F4F8] border border-[#262636] transition-colors cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5 text-[#8B5CF6]" />
              <span className="hidden sm:inline">Import Project</span>
            </button>
            <button
              onClick={onExportCurrentProjectJson}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-[#111118] hover:bg-[#1F1F2E] text-[#F4F4F8] border border-[#262636] transition-colors cursor-pointer"
            >
              <FileJson className="w-3.5 h-3.5 text-[#10B981]" />
              <span className="hidden sm:inline">Backup JSON</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-lg text-[#9494A8] hover:text-white hover:bg-[#1F1F2E] transition-colors cursor-pointer"
              aria-label="Close Dashboard"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 overflow-y-auto space-y-8">
          {/* 1. Hero New Project Banner + Aspect Ratio Presets */}
          <section>
            <div className="relative rounded-2xl p-5 sm:p-6 bg-gradient-to-r from-[#1E1438] via-[#17132A] to-[#111118] border border-[#8B5CF6]/40 overflow-hidden">
              <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-5">
                <div className="space-y-1.5 max-w-lg">
                  <div className="inline-flex items-center gap-1.5 text-[11px] font-semibold text-[#A855F7]">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>START A NEW PRODUCTION</span>
                  </div>
                  <h3 className="font-display font-bold text-xl sm:text-2xl text-white">
                    Create Blank Multi-Track Project
                  </h3>
                  <p className="text-xs sm:text-sm text-[#9494A8]">
                    Select your target canvas format below. You can dynamically smart-reframe aspect ratios at any time in the editor.
                  </p>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {[
                    {
                      ar: '16:9' as AspectRatioOption,
                      label: 'YouTube / PC',
                      sub: '16:9 Widescreen',
                      icon: <Monitor className="w-5 h-5 text-[#A855F7]" />,
                    },
                    {
                      ar: '9:16' as AspectRatioOption,
                      label: 'TikTok / Shorts',
                      sub: '9:16 Vertical',
                      icon: <Smartphone className="w-5 h-5 text-[#EC4899]" />,
                    },
                    {
                      ar: '1:1' as AspectRatioOption,
                      label: 'Instagram Grid',
                      sub: '1:1 Square',
                      icon: <Square className="w-5 h-5 text-[#22D3EE]" />,
                    },
                    {
                      ar: '4:5' as AspectRatioOption,
                      label: 'Social Feed',
                      sub: '4:5 Portrait',
                      icon: <RectangleVertical className="w-5 h-5 text-[#10B981]" />,
                    },
                  ].map((item) => (
                    <button
                      key={item.ar}
                      onClick={() => {
                        onCreateNewProject(item.ar, `Untitled ${item.ar} Cut`);
                        onClose();
                      }}
                      className="flex flex-col items-center justify-center p-3.5 rounded-xl bg-[#111118]/90 hover:bg-[#1F1F2E] border border-[#262636] hover:border-[#8B5CF6] transition-all group cursor-pointer"
                    >
                      <div className="mb-2 p-2 rounded-lg bg-[#181822] group-hover:scale-110 transition-transform">
                        {item.icon}
                      </div>
                      <span className="text-xs font-bold text-[#F4F4F8]">{item.label}</span>
                      <span className="text-[10px] font-mono-code text-[#9494A8]">{item.sub}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </section>

          {/* 2. Starter Templates */}
          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-display font-bold text-sm uppercase tracking-wider text-[#9494A8] flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#A855F7]" />
                Studio Starter Templates (One-Click Timeline Load)
              </h4>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {STARTER_TEMPLATES.map((tpl) => (
                <div
                  key={tpl.id}
                  onClick={() => {
                    onSelectProject(tpl.buildProject());
                    onClose();
                  }}
                  className="group relative rounded-xl bg-[#181822] border border-[#262636] hover:border-[#8B5CF6] overflow-hidden transition-all cursor-pointer flex flex-col"
                >
                  <div className="relative h-36 bg-[#09090E] overflow-hidden">
                    <img
                      src={tpl.thumbnail}
                      alt={tpl.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 opacity-85"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#181822] via-transparent to-black/40" />
                    <span className="absolute top-2.5 left-2.5 px-2 py-0.5 rounded text-[10px] font-mono-code font-bold bg-[#8B5CF6] text-white">
                      {tpl.badge}
                    </span>
                    <span className="absolute bottom-2.5 right-2.5 px-2 py-0.5 rounded text-[10px] font-mono-code bg-black/75 text-[#F4F4F8]">
                      {tpl.durationLabel}
                    </span>
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
                      <div className="px-3 py-1.5 rounded-full bg-[#8B5CF6] text-white text-xs font-semibold flex items-center gap-1.5 shadow-lg">
                        <Play className="w-3.5 h-3.5 fill-current" />
                        Load Template
                      </div>
                    </div>
                  </div>
                  <div className="p-3.5">
                    <h5 className="font-semibold text-sm text-[#F4F4F8] group-hover:text-[#A855F7] transition-colors">
                      {tpl.title}
                    </h5>
                    <p className="text-xs text-[#9494A8] mt-0.5">{tpl.category}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* 3. Recent Projects & Saved Drafts */}
          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-display font-bold text-sm uppercase tracking-wider text-[#9494A8] flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#10B981]" />
                Recent Projects & Saved Drafts ({savedProjects.length})
              </h4>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
              {savedProjects.map((proj) => {
                const isCurrent = proj.id === currentProjectId;
                return (
                  <div
                    key={proj.id}
                    className={`p-3.5 rounded-xl bg-[#181822] border transition-all flex flex-col justify-between gap-3 ${
                      isCurrent
                        ? 'border-[#8B5CF6] ring-1 ring-[#8B5CF6]/40'
                        : 'border-[#262636] hover:border-[#5A5A70]'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div
                        className="min-w-0 flex-1 cursor-pointer"
                        onClick={() => {
                          onSelectProject(proj);
                          onClose();
                        }}
                      >
                        <div className="flex items-center gap-2">
                          <h5 className="font-semibold text-sm text-[#F4F4F8] truncate">
                            {proj.name}
                          </h5>
                          {isCurrent && (
                            <span className="px-1.5 py-0.5 rounded text-[9px] font-mono-code font-bold bg-[#10B981]/20 text-[#10B981] border border-[#10B981]/40">
                              ACTIVE
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 mt-1 text-[11px] font-mono-code text-[#9494A8]">
                          <span>{proj.aspectRatio}</span>
                          <span>•</span>
                          <span>{proj.fps} FPS</span>
                          <span>•</span>
                          <span>{proj.clips.length} clips</span>
                        </div>
                        <p className="text-[11px] text-[#5A5A70] mt-1">
                          Updated {new Date(proj.updatedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-[#262636]">
                      <button
                        onClick={() => {
                          onSelectProject(proj);
                          onClose();
                        }}
                        className="flex items-center gap-1 text-xs font-semibold text-[#A855F7] hover:text-white transition-colors cursor-pointer"
                      >
                        <FolderOpen className="w-3.5 h-3.5" />
                        <span>Open in Editor</span>
                      </button>

                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => onDuplicateProject(proj)}
                          title="Duplicate Draft"
                          className="p-1.5 rounded hover:bg-[#262636] text-[#9494A8] hover:text-white transition-colors cursor-pointer"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                        {savedProjects.length > 1 && (
                          <button
                            onClick={() => onDeleteProject(proj.id)}
                            title="Delete Draft"
                            className="p-1.5 rounded hover:bg-[#EF4444]/20 text-[#9494A8] hover:text-[#EF4444] transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}

              {/* Quick + Card */}
              <button
                onClick={() => {
                  onCreateNewProject('16:9', 'New Studio Project');
                  onClose();
                }}
                className="p-4 rounded-xl border border-dashed border-[#262636] hover:border-[#8B5CF6] bg-[#111118]/50 hover:bg-[#181822] flex flex-col items-center justify-center gap-2 text-[#9494A8] hover:text-[#F4F4F8] transition-all min-h-[110px] cursor-pointer"
              >
                <Plus className="w-6 h-6 text-[#8B5CF6]" />
                <span className="text-xs font-semibold">Create Empty Draft</span>
              </button>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};
