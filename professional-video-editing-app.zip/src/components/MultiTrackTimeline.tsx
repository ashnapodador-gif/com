import React, { useRef, useState } from 'react';
import {
  Scissors,
  Merge,
  Copy,
  Trash2,
  Magnet,
  ZoomIn,
  ZoomOut,
  Volume2,
  VolumeX,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  Plus,
  Diamond,
  Film,
  Type,
  Music,
  Sparkles,
} from 'lucide-react';
import {
  TimelineClip,
  TimelineTrack,
  TrackType,
} from '../types/editor';

interface MultiTrackTimelineProps {
  tracks: TimelineTrack[];
  clips: TimelineClip[];
  currentTime: number;
  totalDuration: number;
  selectedClipId: string | null;
  beatMarkers: number[];
  zoomPxPerSec: number;
  snapEnabled: boolean;
  onChangeZoom: (px: number) => void;
  onToggleSnap: () => void;
  onSeek: (time: number) => void;
  onSelectClip: (id: string | null) => void;
  onUpdateClip: (id: string, patch: Partial<TimelineClip>, recordHistory?: boolean) => void;
  onSplitAtPlayhead: () => void;
  onMergeAdjacentClips: () => void;
  onDuplicateSelected: () => void;
  onDeleteSelected: () => void;
  onToggleTrackMute: (trackId: string) => void;
  onToggleTrackLock: (trackId: string) => void;
  onToggleTrackHidden: (trackId: string) => void;
  onAddTrack: (type: TrackType) => void;
  onAddBeatMarkerAtPlayhead: () => void;
  onDropMediaOnTrack: (mediaId: string, trackId: string, dropTime: number) => void;
}

export const MultiTrackTimeline: React.FC<MultiTrackTimelineProps> = ({
  tracks,
  clips,
  currentTime,
  totalDuration,
  selectedClipId,
  beatMarkers,
  zoomPxPerSec,
  snapEnabled,
  onChangeZoom,
  onToggleSnap,
  onSeek,
  onSelectClip,
  onUpdateClip,
  onSplitAtPlayhead,
  onMergeAdjacentClips,
  onDuplicateSelected,
  onDeleteSelected,
  onToggleTrackMute,
  onToggleTrackLock,
  onToggleTrackHidden,
  onAddTrack,
  onAddBeatMarkerAtPlayhead,
  onDropMediaOnTrack,
}) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [isScrubbingRuler, setIsScrubbingRuler] = useState(false);

  // Dragging clip state (move, trim-left, trim-right)
  const [dragState, setDragState] = useState<{
    clipId: string;
    mode: 'move' | 'trim-left' | 'trim-right';
    startClientX: number;
    origStartTime: number;
    origDuration: number;
    origTrimStart: number;
  } | null>(null);

  const timelineSecondsSpan = Math.max(18, Math.ceil(totalDuration + 6));
  const totalWidthPx = timelineSecondsSpan * zoomPxPerSec;

  // Snap helper
  const snapTime = (rawTime: number, excludeClipId?: string): number => {
    if (!snapEnabled) return Math.max(0, Number(rawTime.toFixed(2)));
    const snapPoints: number[] = [0, currentTime, ...beatMarkers];
    for (const c of clips) {
      if (c.id === excludeClipId) continue;
      snapPoints.push(c.startTime, c.startTime + c.duration);
    }
    const thresholdSec = 8 / zoomPxPerSec;
    for (const pt of snapPoints) {
      if (Math.abs(rawTime - pt) <= thresholdSec) {
        return Math.max(0, Number(pt.toFixed(2)));
      }
    }
    return Math.max(0, Number(rawTime.toFixed(2)));
  };

  // Convert clientX in scroll container to timeline time
  const clientXToTime = (clientX: number): number => {
    if (!scrollContainerRef.current) return 0;
    const rect = scrollContainerRef.current.getBoundingClientRect();
    const offsetX = clientX - rect.left + scrollContainerRef.current.scrollLeft;
    return Math.max(0, offsetX / zoomPxPerSec);
  };

  const handleRulerPointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    setIsScrubbingRuler(true);
    onSeek(clientXToTime(e.clientX));
  };

  const handleRulerPointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!isScrubbingRuler) return;
    onSeek(clientXToTime(e.clientX));
  };

  const handleRulerPointerUp = () => {
    setIsScrubbingRuler(false);
  };

  // Clip Drag & Trim Pointer Handlers
  const startClipInteraction = (
    e: React.PointerEvent,
    clip: TimelineClip,
    mode: 'move' | 'trim-left' | 'trim-right'
  ) => {
    e.stopPropagation();
    const track = tracks.find((t) => t.id === clip.trackId);
    if (track?.locked) return;

    onSelectClip(clip.id);
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);

    setDragState({
      clipId: clip.id,
      mode,
      startClientX: e.clientX,
      origStartTime: clip.startTime,
      origDuration: clip.duration,
      origTrimStart: clip.trimStart,
    });
  };

  const handleClipPointerMove = (e: React.PointerEvent) => {
    if (!dragState) return;
    const deltaSec = (e.clientX - dragState.startClientX) / zoomPxPerSec;

    if (dragState.mode === 'move') {
      const nextStart = snapTime(dragState.origStartTime + deltaSec, dragState.clipId);
      onUpdateClip(dragState.clipId, { startTime: nextStart }, false);
    } else if (dragState.mode === 'trim-left') {
      const maxDelta = dragState.origDuration - 0.4;
      const clampedDelta = Math.max(-dragState.origStartTime, Math.min(maxDelta, deltaSec));
      const newStart = snapTime(dragState.origStartTime + clampedDelta, dragState.clipId);
      const actualDelta = newStart - dragState.origStartTime;
      const newDuration = Math.max(0.4, Number((dragState.origDuration - actualDelta).toFixed(2)));
      const newTrimStart = Math.max(0, Number((dragState.origTrimStart + actualDelta).toFixed(2)));
      onUpdateClip(
        dragState.clipId,
        {
          startTime: newStart,
          duration: newDuration,
          trimStart: newTrimStart,
        },
        false
      );
    } else if (dragState.mode === 'trim-right') {
      const rawEnd = dragState.origStartTime + dragState.origDuration + deltaSec;
      const snappedEnd = snapTime(rawEnd, dragState.clipId);
      const newDuration = Math.max(
        0.4,
        Number((snappedEnd - dragState.origStartTime).toFixed(2))
      );
      onUpdateClip(dragState.clipId, { duration: newDuration }, false);
    }
  };

  const handleClipPointerUp = () => {
    if (dragState) {
      setDragState(null);
    }
  };

  // Track Icon helper
  const getTrackIcon = (type: TrackType) => {
    switch (type) {
      case 'video':
        return <Film className="w-3.5 h-3.5 text-[#6366F1]" />;
      case 'text':
        return <Type className="w-3.5 h-3.5 text-[#F59E0B]" />;
      case 'effect':
        return <Sparkles className="w-3.5 h-3.5 text-[#EC4899]" />;
      case 'audio':
        return <Music className="w-3.5 h-3.5 text-[#10B981]" />;
    }
  };

  // Clip styling by type
  const getClipColorClasses = (clip: TimelineClip, isSelected: boolean) => {
    const ring = isSelected
      ? 'ring-2 ring-white shadow-[0_0_16px_rgba(139,92,246,0.75)] z-20'
      : 'hover:brightness-110 z-10';
    switch (clip.type) {
      case 'video':
      case 'image':
        return `bg-gradient-to-r from-[#4338CA] to-[#4F46E5] border-[#6366F1] ${ring}`;
      case 'audio':
        return `bg-gradient-to-r from-[#065F46] to-[#047857] border-[#10B981] ${ring}`;
      case 'text':
        return `bg-gradient-to-r from-[#92400E] to-[#B45309] border-[#F59E0B] ${ring}`;
      case 'effect':
      case 'sticker':
        return `bg-gradient-to-r from-[#831843] to-[#9D174D] border-[#EC4899] ${ring}`;
    }
  };

  return (
    <section className="h-64 sm:h-72 bg-[#0D0D14] border-t border-[#262636] flex flex-col shrink-0 select-none">
      {/* Timeline Action Toolbar */}
      <div className="h-10 px-3 bg-[#14141D] border-b border-[#262636] flex items-center justify-between gap-2 shrink-0">
        {/* Left Editing Actions: Split, Merge, Duplicate, Delete, Snap, Beat Marker */}
        <div className="flex items-center gap-1 sm:gap-1.5 overflow-x-auto no-scrollbar">
          <button
            onClick={onSplitAtPlayhead}
            title="Split Clip at Playhead (S)"
            className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-[#181822] hover:bg-[#8B5CF6] text-xs font-semibold text-[#F4F4F8] hover:text-white border border-[#262636] transition-colors cursor-pointer"
          >
            <Scissors className="w-3.5 h-3.5 text-[#A855F7]" />
            <span>Split</span>
          </button>

          <button
            onClick={onMergeAdjacentClips}
            title="Merge Adjacent Clips on Track (M)"
            className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-[#181822] hover:bg-[#1F1F2E] text-xs font-semibold text-[#F4F4F8] border border-[#262636] transition-colors cursor-pointer"
          >
            <Merge className="w-3.5 h-3.5 text-[#22D3EE]" />
            <span className="hidden sm:inline">Merge</span>
          </button>

          <button
            onClick={onDuplicateSelected}
            disabled={!selectedClipId}
            title="Duplicate Selected Clip (D)"
            className="flex items-center gap-1 px-2 py-1 rounded-md bg-[#181822] hover:bg-[#1F1F2E] disabled:opacity-40 text-xs font-medium text-[#F4F4F8] border border-[#262636] transition-colors cursor-pointer"
          >
            <Copy className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Duplicate</span>
          </button>

          <button
            onClick={onDeleteSelected}
            disabled={!selectedClipId}
            title="Delete Selected Clip (Delete)"
            className="flex items-center gap-1 px-2 py-1 rounded-md bg-[#181822] hover:bg-[#EF4444]/20 disabled:opacity-40 text-xs font-medium text-[#F4F4F8] hover:text-[#EF4444] border border-[#262636] transition-colors cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>

          <div className="h-4 w-[1px] bg-[#262636] mx-1" />

          <button
            onClick={onToggleSnap}
            title="Toggle Magnetic Timeline Snapping"
            className={`flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium border transition-colors cursor-pointer ${
              snapEnabled
                ? 'bg-[#8B5CF6]/20 text-[#A855F7] border-[#8B5CF6]/50'
                : 'bg-[#181822] text-[#9494A8] border-[#262636]'
            }`}
          >
            <Magnet className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Snap</span>
          </button>

          <button
            onClick={onAddBeatMarkerAtPlayhead}
            title="Add Rhythm Beat Marker (♦) at Playhead"
            className="flex items-center gap-1 px-2 py-1 rounded-md bg-[#181822] hover:bg-[#1F1F2E] text-xs font-medium text-[#22D3EE] border border-[#262636] cursor-pointer"
          >
            <Diamond className="w-3 h-3 fill-current" />
            <span className="hidden lg:inline">+Beat Marker</span>
          </button>
        </div>

        {/* Right: Add Track + Timeline Zoom Slider */}
        <div className="flex items-center gap-2 shrink-0">
          <div className="hidden xl:flex items-center gap-1">
            <button
              onClick={() => onAddTrack('video')}
              className="px-2 py-1 rounded bg-[#181822] hover:bg-[#262636] border border-[#262636] text-[10px] font-semibold text-[#9494A8] hover:text-white flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3 h-3 text-[#6366F1]" />
              <span>Video Track</span>
            </button>
            <button
              onClick={() => onAddTrack('audio')}
              className="px-2 py-1 rounded bg-[#181822] hover:bg-[#262636] border border-[#262636] text-[10px] font-semibold text-[#9494A8] hover:text-white flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3 h-3 text-[#10B981]" />
              <span>Audio Track</span>
            </button>
          </div>

          <div className="flex items-center gap-1.5 bg-[#09090E] px-2 py-1 rounded-lg border border-[#262636]">
            <button
              onClick={() => onChangeZoom(Math.max(30, zoomPxPerSec - 15))}
              className="text-[#9494A8] hover:text-white cursor-pointer"
              title="Zoom Out Timeline"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <input
              type="range"
              min={30}
              max={160}
              value={zoomPxPerSec}
              onChange={(e) => onChangeZoom(Number(e.target.value))}
              className="w-16 sm:w-24 studio-slider"
              aria-label="Timeline Zoom"
            />
            <button
              onClick={() => onChangeZoom(Math.min(160, zoomPxPerSec + 15))}
              className="text-[#9494A8] hover:text-white cursor-pointer"
              title="Zoom In Timeline"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Timeline Body: Fixed Left Track Headers + Synchronized Scrollable Tracks Area */}
      <div className="flex-1 flex min-h-0 overflow-hidden">
        {/* Left Track Headers Column */}
        <div className="w-36 sm:w-44 bg-[#111118] border-r border-[#262636] flex flex-col shrink-0 z-20">
          {/* Ruler Corner Header */}
          <div className="h-7 px-2.5 border-b border-[#262636] bg-[#0D0D14] flex items-center justify-between text-[10px] font-mono-code text-[#5A5A70]">
            <span>TRACKS ({tracks.length})</span>
            <span>M / L / V</span>
          </div>

          {/* Track Headers List */}
          <div className="flex-1 overflow-y-hidden divide-y divide-[#262636]/70">
            {tracks.map((track) => (
              <div
                key={track.id}
                className="h-9 px-2.5 flex items-center justify-between gap-1 bg-[#111118] hover:bg-[#161620] transition-colors"
              >
                <div className="flex items-center gap-1.5 min-w-0">
                  {getTrackIcon(track.type)}
                  <span className="text-[11px] font-semibold text-[#F4F4F8] truncate">
                    {track.name}
                  </span>
                </div>

                <div className="flex items-center gap-0.5 shrink-0">
                  {/* Mute */}
                  <button
                    onClick={() => onToggleTrackMute(track.id)}
                    title={track.muted ? 'Unmute Track' : 'Mute Track'}
                    className={`p-1 rounded transition-colors cursor-pointer ${
                      track.muted
                        ? 'text-[#EF4444] bg-[#EF4444]/15'
                        : 'text-[#5A5A70] hover:text-[#F4F4F8]'
                    }`}
                  >
                    {track.muted ? (
                      <VolumeX className="w-3 h-3" />
                    ) : (
                      <Volume2 className="w-3 h-3" />
                    )}
                  </button>

                  {/* Lock */}
                  <button
                    onClick={() => onToggleTrackLock(track.id)}
                    title={track.locked ? 'Unlock Track' : 'Lock Track'}
                    className={`p-1 rounded transition-colors cursor-pointer ${
                      track.locked
                        ? 'text-[#F59E0B] bg-[#F59E0B]/15'
                        : 'text-[#5A5A70] hover:text-[#F4F4F8]'
                    }`}
                  >
                    {track.locked ? (
                      <Lock className="w-3 h-3" />
                    ) : (
                      <Unlock className="w-3 h-3" />
                    )}
                  </button>

                  {/* Hide/Show */}
                  <button
                    onClick={() => onToggleTrackHidden(track.id)}
                    title={track.hidden ? 'Show Track' : 'Hide Track'}
                    className={`p-1 rounded transition-colors cursor-pointer ${
                      track.hidden
                        ? 'text-[#9494A8] bg-[#262636]'
                        : 'text-[#5A5A70] hover:text-[#F4F4F8]'
                    }`}
                  >
                    {track.hidden ? (
                      <EyeOff className="w-3 h-3" />
                    ) : (
                      <Eye className="w-3 h-3" />
                    )}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Scrollable Multi-Track Canvas & Ruler */}
        <div
          ref={scrollContainerRef}
          onPointerMove={handleClipPointerMove}
          onPointerUp={handleClipPointerUp}
          className="flex-1 overflow-x-auto overflow-y-auto relative bg-[#09090E]"
        >
          <div
            style={{ width: `${totalWidthPx}px` }}
            className="relative min-h-full flex flex-col"
          >
            {/* Timecode Ruler with Beat Markers */}
            <div
              onPointerDown={handleRulerPointerDown}
              onPointerMove={handleRulerPointerMove}
              onPointerUp={handleRulerPointerUp}
              className="h-7 bg-[#0D0D14] border-b border-[#262636] relative cursor-ew-resize sticky top-0 z-20"
            >
              {Array.from({ length: timelineSecondsSpan + 1 }).map((_, sec) => {
                const leftPx = sec * zoomPxPerSec;
                return (
                  <div
                    key={sec}
                    style={{ left: `${leftPx}px` }}
                    className="absolute top-0 bottom-0 flex flex-col justify-end pointer-events-none"
                  >
                    <div className="h-2.5 w-[1px] bg-[#383850]" />
                    <span className="text-[9px] font-mono-code text-[#9494A8] pl-1 -mt-3">
                      {sec}s
                    </span>
                    {/* Half-second sub-tick */}
                    <div
                      style={{ left: `${zoomPxPerSec * 0.5}px` }}
                      className="absolute bottom-0 h-1.5 w-[1px] bg-[#262636]"
                    />
                  </div>
                );
              })}

              {/* Beat Markers (♦) */}
              {beatMarkers.map((bm, idx) => (
                <button
                  key={`${bm}-${idx}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    onSeek(bm);
                  }}
                  style={{ left: `${bm * zoomPxPerSec}px` }}
                  title={`Beat Marker @ ${bm}s (Click to snap playhead)`}
                  className="absolute bottom-0.5 -translate-x-1/2 text-[#22D3EE] hover:scale-125 transition-transform cursor-pointer z-10"
                >
                  <Diamond className="w-2.5 h-2.5 fill-current" />
                </button>
              ))}
            </div>

            {/* Track Lanes */}
            <div className="divide-y divide-[#1D1D2B] relative flex-1">
              {tracks.map((track) => {
                const trackClips = clips.filter((c) => c.trackId === track.id);
                return (
                  <div
                    key={track.id}
                    onClick={() => onSelectClip(null)}
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={(e) => {
                      e.preventDefault();
                      const mediaId = e.dataTransfer.getData('application/kinetix-media-id');
                      if (mediaId) {
                        const dropTime = snapTime(clientXToTime(e.clientX));
                        onDropMediaOnTrack(mediaId, track.id, dropTime);
                      }
                    }}
                    className={`h-9 relative transition-colors ${
                      track.locked || track.hidden
                        ? 'bg-[#09090E]/60 opacity-50'
                        : 'bg-[#0E0E17] hover:bg-[#12121D]'
                    }`}
                  >
                    {/* Subtle vertical second gridlines */}
                    {Array.from({ length: timelineSecondsSpan }).map((_, s) => (
                      <div
                        key={s}
                        style={{ left: `${s * zoomPxPerSec}px` }}
                        className="absolute top-0 bottom-0 w-[1px] bg-[#161622] pointer-events-none"
                      />
                    ))}

                    {/* Clips on this Track */}
                    {trackClips.map((clip) => {
                      const isSelected = clip.id === selectedClipId;
                      const leftPx = clip.startTime * zoomPxPerSec;
                      const widthPx = Math.max(22, clip.duration * zoomPxPerSec);

                      return (
                        <div
                          key={clip.id}
                          style={{
                            left: `${leftPx}px`,
                            width: `${widthPx}px`,
                          }}
                          onPointerDown={(e) => startClipInteraction(e, clip, 'move')}
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectClip(clip.id);
                          }}
                          className={`group absolute top-1 bottom-1 rounded-md border overflow-hidden cursor-grab active:cursor-grabbing flex items-center select-none transition-shadow ${getClipColorClasses(
                            clip,
                            isSelected
                          )}`}
                        >
                          {/* Video Filmstrip Background Repeat */}
                          {(clip.type === 'video' || clip.type === 'image') &&
                            clip.thumbnail && (
                              <div
                                className="absolute inset-0 opacity-30 pointer-events-none"
                                style={{
                                  backgroundImage: `url(${clip.thumbnail})`,
                                  backgroundSize: 'auto 100%',
                                  backgroundRepeat: 'repeat-x',
                                }}
                              />
                            )}

                          {/* Audio Waveform Bars */}
                          {clip.type === 'audio' && clip.waveform && (
                            <div className="absolute inset-0 flex items-end justify-between px-1 py-1 gap-[1px] opacity-55 pointer-events-none">
                              {clip.waveform.slice(0, 48).map((peak, i) => (
                                <div
                                  key={i}
                                  style={{ height: `${Math.round(peak * 100)}%` }}
                                  className="flex-1 bg-[#34D399] rounded-t-xs"
                                />
                              ))}
                            </div>
                          )}

                          {/* Left Trim Handle */}
                          <div
                            onPointerDown={(e) => startClipInteraction(e, clip, 'trim-left')}
                            title="Drag to Trim In-Point"
                            className="w-2.5 h-full bg-black/40 hover:bg-white/80 cursor-ew-resize flex items-center justify-center z-20 shrink-0 transition-colors"
                          >
                            <div className="w-[2px] h-3.5 bg-white/70 rounded-full" />
                          </div>

                          {/* Clip Label & Metadata Badges */}
                          <div className="flex-1 min-w-0 px-1.5 flex items-center justify-between gap-1 relative z-10 pointer-events-none">
                            <span className="text-[10px] font-semibold text-white truncate drop-shadow">
                              {clip.type === 'sticker'
                                ? `${clip.stickerEmoji} ${clip.name}`
                                : clip.type === 'text'
                                ? clip.textStyle?.text || clip.name
                                : clip.name}
                            </span>

                            <div className="flex items-center gap-1 shrink-0">
                              {clip.chromaKey.enabled && (
                                <span className="px-1 rounded text-[8px] font-mono-code font-bold bg-[#10B981] text-black">
                                  KEY
                                </span>
                              )}
                              {clip.speed !== 1 && (
                                <span className="px-1 rounded text-[8px] font-mono-code bg-black/60 text-[#A855F7]">
                                  {clip.speed}x
                                </span>
                              )}
                              {clip.transitionIn.type !== 'none' && (
                                <span className="px-1 rounded text-[8px] font-mono-code bg-white/20 text-white uppercase">
                                  {clip.transitionIn.type}
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Keyframe Diamonds (◆) Indicator */}
                          {clip.keyframes.map((kf) => (
                            <div
                              key={kf.id}
                              style={{
                                left: `${Math.min(
                                  widthPx - 10,
                                  Math.max(6, kf.timeOffset * zoomPxPerSec)
                                )}px`,
                              }}
                              className="absolute bottom-0.5 text-[#FACC15] pointer-events-none z-20"
                            >
                              <Diamond className="w-2.5 h-2.5 fill-current" />
                            </div>
                          ))}

                          {/* Right Trim Handle */}
                          <div
                            onPointerDown={(e) =>
                              startClipInteraction(e, clip, 'trim-right')
                            }
                            title="Drag to Trim Out-Point"
                            className="w-2.5 h-full bg-black/40 hover:bg-white/80 cursor-ew-resize flex items-center justify-center z-20 shrink-0 transition-colors"
                          >
                            <div className="w-[2px] h-3.5 bg-white/70 rounded-full" />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                );
              })}
            </div>

            {/* Vertical Playhead Scrubber Line */}
            <div
              style={{ left: `${currentTime * zoomPxPerSec}px` }}
              className="absolute top-0 bottom-0 w-[2px] bg-[#A855F7] shadow-[0_0_10px_#A855F7] pointer-events-none z-30"
            >
              {/* Playhead Cap */}
              <div className="w-3.5 h-3.5 -ml-[6px] bg-[#A855F7] rotate-45 rounded-xs shadow" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
