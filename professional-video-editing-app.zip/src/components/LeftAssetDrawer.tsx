import React, { useState, useRef } from 'react';
import {
  Film,
  Type,
  Music,
  Sparkles,
  Wand2,
  Smile,
  Bot,
  Upload,
  Plus,
  Mic,
  Square,
  Volume2,
  Check,
  X,
  Subtitles,
  Zap,
  Scissors,
  Smartphone,
  Monitor,
  Layers,
  Sliders,
} from 'lucide-react';
import {
  AIProposal,
  AspectRatioOption,
  EffectOverlayType,
  FilterPreset,
  LeftRailTab,
  MediaItem,
  TextStyleSettings,
  TimelineClip,
  TransitionType,
} from '../types/editor';
import {
  EFFECT_OVERLAY_PRESETS,
  FILTER_PRESETS_INFO,
  STICKER_PRESETS,
  TEXT_TEMPLATES,
  TRANSITION_PRESETS,
} from '../data/presets';
import { formatTimecode } from '../engine/canvasCompositor';

interface LeftAssetDrawerProps {
  activeTab: LeftRailTab;
  onSelectTab: (tab: LeftRailTab) => void;
  mediaLibrary: MediaItem[];
  onImportFiles: (files: FileList) => void;
  onAddMediaToTimeline: (media: MediaItem, targetTrackId?: string) => void;
  onAddTextClip: (style: TextStyleSettings, label: string) => void;
  onAddEffectOverlay: (overlayType: EffectOverlayType, name: string) => void;
  onAddStickerClip: (emoji: string, label: string) => void;
  onApplyFilterToSelectedOrAll: (preset: FilterPreset, applyAll: boolean) => void;
  onApplyTransitionToSelectedOrAll: (
    type: TransitionType,
    duration: number,
    applyAll: boolean
  ) => void;
  onGenerateAutoCaptions: () => void;
  onAddVoiceoverClip: (url: string, duration: number, label: string, ttsText?: string) => void;
  onSyncBeatMarkers: (bpm: number) => void;
  onSnapClipsToBeats: () => void;
  clips: TimelineClip[];
  selectedClipId: string | null;
  onSelectClip: (id: string) => void;
  onUpdateClip: (id: string, patch: Partial<TimelineClip>) => void;
  onSeek: (time: number) => void;
  activeAIProposal: AIProposal | null;
  onProposeAIEdit: (proposal: AIProposal) => void;
  onApproveAIProposal: (proposal: AIProposal) => void;
  onDismissAIProposal: () => void;
}

export const LeftAssetDrawer: React.FC<LeftAssetDrawerProps> = ({
  activeTab,
  onSelectTab,
  mediaLibrary,
  onImportFiles,
  onAddMediaToTimeline,
  onAddTextClip,
  onAddEffectOverlay,
  onAddStickerClip,
  onApplyFilterToSelectedOrAll,
  onApplyTransitionToSelectedOrAll,
  onGenerateAutoCaptions,
  onAddVoiceoverClip,
  onSyncBeatMarkers,
  onSnapClipsToBeats,
  clips,
  selectedClipId,
  onSelectClip,
  onUpdateClip,
  onSeek,
  activeAIProposal,
  onProposeAIEdit,
  onApproveAIProposal,
  onDismissAIProposal,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [mediaFilter, setMediaFilter] = useState<'all' | 'video' | 'image' | 'chroma'>('all');
  const [isDraggingOver, setIsDraggingOver] = useState(false);

  // Transition duration state
  const [transitionDur, setTransitionDur] = useState(0.6);

  // Voiceover Recording State
  const [isRecordingMic, setIsRecordingMic] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordTimerRef = useRef<number | null>(null);

  // Text-to-Speech (TTS) State
  const [ttsScript, setTtsScript] = useState(
    'Welcome to Kinetix Studio. Edit faster with real-time AI and multi-track precision.'
  );
  const [ttsPersona, setTtsPersona] = useState<'Nova (Energetic)' | 'Atlas (Cinematic)' | 'Echo (Tech)'>('Nova (Energetic)');

  // Live Speech Recognition Captioning
  const [isListeningSpeech, setIsListeningSpeech] = useState(false);

  const navItems: { id: LeftRailTab; label: string; icon: React.ReactNode }[] = [
    { id: 'media', label: 'Media', icon: <Film className="w-4 h-4" /> },
    { id: 'text', label: 'Text', icon: <Type className="w-4 h-4" /> },
    { id: 'audio', label: 'Audio', icon: <Music className="w-4 h-4" /> },
    { id: 'effects', label: 'Effects', icon: <Sparkles className="w-4 h-4" /> },
    { id: 'transitions', label: 'Transitions', icon: <Wand2 className="w-4 h-4" /> },
    { id: 'stickers', label: 'Stickers', icon: <Smile className="w-4 h-4" /> },
    { id: 'ai', label: 'AI Studio', icon: <Bot className="w-4 h-4" /> },
  ];

  const handleDropFiles = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onImportFiles(e.dataTransfer.files);
    }
  };

  // Start / Stop Live Microphone Voiceover Recording
  const toggleMicRecording = async () => {
    if (isRecordingMic) {
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
      if (recordTimerRef.current) window.clearInterval(recordTimerRef.current);
      setIsRecordingMic(false);
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const chunks: BlobPart[] = [];
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      const startTs = Date.now();
      setRecordingSeconds(0);
      setIsRecordingMic(true);

      recordTimerRef.current = window.setInterval(() => {
        setRecordingSeconds(Number(((Date.now() - startTs) / 1000).toFixed(1)));
      }, 200);

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunks.push(e.data);
      };
      recorder.onstop = () => {
        stream.getTracks().forEach((t) => t.stop());
        const dur = Math.max(1.5, Number(((Date.now() - startTs) / 1000).toFixed(1)));
        const blob = new Blob(chunks, { type: 'audio/webm' });
        const url = URL.createObjectURL(blob);
        onAddVoiceoverClip(url, dur, `Mic Voiceover (${dur}s)`);
      };
      recorder.start();
    } catch {
      // Fallback simulated voiceover clip if microphone permission is denied in sandbox
      onAddVoiceoverClip(
        'synth://sfx-whoosh',
        3.5,
        'Studio Mic Voiceover (Simulated)',
        'Recorded studio voiceover track'
      );
    }
  };

  // Trigger Text-to-Speech (TTS) Voiceover
  const handleCreateTTSVoiceover = () => {
    if (!ttsScript.trim()) return;
    const words = ttsScript.trim().split(/\s+/).length;
    const estDuration = Math.max(2.2, Number((words * 0.38).toFixed(1)));

    if ('speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
        const utter = new SpeechSynthesisUtterance(ttsScript);
        utter.rate = ttsPersona.includes('Energetic') ? 1.08 : ttsPersona.includes('Cinematic') ? 0.92 : 1.0;
        utter.pitch = ttsPersona.includes('Cinematic') ? 0.85 : 1.05;
        window.speechSynthesis.speak(utter);
      } catch {
        // Ignore speech synthesis errors
      }
    }

    onAddVoiceoverClip(
      'synth://lofi-92',
      estDuration,
      `AI TTS: "${ttsScript.slice(0, 18)}..."`,
      ttsScript
    );
  };

  // Speech Recognition Live Dictation to Subtitle
  const handleLiveSpeechCaption = () => {
    const SpeechRec =
      (window as unknown as { SpeechRecognition?: unknown; webkitSpeechRecognition?: unknown })
        .SpeechRecognition ||
      (window as unknown as { webkitSpeechRecognition?: unknown }).webkitSpeechRecognition;

    if (!SpeechRec) {
      onGenerateAutoCaptions();
      return;
    }

    try {
      setIsListeningSpeech(true);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const recognition = new (SpeechRec as any)();
      recognition.lang = 'en-US';
      recognition.interimResults = false;
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      recognition.onresult = (event: any) => {
        const transcript = event.results?.[0]?.[0]?.transcript;
        if (transcript) {
          onAddTextClip(
            {
              ...TEXT_TEMPLATES[1].style,
              text: transcript,
            },
            `Voice Caption: ${transcript.slice(0, 16)}`
          );
        }
        setIsListeningSpeech(false);
      };
      recognition.onerror = () => {
        setIsListeningSpeech(false);
        onGenerateAutoCaptions();
      };
      recognition.onend = () => setIsListeningSpeech(false);
      recognition.start();
    } catch {
      setIsListeningSpeech(false);
      onGenerateAutoCaptions();
    }
  };

  const visualMedia = mediaLibrary.filter((m) => {
    if (m.type === 'audio') return false;
    if (mediaFilter === 'video') return m.type === 'video';
    if (mediaFilter === 'image') return m.type === 'image';
    if (mediaFilter === 'chroma') return Boolean(m.isGreenScreen);
    return true;
  });

  const audioMedia = mediaLibrary.filter((m) => m.type === 'audio');
  const textClips = clips
    .filter((c) => c.type === 'text')
    .sort((a, b) => a.startTime - b.startTime);

  return (
    <div className="flex h-full bg-[#111118] border-r border-[#262636] shrink-0 select-none">
      {/* Left 56px Tool Icon Rail */}
      <nav className="w-14 bg-[#0D0D14] border-r border-[#262636] flex flex-col items-center py-2 gap-1 shrink-0">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`w-11 py-2 rounded-xl flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                isActive
                  ? 'bg-[#8B5CF6]/20 text-[#A855F7] border border-[#8B5CF6]/50 shadow-[0_0_12px_rgba(139,92,246,0.25)]'
                  : 'text-[#9494A8] hover:text-[#F4F4F8] hover:bg-[#181822]'
              }`}
            >
              {item.icon}
              <span className="text-[9px] font-medium tracking-tight">{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Contextual Asset Drawer (280px on desktop) */}
      <div className="w-68 sm:w-76 flex flex-col h-full overflow-hidden">
        {/* Drawer Header */}
        <div className="px-3.5 py-2.5 border-b border-[#262636] bg-[#14141D] flex items-center justify-between">
          <h2 className="font-display font-bold text-xs uppercase tracking-wider text-[#F4F4F8]">
            {activeTab === 'media' && 'Project Media Bin'}
            {activeTab === 'text' && 'Text & Auto Captions'}
            {activeTab === 'audio' && 'Audio, Voiceover & SFX'}
            {activeTab === 'effects' && 'Color LUTs & VFX Overlays'}
            {activeTab === 'transitions' && 'Motion Transitions'}
            {activeTab === 'stickers' && 'Stickers & Emojis'}
            {activeTab === 'ai' && 'AI Studio Co-Pilot'}
          </h2>
          <span className="text-[10px] font-mono-code text-[#9494A8]">
            {activeTab === 'media' && `${visualMedia.length} assets`}
            {activeTab === 'text' && `${textClips.length} active`}
            {activeTab === 'audio' && `${audioMedia.length} stems`}
          </span>
        </div>

        {/* Scrollable Drawer Body */}
        <div className="flex-1 overflow-y-auto p-3 space-y-4">
          {/* TAB 1: MEDIA BIN */}
          {activeTab === 'media' && (
            <>
              {/* Drag & Drop Import Zone */}
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setIsDraggingOver(true);
                }}
                onDragLeave={() => setIsDraggingOver(false)}
                onDrop={handleDropFiles}
                onClick={() => fileInputRef.current?.click()}
                className={`p-3.5 rounded-xl border border-dashed transition-all cursor-pointer flex flex-col items-center justify-center text-center gap-1.5 ${
                  isDraggingOver
                    ? 'border-[#8B5CF6] bg-[#8B5CF6]/15'
                    : 'border-[#262636] hover:border-[#8B5CF6]/60 bg-[#181822]/70 hover:bg-[#181822]'
                }`}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  accept="video/*,image/*,audio/*"
                  onChange={(e) => e.target.files && onImportFiles(e.target.files)}
                  className="hidden"
                />
                <div className="w-8 h-8 rounded-full bg-[#8B5CF6]/20 text-[#A855F7] flex items-center justify-center">
                  <Upload className="w-4 h-4" />
                </div>
                <p className="text-xs font-semibold text-[#F4F4F8]">
                  Import Media or Drag & Drop
                </p>
                <p className="text-[10px] text-[#9494A8]">
                  MP4, MOV, WebM, PNG, JPG, MP3, WAV
                </p>
              </div>

              {/* Filter Pills */}
              <div className="flex items-center gap-1 bg-[#09090E] p-1 rounded-lg border border-[#262636]">
                {(
                  [
                    { id: 'all', label: 'All' },
                    { id: 'video', label: 'Videos' },
                    { id: 'image', label: 'Photos' },
                    { id: 'chroma', label: 'Green Screen' },
                  ] as const
                ).map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setMediaFilter(f.id)}
                    className={`flex-1 py-1 rounded text-[10px] font-semibold transition-colors cursor-pointer ${
                      mediaFilter === f.id
                        ? 'bg-[#8B5CF6] text-white'
                        : 'text-[#9494A8] hover:text-white'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>

              {/* 2-Column Media Grid */}
              <div className="grid grid-cols-2 gap-2.5">
                {visualMedia.map((item) => (
                  <div
                    key={item.id}
                    draggable
                    onDragStart={(e) => {
                      e.dataTransfer.setData('application/kinetix-media-id', item.id);
                    }}
                    className="group relative rounded-lg bg-[#181822] border border-[#262636] hover:border-[#8B5CF6] overflow-hidden transition-all flex flex-col"
                  >
                    <div className="relative h-20 bg-[#09090E] overflow-hidden">
                      <img
                        src={item.thumbnail}
                        alt={item.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                      {item.isGreenScreen && (
                        <span className="absolute top-1.5 left-1.5 px-1.5 py-0.5 rounded text-[8px] font-mono-code font-bold bg-[#10B981] text-black">
                          CHROMA
                        </span>
                      )}
                      <span className="absolute bottom-1 right-1.5 text-[9px] font-mono-code text-white bg-black/70 px-1 rounded">
                        {item.duration.toFixed(1)}s
                      </span>
                      <button
                        onClick={() =>
                          onAddMediaToTimeline(
                            item,
                            item.isGreenScreen ? 'track-v2' : 'track-v1'
                          )
                        }
                        title={
                          item.isGreenScreen
                            ? 'Add Green Screen Clip to Overlay Track V2'
                            : 'Add to Timeline Track V1'
                        }
                        className="absolute bottom-1 left-1.5 w-6 h-6 rounded-md bg-[#8B5CF6] hover:bg-[#A855F7] text-white flex items-center justify-center shadow-lg cursor-pointer transition-transform active:scale-90"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <div className="p-1.5">
                      <p className="text-[11px] font-medium text-[#F4F4F8] truncate">
                        {item.name}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}

          {/* TAB 2: TEXT & CAPTIONS */}
          {activeTab === 'text' && (
            <>
              {/* Auto-Subtitles & Speech Recognition Card */}
              <div className="p-3 rounded-xl bg-gradient-to-br from-[#1E1438] to-[#181822] border border-[#8B5CF6]/40 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Subtitles className="w-4 h-4 text-[#A855F7]" />
                    AI Auto-Subtitles
                  </span>
                  <span className="text-[9px] font-mono-code px-1.5 py-0.5 rounded bg-[#8B5CF6]/30 text-[#A855F7]">
                    SPEECH SYNC
                  </span>
                </div>
                <p className="text-[11px] text-[#9494A8]">
                  Automatically transcribe timeline dialogue or dictate live from your microphone onto Track T1.
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={onGenerateAutoCaptions}
                    className="py-1.5 px-2.5 rounded-lg bg-[#8B5CF6] hover:bg-[#A855F7] text-white text-[11px] font-semibold flex items-center justify-center gap-1 shadow cursor-pointer"
                  >
                    <Sparkles className="w-3 h-3" />
                    <span>Auto-Caption</span>
                  </button>
                  <button
                    onClick={handleLiveSpeechCaption}
                    className={`py-1.5 px-2.5 rounded-lg text-[11px] font-semibold flex items-center justify-center gap-1 border cursor-pointer ${
                      isListeningSpeech
                        ? 'bg-[#EF4444] text-white border-[#EF4444] animate-pulse'
                        : 'bg-[#111118] hover:bg-[#1F1F2E] text-[#F4F4F8] border-[#262636]'
                    }`}
                  >
                    <Mic className="w-3 h-3 text-[#EC4899]" />
                    <span>{isListeningSpeech ? 'Listening...' : 'Voice Dictate'}</span>
                  </button>
                </div>
              </div>

              {/* Animated Text Templates */}
              <div className="space-y-2">
                <h3 className="text-[11px] font-semibold uppercase tracking-wider text-[#9494A8]">
                  Animated Title Templates
                </h3>
                <div className="space-y-2">
                  {TEXT_TEMPLATES.map((tpl) => (
                    <div
                      key={tpl.id}
                      onClick={() => onAddTextClip({ ...tpl.style }, tpl.label)}
                      className="p-2.5 rounded-xl bg-[#181822] hover:bg-[#1F1F2E] border border-[#262636] hover:border-[#8B5CF6] flex items-center justify-between gap-2 transition-all cursor-pointer group"
                    >
                      <div className="min-w-0">
                        <span className="inline-block text-[9px] font-mono-code font-bold px-1.5 py-0.5 rounded bg-[#F59E0B]/20 text-[#F59E0B] mb-1">
                          {tpl.previewBadge}
                        </span>
                        <p
                          className="text-xs font-bold truncate"
                          style={{ color: tpl.style.color }}
                        >
                          {tpl.style.text}
                        </p>
                        <p className="text-[10px] text-[#9494A8]">{tpl.label}</p>
                      </div>
                      <div className="w-7 h-7 rounded-lg bg-[#8B5CF6]/20 group-hover:bg-[#8B5CF6] text-[#A855F7] group-hover:text-white flex items-center justify-center shrink-0 transition-colors">
                        <Plus className="w-4 h-4" />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Active Subtitle & Caption List Editor */}
              <div className="space-y-2 pt-2 border-t border-[#262636]">
                <h3 className="text-[11px] font-semibold uppercase tracking-wider text-[#9494A8]">
                  Timeline Captions ({textClips.length})
                </h3>
                {textClips.length === 0 ? (
                  <p className="text-xs text-[#5A5A70] italic">
                    No captions on Track T1 yet.
                  </p>
                ) : (
                  <div className="space-y-1.5">
                    {textClips.map((tc) => (
                      <div
                        key={tc.id}
                        onClick={() => {
                          onSelectClip(tc.id);
                          onSeek(tc.startTime + 0.1);
                        }}
                        className={`p-2 rounded-lg border text-xs transition-all cursor-pointer ${
                          selectedClipId === tc.id
                            ? 'bg-[#8B5CF6]/15 border-[#8B5CF6]'
                            : 'bg-[#181822] border-[#262636] hover:border-[#5A5A70]'
                        }`}
                      >
                        <div className="flex items-center justify-between text-[10px] font-mono-code text-[#9494A8] mb-1">
                          <span>{formatTimecode(tc.startTime, 30)}</span>
                          <span>{tc.duration.toFixed(1)}s</span>
                        </div>
                        <input
                          type="text"
                          value={tc.textStyle?.text || tc.name}
                          onChange={(e) => {
                            if (!tc.textStyle) return;
                            onUpdateClip(tc.id, {
                              name: e.target.value,
                              textStyle: { ...tc.textStyle, text: e.target.value },
                            });
                          }}
                          className="w-full bg-[#09090E] px-2 py-1 rounded border border-[#262636] focus:border-[#8B5CF6] text-xs text-white outline-none"
                        />
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </>
          )}

          {/* TAB 3: AUDIO, VOICEOVER & TTS */}
          {activeTab === 'audio' && (
            <>
              {/* Live Microphone Voiceover Recorder */}
              <div className="p-3 rounded-xl bg-[#181822] border border-[#262636] space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#F4F4F8] flex items-center gap-1.5">
                    <Mic className="w-3.5 h-3.5 text-[#EF4444]" />
                    Voiceover Recorder
                  </span>
                  {isRecordingMic && (
                    <span className="text-[10px] font-mono-code text-[#EF4444] animate-pulse">
                      ● REC {recordingSeconds}s
                    </span>
                  )}
                </div>
                <button
                  onClick={toggleMicRecording}
                  className={`w-full py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    isRecordingMic
                      ? 'bg-[#EF4444] text-white shadow-[0_0_15px_rgba(239,68,68,0.5)]'
                      : 'bg-[#111118] hover:bg-[#1F1F2E] text-[#F4F4F8] border border-[#262636]'
                  }`}
                >
                  {isRecordingMic ? (
                    <>
                      <Square className="w-3.5 h-3.5 fill-current" />
                      <span>Stop & Drop to Track A2</span>
                    </>
                  ) : (
                    <>
                      <Mic className="w-3.5 h-3.5 text-[#EF4444]" />
                      <span>Record Mic Voiceover</span>
                    </>
                  )}
                </button>
              </div>

              {/* AI Text-to-Speech (TTS) Generator */}
              <div className="p-3 rounded-xl bg-[#181822] border border-[#262636] space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[#F4F4F8] flex items-center gap-1.5">
                    <Volume2 className="w-3.5 h-3.5 text-[#10B981]" />
                    AI Text-to-Speech (TTS)
                  </span>
                </div>
                <textarea
                  rows={2}
                  value={ttsScript}
                  onChange={(e) => setTtsScript(e.target.value)}
                  placeholder="Type script for AI narrator..."
                  className="w-full p-2 rounded-lg bg-[#09090E] border border-[#262636] focus:border-[#8B5CF6] text-xs text-white outline-none resize-none"
                />
                <div className="flex items-center gap-1.5">
                  <select
                    value={ttsPersona}
                    onChange={(e) => setTtsPersona(e.target.value as typeof ttsPersona)}
                    className="flex-1 bg-[#09090E] border border-[#262636] rounded-lg px-2 py-1.5 text-[11px] text-[#F4F4F8] outline-none"
                  >
                    <option value="Nova (Energetic)">Nova (Energetic)</option>
                    <option value="Atlas (Cinematic)">Atlas (Cinematic)</option>
                    <option value="Echo (Tech)">Echo (Tech)</option>
                  </select>
                  <button
                    onClick={handleCreateTTSVoiceover}
                    className="px-3 py-1.5 rounded-lg bg-[#10B981] hover:bg-[#059669] text-black font-bold text-[11px] cursor-pointer"
                  >
                    Speak + Add
                  </button>
                </div>
              </div>

              {/* Beat Synchronization Helper */}
              <div className="p-3 rounded-xl bg-gradient-to-r from-[#10B981]/15 to-[#8B5CF6]/15 border border-[#10B981]/40 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5 text-[#10B981]" />
                    Beat Sync & Rhythm Markers
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    onClick={() => onSyncBeatMarkers(128)}
                    className="py-1.5 px-2 rounded-lg bg-[#111118] hover:bg-[#181822] border border-[#262636] text-[11px] font-semibold text-[#10B981] cursor-pointer"
                  >
                    Generate ♦ Beats
                  </button>
                  <button
                    onClick={onSnapClipsToBeats}
                    className="py-1.5 px-2 rounded-lg bg-[#10B981] hover:bg-[#059669] text-[11px] font-bold text-black cursor-pointer"
                  >
                    Snap Cuts to Beats
                  </button>
                </div>
              </div>

              {/* Studio Music & SFX Stems */}
              <div className="space-y-2">
                <h3 className="text-[11px] font-semibold uppercase tracking-wider text-[#9494A8]">
                  Royalty-Free Music & SFX
                </h3>
                <div className="space-y-2">
                  {audioMedia.map((aud) => (
                    <div
                      key={aud.id}
                      className="p-2.5 rounded-xl bg-[#181822] hover:bg-[#1F1F2E] border border-[#262636] flex items-center justify-between gap-2 transition-all"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`px-1.5 py-0.5 rounded text-[9px] font-mono-code font-bold uppercase ${
                              aud.audioCategory === 'sfx'
                                ? 'bg-[#EC4899]/20 text-[#EC4899]'
                                : 'bg-[#10B981]/20 text-[#10B981]'
                            }`}
                          >
                            {aud.audioCategory}
                          </span>
                          {aud.bpm && (
                            <span className="text-[10px] font-mono-code text-[#9494A8]">
                              {aud.bpm} BPM
                            </span>
                          )}
                        </div>
                        <p className="text-xs font-semibold text-[#F4F4F8] truncate mt-1">
                          {aud.name}
                        </p>
                      </div>
                      <button
                        onClick={() =>
                          onAddMediaToTimeline(
                            aud,
                            aud.audioCategory === 'sfx' ? 'track-a2' : 'track-a1'
                          )
                        }
                        className="w-7 h-7 rounded-lg bg-[#10B981]/20 hover:bg-[#10B981] text-[#10B981] hover:text-black flex items-center justify-center transition-colors cursor-pointer"
                        title="Add Audio to Timeline"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {/* TAB 4: EFFECTS, LUTS & OVERLAYS */}
          {activeTab === 'effects' && (
            <>
              {/* Cinematic Overlays (Track FX1) */}
              <div className="space-y-2">
                <h3 className="text-[11px] font-semibold uppercase tracking-wider text-[#9494A8]">
                  Cinematic Overlays (Track FX1)
                </h3>
                <div className="grid grid-cols-1 gap-2">
                  {EFFECT_OVERLAY_PRESETS.map((fx) => (
                    <div
                      key={fx.id}
                      onClick={() => onAddEffectOverlay(fx.id, fx.name)}
                      className="p-2.5 rounded-xl bg-[#181822] hover:bg-[#1F1F2E] border border-[#262636] hover:border-[#EC4899] flex items-center justify-between gap-2 cursor-pointer transition-all group"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div
                          className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                          style={{ backgroundColor: `${fx.color}25`, color: fx.color }}
                        >
                          <Sparkles className="w-4 h-4" />
                        </div>
                        <div className="min-w-0">
                          <p className="text-xs font-bold text-[#F4F4F8] truncate">
                            {fx.name}
                          </p>
                          <p className="text-[10px] text-[#9494A8] truncate">{fx.desc}</p>
                        </div>
                      </div>
                      <Plus className="w-4 h-4 text-[#9494A8] group-hover:text-[#EC4899] shrink-0" />
                    </div>
                  ))}
                </div>
              </div>

              {/* Color Grading LUT Presets */}
              <div className="space-y-2 pt-2 border-t border-[#262636]">
                <h3 className="text-[11px] font-semibold uppercase tracking-wider text-[#9494A8]">
                  Color Grading LUT Presets
                </h3>
                <div className="grid grid-cols-2 gap-2">
                  {FILTER_PRESETS_INFO.map((lut) => (
                    <button
                      key={lut.id}
                      onClick={() => onApplyFilterToSelectedOrAll(lut.id, false)}
                      className="p-2 rounded-xl bg-[#181822] hover:bg-[#1F1F2E] border border-[#262636] hover:border-[#8B5CF6] text-left transition-all cursor-pointer group"
                    >
                      <div
                        className={`h-10 rounded-lg bg-gradient-to-r ${lut.previewGradient} mb-1.5 border border-white/10`}
                      />
                      <p className="text-[11px] font-bold text-[#F4F4F8] truncate">
                        {lut.name}
                      </p>
                      <p className="text-[9px] text-[#9494A8] truncate">{lut.desc}</p>
                    </button>
                  ))}
                </div>
              </div>
            </>
          )}

          {/* TAB 5: TRANSITIONS */}
          {activeTab === 'transitions' && (
            <>
              <div className="p-3 rounded-xl bg-[#181822] border border-[#262636] space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-[#9494A8]">Transition Duration</span>
                  <span className="font-mono-code font-bold text-[#A855F7]">
                    {transitionDur.toFixed(1)}s
                  </span>
                </div>
                <input
                  type="range"
                  min={0.2}
                  max={2.0}
                  step={0.1}
                  value={transitionDur}
                  onChange={(e) => setTransitionDur(Number(e.target.value))}
                  className="w-full studio-slider"
                />
              </div>

              <div className="space-y-2">
                {TRANSITION_PRESETS.map((tr) => (
                  <div
                    key={tr.id}
                    className="p-2.5 rounded-xl bg-[#181822] border border-[#262636] hover:border-[#8B5CF6] space-y-2 transition-all"
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-[9px] font-mono-code font-bold px-1.5 py-0.5 rounded bg-[#8B5CF6]/20 text-[#A855F7]">
                          {tr.badge}
                        </span>
                        <h4 className="text-xs font-bold text-[#F4F4F8] mt-1">{tr.name}</h4>
                        <p className="text-[10px] text-[#9494A8]">{tr.desc}</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-1.5">
                      <button
                        onClick={() =>
                          onApplyTransitionToSelectedOrAll(tr.id, transitionDur, false)
                        }
                        className="py-1 px-2 rounded bg-[#111118] hover:bg-[#8B5CF6] text-[10px] font-semibold text-[#F4F4F8] hover:text-white border border-[#262636] transition-colors cursor-pointer"
                      >
                        Apply Selected
                      </button>
                      <button
                        onClick={() =>
                          onApplyTransitionToSelectedOrAll(tr.id, transitionDur, true)
                        }
                        className="py-1 px-2 rounded bg-[#8B5CF6]/20 hover:bg-[#8B5CF6] text-[10px] font-semibold text-[#A855F7] hover:text-white border border-[#8B5CF6]/40 transition-colors cursor-pointer"
                      >
                        Apply All Cuts
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}

          {/* TAB 6: STICKERS & EMOJIS */}
          {activeTab === 'stickers' && (
            <div className="space-y-3">
              <p className="text-xs text-[#9494A8]">
                Click any animated sticker to drop it onto Track FX1 at the playhead. Drag directly on the canvas to position or scale.
              </p>
              <div className="grid grid-cols-3 gap-2.5">
                {STICKER_PRESETS.map((stk) => (
                  <button
                    key={stk.id}
                    onClick={() => onAddStickerClip(stk.emoji, stk.label)}
                    className="p-3 rounded-xl bg-[#181822] hover:bg-[#1F1F2E] border border-[#262636] hover:border-[#8B5CF6] flex flex-col items-center justify-center gap-1 transition-all cursor-pointer group"
                  >
                    <span className="text-2xl group-hover:scale-125 transition-transform">
                      {stk.emoji}
                    </span>
                    <span className="text-[10px] font-medium text-[#9494A8] truncate max-w-full">
                      {stk.label}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* TAB 7: AI STUDIO CO-PILOT */}
          {activeTab === 'ai' && (
            <div className="space-y-3.5">
              {/* Active AI Approval Card (User Consent Required before mutating timeline) */}
              {activeAIProposal && (
                <div className="p-3.5 rounded-xl bg-gradient-to-br from-[#2B124C] via-[#1B1336] to-[#141422] border border-[#EC4899] shadow-xl space-y-2.5 animate-in fade-in zoom-in-95 duration-150">
                  <div className="flex items-center justify-between">
                    <span className="inline-flex items-center gap-1 text-[10px] font-mono-code font-bold uppercase px-2 py-0.5 rounded-full bg-gradient-to-r from-[#8B5CF6] to-[#EC4899] text-white">
                      <Sparkles className="w-3 h-3" />
                      Approval Required
                    </span>
                    <button
                      onClick={onDismissAIProposal}
                      className="text-[#9494A8] hover:text-white cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                  <h4 className="font-display font-bold text-xs text-white">
                    {activeAIProposal.title}
                  </h4>
                  <p className="text-[11px] text-[#D4D4E8]">{activeAIProposal.description}</p>
                  <ul className="space-y-1 text-[10px] text-[#A855F7] bg-[#09090E]/70 p-2 rounded-lg border border-[#262636]">
                    {activeAIProposal.changesSummary.map((line, i) => (
                      <li key={i} className="flex items-center gap-1.5">
                        <Check className="w-3 h-3 text-[#10B981] shrink-0" />
                        <span>{line}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <button
                      onClick={() => onApproveAIProposal(activeAIProposal)}
                      className="py-1.5 px-3 rounded-lg bg-gradient-to-r from-[#10B981] to-[#059669] text-black font-bold text-xs flex items-center justify-center gap-1 shadow cursor-pointer"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Approve & Apply</span>
                    </button>
                    <button
                      onClick={onDismissAIProposal}
                      className="py-1.5 px-3 rounded-lg bg-[#111118] hover:bg-[#262636] text-[#9494A8] hover:text-white font-semibold text-xs cursor-pointer"
                    >
                      Dismiss
                    </button>
                  </div>
                </div>
              )}

              {/* AI Smart Tools List */}
              <div className="space-y-2">
                <h3 className="text-[11px] font-semibold uppercase tracking-wider text-[#9494A8]">
                  AI Assistant Suggestions
                </h3>

                {[
                  {
                    id: 'prop-beat-edit',
                    icon: <Zap className="w-4 h-4 text-[#EC4899]" />,
                    title: 'AI Beat-Sync & Dynamic Transitions',
                    description:
                      'Detects 128 BPM transients, aligns video cuts to beat markers, and inserts Zoom & Glitch transitions.',
                    changesSummary: [
                      'Generate 128 BPM beat markers on ruler',
                      'Snap Track V1 video cuts to nearest beat',
                      'Apply Hyper Zoom & Glitch transitions (0.5s)',
                    ],
                    actionType: 'beat-sync-edit' as const,
                  },
                  {
                    id: 'prop-captions',
                    icon: <Subtitles className="w-4 h-4 text-[#F59E0B]" />,
                    title: 'AI Auto-Captions & Viral Pop Style',
                    description:
                      'Analyzes voice/dialogue timing and generates synchronized high-retention captions on Track T1.',
                    changesSummary: [
                      'Create 4 timed subtitle segments on Track T1',
                      'Apply TikTok Pop yellow/black stroke styling',
                      'Enable Bounce-Pop word entry animation',
                    ],
                    actionType: 'auto-captions' as const,
                  },
                  {
                    id: 'prop-chroma',
                    icon: <Layers className="w-4 h-4 text-[#10B981]" />,
                    title: 'AI Green-Screen Chroma Key Composite',
                    description:
                      'Places/activates the Holo Presenter on Track V2 and isolates the subject with spill suppression.',
                    changesSummary: [
                      'Enable RGB Chroma Key (#00FF00) on V2 overlay',
                      'Optimize similarity (46%) & edge feathering (16%)',
                      'Composite cleanly over V1 background track',
                    ],
                    actionType: 'background-remove' as const,
                  },
                  {
                    id: 'prop-highlight',
                    icon: <Scissors className="w-4 h-4 text-[#22D3EE]" />,
                    title: 'AI Highlight Detection & Speed Ramp',
                    description:
                      'Identifies peak action frames, trims dead air, and applies Montage speed ramping.',
                    changesSummary: [
                      'Apply Montage Fast-Slow-Fast speed curve on V1',
                      'Boost color contrast (+18) & saturation (+24)',
                      'Add Cyber Whoosh SFX on transition point',
                    ],
                    actionType: 'highlight-trim' as const,
                  },
                  {
                    id: 'prop-grade',
                    icon: <Sliders className="w-4 h-4 text-[#A855F7]" />,
                    title: 'AI Cyberpunk Master Color Grade',
                    description:
                      'Applies unified Cyberpunk 2099 LUT across all video clips with anamorphic scope bars.',
                    changesSummary: [
                      'Apply Cyberpunk 2099 LUT to all video clips',
                      'Add 2.35:1 Anamorphic Cinema Bars on FX1',
                    ],
                    actionType: 'cyberpunk-grade' as const,
                  },
                ].map((card) => (
                  <div
                    key={card.id}
                    onClick={() =>
                      onProposeAIEdit({
                        id: card.id,
                        title: card.title,
                        description: card.description,
                        changesSummary: card.changesSummary,
                        actionType: card.actionType,
                      })
                    }
                    className="p-3 rounded-xl bg-[#181822] hover:bg-[#1F1F2E] border border-[#262636] hover:border-[#A855F7] transition-all cursor-pointer space-y-1"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        {card.icon}
                        <span className="text-xs font-bold text-[#F4F4F8]">
                          {card.title}
                        </span>
                      </div>
                    </div>
                    <p className="text-[11px] text-[#9494A8] leading-relaxed">
                      {card.description}
                    </p>
                    <span className="inline-block text-[10px] font-semibold text-[#A855F7] pt-0.5">
                      Preview AI Proposal →
                    </span>
                  </div>
                ))}
              </div>

              {/* AI Smart Auto-Reframe for Social Platforms */}
              <div className="p-3 rounded-xl bg-[#181822] border border-[#262636] space-y-2">
                <h4 className="text-xs font-bold text-[#F4F4F8] flex items-center gap-1.5">
                  <Smartphone className="w-3.5 h-3.5 text-[#EC4899]" />
                  Smart Auto-Reframe (Aspect Ratio)
                </h4>
                <p className="text-[10px] text-[#9494A8]">
                  Intelligently resizes canvas, centers subjects, and enables ambient blurred background fill.
                </p>
                <div className="grid grid-cols-2 gap-1.5">
                  {(
                    [
                      { ar: '9:16' as AspectRatioOption, label: 'TikTok / Shorts (9:16)' },
                      { ar: '16:9' as AspectRatioOption, label: 'YouTube HD (16:9)' },
                      { ar: '4:5' as AspectRatioOption, label: 'IG Reels Feed (4:5)' },
                      { ar: '1:1' as AspectRatioOption, label: 'Square Post (1:1)' },
                    ] as const
                  ).map((preset) => (
                    <button
                      key={preset.ar}
                      onClick={() =>
                        onProposeAIEdit({
                          id: `reframe-${preset.ar}`,
                          title: `Smart Auto-Reframe to ${preset.label}`,
                          description: `Converts project canvas to ${preset.ar}, reframes active overlays, and activates Gaussian background blur fill.`,
                          changesSummary: [
                            `Switch project aspect ratio to ${preset.ar}`,
                            'Enable ambient Gaussian blur fill on V1 clips',
                            'Auto-center captions within safe title bounds',
                          ],
                          actionType: 'smart-reframe',
                          targetAspectRatio: preset.ar,
                        })
                      }
                      className="py-1.5 px-2 rounded-lg bg-[#111118] hover:bg-[#8B5CF6]/25 border border-[#262636] hover:border-[#8B5CF6] text-[10px] font-semibold text-[#F4F4F8] flex items-center justify-center gap-1 cursor-pointer"
                    >
                      {preset.ar === '16:9' ? (
                        <Monitor className="w-3 h-3 text-[#A855F7]" />
                      ) : (
                        <Smartphone className="w-3 h-3 text-[#EC4899]" />
                      )}
                      <span>{preset.ar}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
