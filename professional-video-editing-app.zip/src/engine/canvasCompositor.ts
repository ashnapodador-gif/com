import {
  AspectRatioOption,
  ColorGradingSettings,
  Keyframe,
  TimelineClip,
  TimelineTrack,
} from '../types/editor';
import { FILTER_PRESETS_INFO } from '../data/presets';

export function getCanvasDimensions(
  aspectRatio: AspectRatioOption,
  baseShortEdge = 720
): { width: number; height: number } {
  switch (aspectRatio) {
    case '16:9':
      return { width: Math.round((baseShortEdge * 16) / 9), height: baseShortEdge };
    case '9:16':
      return { width: baseShortEdge, height: Math.round((baseShortEdge * 16) / 9) };
    case '1:1':
      return { width: baseShortEdge, height: baseShortEdge };
    case '4:5':
      return { width: baseShortEdge, height: Math.round((baseShortEdge * 5) / 4) };
  }
}

export function formatTimecode(seconds: number, fps = 30): string {
  const safe = Math.max(0, seconds);
  const mins = Math.floor(safe / 60);
  const secs = Math.floor(safe % 60);
  const frames = Math.floor((safe % 1) * fps);
  const mm = String(mins).padStart(2, '0');
  const ss = String(secs).padStart(2, '0');
  const ff = String(frames).padStart(2, '0');
  return `${mm}:${ss}:${ff}`;
}

export function computeClipLocalTime(clip: TimelineClip, timelineTime: number): number {
  const elapsed = Math.max(0, timelineTime - clip.startTime);
  const progress = clip.duration > 0 ? Math.min(1, elapsed / clip.duration) : 0;

  // Apply speed ramp curve to progress
  let rampedProgress = progress;
  switch (clip.speedRamp) {
    case 'montage':
      // Fast in, slow middle, fast out
      rampedProgress =
        progress < 0.5
          ? 2 * progress * progress
          : 1 - Math.pow(-2 * progress + 2, 2) / 2;
      break;
    case 'hero-slowmo':
      // Normal then dramatic slow motion after 40%
      rampedProgress = progress < 0.4 ? progress * 1.4 : 0.56 + (progress - 0.4) * 0.35;
      break;
    case 'jump-boost':
      rampedProgress = Math.pow(progress, 0.65);
      break;
    case 'bullet-time':
      rampedProgress = progress * 0.45 + 0.55 * Math.pow(progress, 3);
      break;
    default:
      rampedProgress = progress;
  }

  const effectiveElapsed = rampedProgress * clip.duration * clip.speed;
  if (clip.reverse) {
    return Math.max(0, clip.trimStart + clip.duration * clip.speed - effectiveElapsed);
  }
  return clip.trimStart + effectiveElapsed;
}

export function interpolateKeyframes(
  clip: TimelineClip,
  localTime: number
): { x: number; y: number; scale: number; rotation: number; opacity: number } {
  const base = {
    x: clip.x,
    y: clip.y,
    scale: clip.scale,
    rotation: clip.rotation,
    opacity: clip.opacity,
  };

  if (!clip.keyframes || clip.keyframes.length === 0) {
    return base;
  }

  const sorted: Keyframe[] = [...clip.keyframes].sort((a, b) => a.timeOffset - b.timeOffset);
  if (localTime <= sorted[0].timeOffset) {
    const k = sorted[0];
    return { x: k.x, y: k.y, scale: k.scale, rotation: k.rotation, opacity: k.opacity };
  }
  if (localTime >= sorted[sorted.length - 1].timeOffset) {
    const k = sorted[sorted.length - 1];
    return { x: k.x, y: k.y, scale: k.scale, rotation: k.rotation, opacity: k.opacity };
  }

  for (let i = 0; i < sorted.length - 1; i++) {
    const k1 = sorted[i];
    const k2 = sorted[i + 1];
    if (localTime >= k1.timeOffset && localTime <= k2.timeOffset) {
      const span = Math.max(0.0001, k2.timeOffset - k1.timeOffset);
      const rawT = (localTime - k1.timeOffset) / span;
      // Smoothstep easing
      const t = rawT * rawT * (3 - 2 * rawT);
      return {
        x: k1.x + (k2.x - k1.x) * t,
        y: k1.y + (k2.y - k1.y) * t,
        scale: k1.scale + (k2.scale - k1.scale) * t,
        rotation: k1.rotation + (k2.rotation - k1.rotation) * t,
        opacity: k1.opacity + (k2.opacity - k1.opacity) * t,
      };
    }
  }

  return base;
}

function getEffectiveColorSettings(color: ColorGradingSettings): ColorGradingSettings {
  if (color.filterPreset === 'none') return color;
  const presetObj = FILTER_PRESETS_INFO.find((p) => p.id === color.filterPreset);
  const p: Partial<ColorGradingSettings> = presetObj?.settings || {};
  return {
    brightness: color.brightness + (p.brightness || 0),
    contrast: color.contrast + (p.contrast || 0),
    saturation: color.saturation + (p.saturation || 0),
    exposure: color.exposure + (p.exposure || 0),
    hue: color.hue + (p.hue || 0),
    temperature: color.temperature + (p.temperature || 0),
    vignette: Math.max(color.vignette, p.vignette || 0),
    blur: color.blur,
    filterPreset: color.filterPreset,
  };
}

export function buildCssFilterString(color: ColorGradingSettings, extraBlur = 0): string {
  const c = getEffectiveColorSettings(color);
  const b = Math.max(0, 100 + c.brightness + c.exposure * 0.6);
  const ct = Math.max(0, 100 + c.contrast);
  const sat = Math.max(0, 100 + c.saturation);
  const hue = c.hue;
  const totalBlur = Math.max(0, c.blur * 0.25 + extraBlur);

  const parts: string[] = [
    `brightness(${b.toFixed(0)}%)`,
    `contrast(${ct.toFixed(0)}%)`,
    `saturate(${sat.toFixed(0)}%)`,
  ];
  if (Math.abs(hue) > 0.5) {
    parts.push(`hue-rotate(${hue.toFixed(0)}deg)`);
  }
  if (totalBlur > 0.2) {
    parts.push(`blur(${totalBlur.toFixed(1)}px)`);
  }
  return parts.join(' ');
}

function hexToRgb(hex: string): { r: number; g: number; b: number } {
  const clean = hex.replace('#', '');
  const num = parseInt(clean.length === 3 ? clean.replace(/(.)/g, '$1$1') : clean, 16);
  if (Number.isNaN(num)) return { r: 0, g: 255, b: 0 };
  return {
    r: (num >> 16) & 255,
    g: (num >> 8) & 255,
    b: num & 255,
  };
}

// Reusable offscreen canvas for Chroma Key pixel processing
let offscreenCanvas: HTMLCanvasElement | null = null;

function getOffscreenCanvas(w: number, h: number): HTMLCanvasElement {
  if (!offscreenCanvas) {
    offscreenCanvas = document.createElement('canvas');
  }
  if (offscreenCanvas.width !== w || offscreenCanvas.height !== h) {
    offscreenCanvas.width = w;
    offscreenCanvas.height = h;
  }
  return offscreenCanvas;
}

/**
 * Renders procedural 60fps studio shaders for built-in clips or fallback when video element isn't ready
 */
export function drawProceduralScene(
  ctx: CanvasRenderingContext2D,
  preset: string,
  time: number,
  w: number,
  h: number
) {
  ctx.save();
  if (preset === 'greenscreen-presenter') {
    // Pure #00FF00 Green Screen background for real-time Chroma Key removal demo!
    ctx.fillStyle = '#00FF00';
    ctx.fillRect(0, 0, w, h);

    const cx = w * 0.5;
    const cy = h * 0.56;
    const bob = Math.sin(time * 3.5) * (h * 0.018);

    // Holographic Outer Ring behind presenter
    ctx.strokeStyle = '#8B5CF6';
    ctx.lineWidth = Math.max(3, w * 0.006);
    ctx.beginPath();
    ctx.arc(cx, cy - h * 0.06 + bob, Math.min(w, h) * 0.28, 0, Math.PI * 2);
    ctx.stroke();

    // Rotating Cyber Arcs
    ctx.strokeStyle = '#22D3EE';
    ctx.lineWidth = Math.max(4, w * 0.008);
    ctx.beginPath();
    ctx.arc(
      cx,
      cy - h * 0.06 + bob,
      Math.min(w, h) * 0.32,
      time * 1.8,
      time * 1.8 + Math.PI * 0.75
    );
    ctx.stroke();

    // Stylized Cyber Presenter Silhouette / Avatar
    const gradBody = ctx.createLinearGradient(cx, cy - h * 0.25, cx, cy + h * 0.35);
    gradBody.addColorStop(0, '#4F46E5');
    gradBody.addColorStop(0.5, '#7C3AED');
    gradBody.addColorStop(1, '#EC4899');

    // Shoulders / Jacket
    ctx.fillStyle = gradBody;
    ctx.beginPath();
    ctx.roundRect(
      cx - w * 0.16,
      cy - h * 0.02 + bob,
      w * 0.32,
      h * 0.34,
      [w * 0.08, w * 0.08, w * 0.02, w * 0.02]
    );
    ctx.fill();

    // Neon Collar Trim
    ctx.strokeStyle = '#F4F4F8';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(cx - w * 0.07, cy - h * 0.02 + bob);
    ctx.lineTo(cx, cy + h * 0.1 + bob);
    ctx.lineTo(cx + w * 0.07, cy - h * 0.02 + bob);
    ctx.stroke();

    // Head / Visor Helmet
    ctx.fillStyle = '#1E1B4B';
    ctx.beginPath();
    ctx.arc(cx, cy - h * 0.14 + bob, Math.min(w, h) * 0.11, 0, Math.PI * 2);
    ctx.fill();
    ctx.lineWidth = 3;
    ctx.strokeStyle = '#A855F7';
    ctx.stroke();

    // Glowing LED Cyber Visor
    const visorGrad = ctx.createLinearGradient(cx - w * 0.07, 0, cx + w * 0.07, 0);
    visorGrad.addColorStop(0, '#22D3EE');
    visorGrad.addColorStop(0.5, '#F472B6');
    visorGrad.addColorStop(1, '#22D3EE');
    ctx.fillStyle = visorGrad;
    ctx.beginPath();
    ctx.roundRect(
      cx - w * 0.065,
      cy - h * 0.165 + bob,
      w * 0.13,
      h * 0.042,
      8
    );
    ctx.fill();

    // Audio-reactive equalizer bars on chest
    for (let i = -3; i <= 3; i++) {
      const barH = (0.03 + 0.04 * Math.abs(Math.sin(time * 8 + i * 0.9))) * h;
      ctx.fillStyle = '#22D3EE';
      ctx.fillRect(
        cx + i * (w * 0.016) - w * 0.005,
        cy + h * 0.16 + bob - barH * 0.5,
        w * 0.01,
        barH
      );
    }

    // Floating Telemetry Badge
    ctx.fillStyle = '#181822';
    ctx.strokeStyle = '#EC4899';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(cx - w * 0.14, cy + h * 0.24 + bob, w * 0.28, h * 0.065, 8);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = '#FFFFFF';
    ctx.font = `700 ${Math.max(12, Math.round(h * 0.026))}px "JetBrains Mono", monospace`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('CHROMA KEY // ACTIVE', cx, cy + h * 0.273 + bob);

    ctx.restore();
    return;
  }

  if (preset === 'hyper-tunnel') {
    // Deep Space Quantum Warp Tunnel
    const bg = ctx.createRadialGradient(w * 0.5, h * 0.5, 10, w * 0.5, h * 0.5, Math.max(w, h) * 0.7);
    bg.addColorStop(0, '#2E1065');
    bg.addColorStop(0.5, '#0F0728');
    bg.addColorStop(1, '#05050A');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, w, h);

    const cx = w * 0.5 + Math.sin(time * 1.4) * (w * 0.04);
    const cy = h * 0.5 + Math.cos(time * 1.1) * (h * 0.04);

    for (let i = 0; i < 16; i++) {
      const phase = ((time * 0.85 + i / 16) % 1);
      const radius = Math.pow(phase, 2.1) * Math.max(w, h) * 0.75;
      ctx.strokeStyle = i % 2 === 0 ? `rgba(139, 92, 246, ${phase})` : `rgba(34, 211, 238, ${phase})`;
      ctx.lineWidth = 1.5 + phase * 5;
      ctx.beginPath();
      for (let side = 0; side <= 6; side++) {
        const ang = (side * Math.PI) / 3 + time * 0.5 + phase * 1.2;
        const px = cx + Math.cos(ang) * radius;
        const py = cy + Math.sin(ang) * radius;
        if (side === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.stroke();
    }
    ctx.restore();
    return;
  }

  if (preset === 'aurora-waves' || preset === 'synth-corridor') {
    const bg = ctx.createLinearGradient(0, 0, 0, h);
    bg.addColorStop(0, '#090919');
    bg.addColorStop(0.55, '#2E1065');
    bg.addColorStop(0.6, '#EC4899');
    bg.addColorStop(1, '#09090E');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, w, h);

    // Retro Sun
    const sunGrad = ctx.createLinearGradient(0, h * 0.2, 0, h * 0.58);
    sunGrad.addColorStop(0, '#FACC15');
    sunGrad.addColorStop(0.5, '#F97316');
    sunGrad.addColorStop(1, '#EC4899');
    ctx.fillStyle = sunGrad;
    ctx.beginPath();
    ctx.arc(w * 0.5, h * 0.42, Math.min(w, h) * 0.18, 0, Math.PI * 2);
    ctx.fill();

    // Perspective Grid Floor
    const horizon = h * 0.58;
    ctx.strokeStyle = 'rgba(34, 211, 238, 0.55)';
    ctx.lineWidth = 1.5;
    for (let i = -12; i <= 12; i++) {
      ctx.beginPath();
      ctx.moveTo(w * 0.5 + i * (w * 0.02), horizon);
      ctx.lineTo(w * 0.5 + i * (w * 0.14), h);
      ctx.stroke();
    }
    const scroll = (time * 1.5) % 1;
    for (let j = 0; j < 10; j++) {
      const p = Math.pow((j + scroll) / 10, 2);
      const yPos = horizon + p * (h - horizon);
      ctx.beginPath();
      ctx.moveTo(0, yPos);
      ctx.lineTo(w, yPos);
      ctx.stroke();
    }
    ctx.restore();
    return;
  }

  // Default 'neon-city' procedural backdrop
  const grad = ctx.createLinearGradient(0, 0, w, h);
  grad.addColorStop(0, '#0F172A');
  grad.addColorStop(0.5, '#3B0764');
  grad.addColorStop(1, '#09090E');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);

  // Animated Neon Skyline Towers
  for (let i = 0; i < 22; i++) {
    const bw = w / 18;
    const bx = ((i * bw * 0.9 - time * 35) % (w + bw * 2)) - bw;
    const bh = (0.25 + 0.35 * Math.abs(Math.sin(i * 1.7))) * h;
    ctx.fillStyle = i % 2 === 0 ? '#111122' : '#191930';
    ctx.fillRect(bx, h - bh, bw * 0.82, bh);

    ctx.fillStyle = i % 3 === 0 ? '#EC4899' : '#22D3EE';
    for (let wy = h - bh + 14; wy < h - 16; wy += 22) {
      if (Math.sin(i * 3 + wy + Math.floor(time * 2)) > -0.2) {
        ctx.fillRect(bx + 8, wy, bw * 0.5, 6);
      }
    }
  }
  ctx.restore();
}

/**
 * Applies pixel-by-pixel Chroma Key background removal on an offscreen canvas
 */
function applyChromaKeyBuffer(
  offCtx: CanvasRenderingContext2D,
  w: number,
  h: number,
  keyColorHex: string,
  similarity: number,
  smoothness: number,
  spillSuppression: number
) {
  const imgData = offCtx.getImageData(0, 0, w, h);
  const data = imgData.data;
  const target = hexToRgb(keyColorHex);
  const thresh = (similarity / 100) * 260;
  const smoothRange = Math.max(1, (smoothness / 100) * 180);
  const spillFactor = spillSuppression / 100;

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];

    const dr = r - target.r;
    const dg = g - target.g;
    const db = b - target.b;
    const dist = Math.sqrt(dr * dr + dg * dg + db * db);

    if (dist < thresh) {
      data[i + 3] = 0;
    } else if (dist < thresh + smoothRange) {
      const alphaFactor = (dist - thresh) / smoothRange;
      data[i + 3] = Math.round(data[i + 3] * alphaFactor);
      if (spillFactor > 0 && target.g > target.r && target.g > target.b) {
        data[i + 1] = Math.round(Math.min(g, (r + b) * 0.55 + g * (1 - spillFactor)));
      }
    }
  }

  offCtx.putImageData(imgData, 0, 0);
}

/**
 * Renders an Effect Overlay clip onto the main canvas
 */
function renderEffectOverlay(
  ctx: CanvasRenderingContext2D,
  clip: TimelineClip,
  time: number,
  w: number,
  h: number
) {
  const type = clip.effectOverlayType || 'vhs';
  ctx.save();
  ctx.globalAlpha = (clip.opacity / 100);

  if (type === 'cinema-bars') {
    const barH = h * 0.12;
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, w, barH);
    ctx.fillRect(0, h - barH, w, barH);
  } else if (type === 'vhs') {
    // Scanlines
    ctx.fillStyle = 'rgba(255, 255, 255, 0.04)';
    for (let y = 0; y < h; y += 4) {
      ctx.fillRect(0, y, w, 1.5);
    }
    // Tracking bar
    const barY = ((time * 140) % (h + 80)) - 40;
    const grad = ctx.createLinearGradient(0, barY, 0, barY + 36);
    grad.addColorStop(0, 'rgba(236, 72, 153, 0)');
    grad.addColorStop(0.5, 'rgba(34, 211, 238, 0.18)');
    grad.addColorStop(1, 'rgba(236, 72, 153, 0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, barY, w, 36);
  } else if (type === 'rgb-split') {
    // Chromatic edge glow
    const pulse = Math.sin(time * 8) * 6;
    ctx.strokeStyle = 'rgba(34, 211, 238, 0.4)';
    ctx.lineWidth = 6 + Math.abs(pulse);
    ctx.strokeRect(4, 4, w - 8, h - 8);
    ctx.strokeStyle = 'rgba(236, 72, 153, 0.4)';
    ctx.strokeRect(8, 8, w - 16, h - 16);
  } else if (type === 'film-grain') {
    // Procedural film grain specks
    ctx.fillStyle = 'rgba(255, 250, 240, 0.09)';
    const seed = Math.floor(time * 24);
    for (let i = 0; i < 90; i++) {
      const gx = ((seed * 97 + i * 313) % 1000) * 0.001 * w;
      const gy = ((seed * 53 + i * 617) % 1000) * 0.001 * h;
      ctx.fillRect(gx, gy, 2, 2);
    }
  } else if (type === 'neon-frame') {
    // Cyber HUD Viewfinder brackets + REC indicator
    const pad = Math.min(w, h) * 0.045;
    const len = Math.min(w, h) * 0.07;
    ctx.strokeStyle = '#8B5CF6';
    ctx.lineWidth = 2.5;

    // Top-left
    ctx.beginPath();
    ctx.moveTo(pad, pad + len);
    ctx.lineTo(pad, pad);
    ctx.lineTo(pad + len, pad);
    // Top-right
    ctx.moveTo(w - pad - len, pad);
    ctx.lineTo(w - pad, pad);
    ctx.lineTo(w - pad, pad + len);
    // Bottom-left
    ctx.moveTo(pad, h - pad - len);
    ctx.lineTo(pad, h - pad);
    ctx.lineTo(pad + len, h - pad);
    // Bottom-right
    ctx.moveTo(w - pad - len, h - pad);
    ctx.lineTo(w - pad, h - pad);
    ctx.lineTo(w - pad, h - pad - len);
    ctx.stroke();

    // Blinking REC dot
    if (Math.sin(time * 5) > -0.2) {
      ctx.fillStyle = '#EF4444';
      ctx.beginPath();
      ctx.arc(pad + 16, pad + 16, 5, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.fillStyle = 'rgba(244, 244, 248, 0.8)';
    ctx.font = `600 ${Math.max(11, Math.round(h * 0.018))}px "JetBrains Mono", monospace`;
    ctx.fillText('REC ● 60FPS RAW', pad + 28, pad + 20);
  } else if (type === 'light-leak') {
    const lx = (0.5 + 0.4 * Math.sin(time * 1.3)) * w;
    const ly = (0.5 + 0.3 * Math.cos(time * 0.9)) * h;
    const leak = ctx.createRadialGradient(lx, ly, 10, lx, ly, Math.max(w, h) * 0.55);
    leak.addColorStop(0, 'rgba(249, 115, 22, 0.38)');
    leak.addColorStop(0.5, 'rgba(236, 72, 153, 0.22)');
    leak.addColorStop(1, 'rgba(139, 92, 246, 0)');
    ctx.fillStyle = leak;
    ctx.fillRect(0, 0, w, h);
  } else if (type === 'bokeh-pulse') {
    for (let i = 0; i < 14; i++) {
      const bx = ((i * 137 + time * 28 * (1 + (i % 3) * 0.3)) % (w + 80)) - 40;
      const by = ((i * 251 - time * 20) % (h + 80));
      const finalY = by < 0 ? by + h : by;
      const rad = 12 + (i % 4) * 10;
      ctx.fillStyle = i % 2 === 0 ? 'rgba(168, 85, 247, 0.22)' : 'rgba(34, 211, 238, 0.2)';
      ctx.beginPath();
      ctx.arc(bx, finalY, rad, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  ctx.restore();
}

/**
 * Renders Text / Subtitle Clip with animations, gradients, outlines, shadows, and background pill
 */
function renderTextClip(
  ctx: CanvasRenderingContext2D,
  clip: TimelineClip,
  timelineTime: number,
  w: number,
  h: number
) {
  const ts = clip.textStyle;
  if (!ts || !ts.text) return;

  const localTime = Math.max(0, timelineTime - clip.startTime);
  const kf = interpolateKeyframes(clip, localTime);

  ctx.save();
  const cx = w * 0.5 + (kf.x / 100) * (w * 0.5);
  let cy = h * 0.5 + (kf.y / 100) * (h * 0.5);
  let scale = kf.scale / 100;
  let alpha = (kf.opacity / 100);
  let offsetX = 0;

  // Text Animation Modifiers
  let displayedText = ts.text;
  const animProgress = Math.min(1, localTime / 0.55);

  if (ts.animation === 'typewriter') {
    const typeSpan = Math.min(1.6, clip.duration * 0.7);
    const charCount = Math.max(
      1,
      Math.floor(Math.min(1, localTime / Math.max(0.2, typeSpan)) * ts.text.length)
    );
    displayedText = ts.text.slice(0, charCount);
  } else if (ts.animation === 'bounce') {
    const bounce =
      animProgress < 1
        ? 0.3 + 0.7 * Math.sin(animProgress * Math.PI * 1.3) * 1.15
        : 1 + 0.03 * Math.sin(localTime * 6);
    scale *= bounce;
  } else if (ts.animation === 'fade-up') {
    alpha *= animProgress;
    cy += (1 - animProgress) * 32;
  } else if (ts.animation === 'slide-in') {
    const ease = 1 - Math.pow(1 - animProgress, 3);
    offsetX = (1 - ease) * -w * 0.35;
    alpha *= ease;
  } else if (ts.animation === 'wave') {
    cy += Math.sin(localTime * 6) * 8;
  } else if (ts.animation === 'glitch') {
    if (Math.sin(localTime * 28) > 0.65) {
      offsetX = (Math.sin(localTime * 95) * 8);
    }
  }

  ctx.translate(cx + offsetX, cy);
  ctx.rotate((kf.rotation * Math.PI) / 180);
  ctx.scale(scale, scale);
  ctx.globalAlpha = Math.max(0, Math.min(1, alpha));

  const scaledFontSize = Math.max(14, Math.round((ts.fontSize / 720) * Math.min(w, h)));
  ctx.font = `${ts.fontWeight} ${scaledFontSize}px "${ts.fontFamily}", sans-serif`;
  ctx.textAlign = ts.align;
  ctx.textBaseline = 'middle';

  const metrics = ctx.measureText(displayedText);
  const textWidth = metrics.width;
  const boxPadX = scaledFontSize * 0.45;
  const boxPadY = scaledFontSize * 0.28;

  // Optional Pill Background
  if (ts.bgOpacity > 0) {
    ctx.save();
    ctx.globalAlpha = alpha * (ts.bgOpacity / 100);
    ctx.fillStyle = ts.bgColor || '#09090E';
    let boxX = -textWidth * 0.5 - boxPadX;
    if (ts.align === 'left') boxX = -boxPadX;
    if (ts.align === 'right') boxX = -textWidth - boxPadX;
    ctx.beginPath();
    ctx.roundRect(
      boxX,
      -scaledFontSize * 0.5 - boxPadY,
      textWidth + boxPadX * 2,
      scaledFontSize + boxPadY * 2,
      10
    );
    ctx.fill();
    ctx.restore();
  }

  // Shadow
  if (ts.shadowBlur > 0) {
    ctx.shadowColor = ts.shadowColor || '#000000';
    ctx.shadowBlur = ts.shadowBlur;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 2;
  }

  // Outline Stroke
  if (ts.outlineWidth > 0) {
    ctx.strokeStyle = ts.outlineColor || '#000000';
    ctx.lineWidth = ts.outlineWidth * 1.6;
    ctx.lineJoin = 'round';
    ctx.strokeText(displayedText, 0, 0);
  }

  // Fill (Solid or Gradient)
  if (ts.useGradient) {
    const grad = ctx.createLinearGradient(-textWidth * 0.5, -scaledFontSize * 0.5, textWidth * 0.5, scaledFontSize * 0.5);
    grad.addColorStop(0, ts.color);
    grad.addColorStop(1, ts.gradientColor2 || '#EC4899');
    ctx.fillStyle = grad;
  } else {
    ctx.fillStyle = ts.color;
  }

  ctx.fillText(displayedText, 0, 0);
  ctx.restore();
}

/**
 * Renders Sticker Clip
 */
function renderStickerClip(
  ctx: CanvasRenderingContext2D,
  clip: TimelineClip,
  timelineTime: number,
  w: number,
  h: number
) {
  const localTime = Math.max(0, timelineTime - clip.startTime);
  const kf = interpolateKeyframes(clip, localTime);

  ctx.save();
  const cx = w * 0.5 + (kf.x / 100) * (w * 0.5);
  const cy = h * 0.5 + (kf.y / 100) * (h * 0.5);
  const pulse = 1 + 0.06 * Math.sin(localTime * 6);
  const scale = (kf.scale / 100) * pulse;

  ctx.translate(cx, cy);
  ctx.rotate((kf.rotation * Math.PI) / 180);
  ctx.scale(scale, scale);
  ctx.globalAlpha = Math.max(0, Math.min(1, kf.opacity / 100));

  const size = Math.round(Math.min(w, h) * 0.14);
  ctx.font = `${size}px sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(clip.stickerEmoji || '🔥', 0, 0);
  ctx.restore();
}

/**
 * Main Frame Renderer: Composites all visible tracks in bottom-to-top order
 */
export function renderCompositeFrame(params: {
  ctx: CanvasRenderingContext2D;
  width: number;
  height: number;
  timelineTime: number;
  tracks: TimelineTrack[];
  clips: TimelineClip[];
  videoElements: Map<string, HTMLVideoElement>;
  imageElements: Map<string, HTMLImageElement>;
  selectedClipId: string | null;
  showSafeGuides: boolean;
}) {
  const {
    ctx,
    width: w,
    height: h,
    timelineTime,
    tracks,
    clips,
    videoElements,
    imageElements,
    selectedClipId,
    showSafeGuides,
  } = params;

  // Clear Obsidian Canvas
  ctx.clearRect(0, 0, w, h);
  ctx.fillStyle = '#07070C';
  ctx.fillRect(0, 0, w, h);

  // Render tracks: V1 first, then V2, then FX1, then T1
  const orderedTracks = [...tracks].reverse();

  for (const track of orderedTracks) {
    if (track.hidden || track.type === 'audio') continue;

    const activeClips = clips
      .filter(
        (c) =>
          c.trackId === track.id &&
          timelineTime >= c.startTime &&
          timelineTime <= c.startTime + c.duration
      )
      .sort((a, b) => a.startTime - b.startTime);

    for (const clip of activeClips) {
      if (clip.type === 'text') {
        renderTextClip(ctx, clip, timelineTime, w, h);
        continue;
      }
      if (clip.type === 'sticker') {
        renderStickerClip(ctx, clip, timelineTime, w, h);
        continue;
      }
      if (clip.type === 'effect') {
        renderEffectOverlay(ctx, clip, timelineTime, w, h);
        continue;
      }

      // Video or Image Clip
      const localElapsed = Math.max(0, timelineTime - clip.startTime);
      const remaining = Math.max(0, clip.startTime + clip.duration - timelineTime);
      const sourceTime = computeClipLocalTime(clip, timelineTime);
      const kf = interpolateKeyframes(clip, localElapsed);

      // Compute Transition Modifiers (In & Out)
      let transAlpha = 1;
      let transScale = 1;
      let transX = 0;
      let transY = 0;
      let transRot = 0;
      let transBlur = 0;
      let isGlitching = false;

      if (clip.transitionIn.type !== 'none' && localElapsed < clip.transitionIn.duration) {
        const p = Math.max(0, Math.min(1, localElapsed / clip.transitionIn.duration));
        const ease = p * p * (3 - 2 * p);
        switch (clip.transitionIn.type) {
          case 'fade':
            transAlpha *= ease;
            break;
          case 'zoom':
            transScale *= 0.35 + 0.65 * ease;
            transAlpha *= ease;
            break;
          case 'slide-left':
            transX += (1 - ease) * w;
            break;
          case 'slide-up':
            transY += (1 - ease) * h;
            break;
          case 'blur':
            transBlur += (1 - ease) * 18;
            transAlpha *= ease;
            break;
          case 'glitch':
            isGlitching = true;
            transX += Math.sin(localElapsed * 90) * (1 - ease) * 35;
            break;
          case 'spin':
            transRot += (1 - ease) * 360;
            transScale *= ease;
            break;
        }
      }

      if (clip.transitionOut.type !== 'none' && remaining < clip.transitionOut.duration) {
        const p = Math.max(0, Math.min(1, remaining / clip.transitionOut.duration));
        const ease = p * p * (3 - 2 * p);
        switch (clip.transitionOut.type) {
          case 'fade':
            transAlpha *= ease;
            break;
          case 'zoom':
            transScale *= 1 + (1 - ease) * 0.9;
            transAlpha *= ease;
            break;
          case 'slide-left':
            transX -= (1 - ease) * w;
            break;
          case 'slide-up':
            transY -= (1 - ease) * h;
            break;
          case 'blur':
            transBlur += (1 - ease) * 18;
            transAlpha *= ease;
            break;
          case 'glitch':
            isGlitching = true;
            transX += Math.cos(remaining * 90) * (1 - ease) * 35;
            break;
          case 'spin':
            transRot -= (1 - ease) * 360;
            transScale *= ease;
            break;
        }
      }

      ctx.save();
      ctx.globalCompositeOperation = clip.blendMode || 'source-over';
      ctx.globalAlpha = Math.max(0, Math.min(1, (kf.opacity / 100) * transAlpha));

      // Prepare source drawable (HTMLVideoElement, HTMLImageElement, or Procedural Shader)
      const vidEl = clip.url ? videoElements.get(clip.id) : undefined;
      const imgEl = clip.url ? imageElements.get(clip.id) : undefined;

      const hasReadyVideo =
        vidEl && vidEl.readyState >= 2 && vidEl.videoWidth > 0 && !clip.url?.startsWith('procedural://');
      const hasReadyImage =
        imgEl && imgEl.complete && imgEl.naturalWidth > 0;

      // Ambient Background Blur Fill (when enabled on main track V1)
      if (clip.backgroundBlurFill && track.id === 'track-v1' && !clip.chromaKey.enabled) {
        ctx.save();
        ctx.filter = `blur(24px) brightness(55%)`;
        if (hasReadyVideo && vidEl) {
          ctx.drawImage(vidEl, -w * 0.1, -h * 0.1, w * 1.2, h * 1.2);
        } else if (hasReadyImage && imgEl) {
          ctx.drawImage(imgEl, -w * 0.1, -h * 0.1, w * 1.2, h * 1.2);
        } else {
          drawProceduralScene(ctx, clip.proceduralPreset || 'neon-city', sourceTime, w, h);
        }
        ctx.restore();
      }

      // Spatial Transform Setup
      const centerX = w * 0.5 + (kf.x / 100) * (w * 0.5) + transX;
      const centerY = h * 0.5 + (kf.y / 100) * (h * 0.5) + transY;
      const finalScale = (kf.scale / 100) * transScale;
      const finalRot = ((kf.rotation + transRot) * Math.PI) / 180;

      ctx.translate(centerX, centerY);
      ctx.rotate(finalRot);
      ctx.scale(
        finalScale * (clip.flipH ? -1 : 1),
        finalScale * (clip.flipV ? -1 : 1)
      );

      // Crop Clipping Rectangle
      const cropL = (clip.crop.left / 100) * w;
      const cropR = (clip.crop.right / 100) * w;
      const cropT = (clip.crop.top / 100) * h;
      const cropB = (clip.crop.bottom / 100) * h;
      ctx.beginPath();
      ctx.rect(-w * 0.5 + cropL, -h * 0.5 + cropT, w - cropL - cropR, h - cropT - cropB);
      ctx.clip();

      // Apply Color Grading & LUT CSS Filter
      ctx.filter = buildCssFilterString(clip.color, transBlur);

      // Chroma Key Path vs Standard Draw Path
      if (clip.chromaKey.enabled) {
        const off = getOffscreenCanvas(w, h);
        const offCtx = off.getContext('2d', { willReadFrequently: true });
        if (offCtx) {
          offCtx.clearRect(0, 0, w, h);
          if (hasReadyVideo && vidEl) {
            try {
              offCtx.drawImage(vidEl, 0, 0, w, h);
            } catch {
              drawProceduralScene(offCtx, clip.proceduralPreset || 'greenscreen-presenter', sourceTime, w, h);
            }
          } else if (hasReadyImage && imgEl) {
            try {
              offCtx.drawImage(imgEl, 0, 0, w, h);
            } catch {
              drawProceduralScene(offCtx, clip.proceduralPreset || 'greenscreen-presenter', sourceTime, w, h);
            }
          } else {
            drawProceduralScene(
              offCtx,
              clip.proceduralPreset || 'greenscreen-presenter',
              sourceTime,
              w,
              h
            );
          }

          try {
            applyChromaKeyBuffer(
              offCtx,
              w,
              h,
              clip.chromaKey.keyColor,
              clip.chromaKey.similarity,
              clip.chromaKey.smoothness,
              clip.chromaKey.spillSuppression
            );
          } catch {
            // Fallback if CORS tainted
          }
          ctx.drawImage(off, -w * 0.5, -h * 0.5, w, h);
        }
      } else {
        if (hasReadyVideo && vidEl) {
          // Aspect-aware fit inside canvas
          const vw = vidEl.videoWidth;
          const vh = vidEl.videoHeight;
          const scaleFactor = Math.min(w / vw, h / vh);
          const dw = vw * scaleFactor;
          const dh = vh * scaleFactor;
          ctx.drawImage(vidEl, -dw * 0.5, -dh * 0.5, dw, dh);
        } else if (hasReadyImage && imgEl) {
          const iw = imgEl.naturalWidth;
          const ih = imgEl.naturalHeight;
          const scaleFactor = Math.min(w / iw, h / ih);
          const dw = iw * scaleFactor;
          const dh = ih * scaleFactor;
          ctx.drawImage(imgEl, -dw * 0.5, -dh * 0.5, dw, dh);
        } else {
          ctx.save();
          ctx.translate(-w * 0.5, -h * 0.5);
          drawProceduralScene(ctx, clip.proceduralPreset || 'neon-city', sourceTime, w, h);
          ctx.restore();
        }
      }

      // Temperature Overlay (Warm/Cool Color Cast)
      const effectiveColor = getEffectiveColorSettings(clip.color);
      if (Math.abs(effectiveColor.temperature) > 2) {
        ctx.filter = 'none';
        const tempAlpha = Math.min(0.28, Math.abs(effectiveColor.temperature) / 250);
        ctx.fillStyle =
          effectiveColor.temperature > 0
            ? `rgba(245, 158, 11, ${tempAlpha})`
            : `rgba(34, 211, 238, ${tempAlpha})`;
        ctx.fillRect(-w * 0.5, -h * 0.5, w, h);
      }

      // Vignette Overlay
      if (effectiveColor.vignette > 2) {
        ctx.filter = 'none';
        const vigGrad = ctx.createRadialGradient(0, 0, Math.min(w, h) * 0.25, 0, 0, Math.max(w, h) * 0.72);
        vigGrad.addColorStop(0, 'rgba(0,0,0,0)');
        vigGrad.addColorStop(1, `rgba(0,0,0,${Math.min(0.85, effectiveColor.vignette / 100)})`);
        ctx.fillStyle = vigGrad;
        ctx.fillRect(-w * 0.5, -h * 0.5, w, h);
      }

      // Glitch Transition Slice Bars
      if (isGlitching) {
        ctx.filter = 'none';
        ctx.fillStyle = 'rgba(236, 72, 153, 0.35)';
        ctx.fillRect(-w * 0.5, -h * 0.18, w, h * 0.06);
        ctx.fillStyle = 'rgba(34, 211, 238, 0.35)';
        ctx.fillRect(-w * 0.5, h * 0.12, w, h * 0.05);
      }

      ctx.restore();
    }
  }

  // Draw Selection Gizmo Handle if selected clip is visible on canvas
  if (selectedClipId) {
    const sel = clips.find(
      (c) =>
        c.id === selectedClipId &&
        c.type !== 'audio' &&
        c.type !== 'effect' &&
        timelineTime >= c.startTime &&
        timelineTime <= c.startTime + c.duration
    );
    if (sel) {
      const localElapsed = Math.max(0, timelineTime - sel.startTime);
      const kf = interpolateKeyframes(sel, localElapsed);
      const cx = w * 0.5 + (kf.x / 100) * (w * 0.5);
      const cy = h * 0.5 + (kf.y / 100) * (h * 0.5);
      const boxW = sel.type === 'text' ? w * 0.55 * (kf.scale / 100) : sel.type === 'sticker' ? w * 0.18 * (kf.scale / 100) : w * (kf.scale / 100);
      const boxH = sel.type === 'text' ? h * 0.14 * (kf.scale / 100) : sel.type === 'sticker' ? w * 0.18 * (kf.scale / 100) : h * (kf.scale / 100);

      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate((kf.rotation * Math.PI) / 180);
      ctx.strokeStyle = '#8B5CF6';
      ctx.lineWidth = 2;
      ctx.setLineDash([6, 4]);
      ctx.strokeRect(-boxW * 0.5, -boxH * 0.5, boxW, boxH);
      ctx.setLineDash([]);

      // Corner Resize Nodes
      const corners = [
        [-boxW * 0.5, -boxH * 0.5],
        [boxW * 0.5, -boxH * 0.5],
        [-boxW * 0.5, boxH * 0.5],
        [boxW * 0.5, boxH * 0.5],
      ];
      for (const [kx, ky] of corners) {
        ctx.fillStyle = '#FFFFFF';
        ctx.strokeStyle = '#8B5CF6';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(kx, ky, 5, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      }
      ctx.restore();
    }
  }

  // Optional Rule-of-Thirds & Social Safe Zone Guides
  if (showSafeGuides) {
    ctx.save();
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.18)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(w / 3, 0);
    ctx.lineTo(w / 3, h);
    ctx.moveTo((w * 2) / 3, 0);
    ctx.lineTo((w * 2) / 3, h);
    ctx.moveTo(0, h / 3);
    ctx.lineTo(w, h / 3);
    ctx.moveTo(0, (h * 2) / 3);
    ctx.lineTo(w, (h * 2) / 3);
    ctx.stroke();

    // Inner Title Safe Margin
    ctx.strokeStyle = 'rgba(139, 92, 246, 0.35)';
    ctx.setLineDash([4, 4]);
    ctx.strokeRect(w * 0.08, h * 0.08, w * 0.84, h * 0.84);
    ctx.restore();
  }
}
