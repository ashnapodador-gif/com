import { TimelineClip, TimelineTrack } from '../types/editor';

class StudioAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private exportDestination: MediaStreamAudioDestinationNode | null = null;
  private lastTriggeredBeatIndex = -1;
  private triggeredSfxIds: Set<string> = new Set();

  public ensureContext(): AudioContext {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = 0.85;
      this.masterGain.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public getExportAudioStream(): MediaStream | null {
    try {
      const ctx = this.ensureContext();
      if (!this.exportDestination) {
        this.exportDestination = ctx.createMediaStreamDestination();
        this.masterGain?.connect(this.exportDestination);
      }
      return this.exportDestination.stream;
    } catch {
      return null;
    }
  }

  public resetTriggers() {
    this.lastTriggeredBeatIndex = -1;
    this.triggeredSfxIds.clear();
  }

  /**
   * Computes current stereo VU meter level (0-100) and triggers synthesized beats/SFX during playback
   */
  public tickPlayback(params: {
    timelineTime: number;
    isPlaying: boolean;
    tracks: TimelineTrack[];
    clips: TimelineClip[];
    isMuted: boolean;
  }): { leftLevel: number; rightLevel: number } {
    const { timelineTime, isPlaying, tracks, clips, isMuted } = params;
    if (!isPlaying || isMuted) {
      return { leftLevel: 0, rightLevel: 0 };
    }

    let totalEnergy = 0;

    for (const clip of clips) {
      if (clip.type !== 'audio' && clip.type !== 'video') continue;
      if (timelineTime < clip.startTime || timelineTime > clip.startTime + clip.duration) continue;

      const track = tracks.find((t) => t.id === clip.trackId);
      if (!track || track.muted || track.hidden) continue;

      const localElapsed = timelineTime - clip.startTime;
      const remaining = clip.startTime + clip.duration - timelineTime;
      const settings = clip.audioSettings || {
        volume: 100,
        fadeIn: 0,
        fadeOut: 0,
        noiseReduction: false,
        voiceEnhance: false,
      };

      let gain = settings.volume / 100;
      if (settings.fadeIn > 0 && localElapsed < settings.fadeIn) {
        gain *= localElapsed / settings.fadeIn;
      }
      if (settings.fadeOut > 0 && remaining < settings.fadeOut) {
        gain *= remaining / settings.fadeOut;
      }

      if (gain <= 0.01) continue;

      // Sample waveform energy at current position
      if (clip.waveform && clip.waveform.length > 0) {
        const idx = Math.min(
          clip.waveform.length - 1,
          Math.floor((localElapsed / Math.max(0.1, clip.duration)) * clip.waveform.length)
        );
        totalEnergy += clip.waveform[idx] * gain;
      } else {
        totalEnergy += (0.35 + 0.25 * Math.abs(Math.sin(timelineTime * 9))) * gain;
      }

      // Trigger synthesized procedural music pulse or SFX
      if (clip.proceduralPreset?.startsWith('synthwave') || clip.proceduralPreset?.startsWith('lofi') || clip.proceduralPreset?.startsWith('cinematic')) {
        const bpm = clip.proceduralPreset === 'lofi-92' ? 92 : clip.proceduralPreset === 'cinematic-110' ? 110 : 128;
        const stepDuration = 60 / bpm / 2; // 8th notes
        const stepIndex = Math.floor(timelineTime / stepDuration);
        if (stepIndex !== this.lastTriggeredBeatIndex) {
          this.lastTriggeredBeatIndex = stepIndex;
          this.triggerSynthStep(clip.proceduralPreset, stepIndex, Math.min(1, gain * 0.35), settings.voiceEnhance);
        }
      } else if (clip.proceduralPreset?.startsWith('sfx-')) {
        const triggerKey = `${clip.id}-${Math.floor(clip.startTime * 10)}`;
        if (localElapsed < 0.25 && !this.triggeredSfxIds.has(triggerKey)) {
          this.triggeredSfxIds.add(triggerKey);
          this.triggerSfx(clip.proceduralPreset, Math.min(1, gain * 0.5));
        }
      }
    }

    const clamped = Math.min(98, Math.round(totalEnergy * 78));
    const jitter = Math.round(Math.sin(timelineTime * 42) * 5);
    return {
      leftLevel: Math.max(0, Math.min(100, clamped + jitter)),
      rightLevel: Math.max(0, Math.min(100, clamped - jitter)),
    };
  }

  private triggerSynthStep(preset: string, stepIndex: number, gainAmount: number, enhance: boolean) {
    try {
      const ctx = this.ensureContext();
      if (!this.masterGain) return;
      const now = ctx.currentTime;

      // Bass / Arpeggio notes (D minor pentatonic synthwave)
      const notes =
        preset === 'lofi-92'
          ? [146.83, 174.61, 220.0, 261.63, 196.0, 174.61, 146.83, 130.81]
          : preset === 'cinematic-110'
          ? [73.42, 73.42, 87.31, 73.42, 110.0, 98.0, 82.41, 73.42]
          : [146.83, 146.83, 293.66, 220.0, 261.63, 220.0, 174.61, 196.0];

      const freq = notes[stepIndex % notes.length];

      const osc = ctx.createOscillator();
      const filter = ctx.createBiquadFilter();
      const env = ctx.createGain();

      osc.type = preset === 'lofi-92' ? 'triangle' : 'sawtooth';
      osc.frequency.setValueAtTime(freq, now);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(enhance ? 2400 : 1250, now);
      filter.frequency.exponentialRampToValueAtTime(280, now + 0.19);

      env.gain.setValueAtTime(0.001, now);
      env.gain.linearRampToValueAtTime(gainAmount * 0.35, now + 0.015);
      env.gain.exponentialRampToValueAtTime(0.001, now + 0.21);

      osc.connect(filter);
      filter.connect(env);
      env.connect(this.masterGain);

      osc.start(now);
      osc.stop(now + 0.22);

      // Kick drum on even quarter beats
      if (stepIndex % 2 === 0) {
        const kickOsc = ctx.createOscillator();
        const kickEnv = ctx.createGain();
        kickOsc.type = 'sine';
        kickOsc.frequency.setValueAtTime(125, now);
        kickOsc.frequency.exponentialRampToValueAtTime(36, now + 0.12);

        kickEnv.gain.setValueAtTime(gainAmount * 0.55, now);
        kickEnv.gain.exponentialRampToValueAtTime(0.001, now + 0.14);

        kickOsc.connect(kickEnv);
        kickEnv.connect(this.masterGain);
        kickOsc.start(now);
        kickOsc.stop(now + 0.15);
      }
    } catch {
      // Ignore audio autoplay block if user hasn't clicked yet
    }
  }

  public triggerSfx(preset: string, gainAmount = 0.45) {
    try {
      const ctx = this.ensureContext();
      if (!this.masterGain) return;
      const now = ctx.currentTime;

      const osc = ctx.createOscillator();
      const env = ctx.createGain();

      if (preset === 'sfx-whoosh') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(140, now);
        osc.frequency.exponentialRampToValueAtTime(680, now + 0.22);
        osc.frequency.exponentialRampToValueAtTime(90, now + 0.55);
        env.gain.setValueAtTime(0.01, now);
        env.gain.linearRampToValueAtTime(gainAmount, now + 0.2);
        env.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
        osc.connect(env);
        env.connect(this.masterGain);
        osc.start(now);
        osc.stop(now + 0.62);
      } else if (preset === 'sfx-boom') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(98, now);
        osc.frequency.exponentialRampToValueAtTime(28, now + 0.9);
        env.gain.setValueAtTime(gainAmount * 0.9, now);
        env.gain.exponentialRampToValueAtTime(0.001, now + 0.95);
        osc.connect(env);
        env.connect(this.masterGain);
        osc.start(now);
        osc.stop(now + 1.0);
      } else {
        // Glitch burst
        osc.type = 'square';
        osc.frequency.setValueAtTime(520, now);
        osc.frequency.setValueAtTime(1240, now + 0.06);
        osc.frequency.setValueAtTime(310, now + 0.12);
        env.gain.setValueAtTime(gainAmount * 0.4, now);
        env.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
        osc.connect(env);
        env.connect(this.masterGain);
        osc.start(now);
        osc.stop(now + 0.24);
      }
    } catch {
      // Ignore
    }
  }
}

export const studioAudioEngine = new StudioAudioEngine();
